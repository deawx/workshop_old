<?php defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Javascript extends CI_Javascript {

  function __construction()
  {
    parent::__construct();
  }

}
