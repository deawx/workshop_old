<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['javascript_location'] = base_url('assets/js/jquery.min.js');
// $config['javascript_ajax_img'] = base_url('assets/img/loader_circle.gif');
