<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['about'] = 'test';
$config['address'] = '';
$config['email'] = '';
$config['phone'] = '';
