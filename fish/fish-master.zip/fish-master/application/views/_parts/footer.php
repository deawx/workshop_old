<br/><br/>
<footer>
  <hr/>
  <div class="container">
    <div class="row">
        <div class="col-lg-12">
            <p>Copyright &copy; ปีพุทธศักราช 2559 - <?=date('Y')+543;?></p>
        </div>
    </div>
  </div>
</footer>
