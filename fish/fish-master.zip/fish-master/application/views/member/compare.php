<?php
echo '<pre>';
print_r($compare);
echo '</pre>';
?>
