<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['site_title'] = 'mastercar-clinic';
$config['site_header'] = '<u>มาสเตอร์คาร์ คลีนิค</u>';
$config['site_footer'] = 'mastercar-clinic';
