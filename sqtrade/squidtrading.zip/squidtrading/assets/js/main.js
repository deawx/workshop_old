$(document).ready(function(){

	//confirm delete
	$('#confirm-delete').on('show.bs.modal',function(e) {
		var target = $(e.relatedTarget);
		var title = 'ยืนยันการทำงาน';
		var body = target.data('body');
		var href = target.data('href');
		var modal = $(this);
		modal.find('.modal-header').text(title);
		modal.find('.modal-body').html(body);
		modal.find('a.btn').attr('href',href);
	});

});
