-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 14, 2015 at 08:20 PM
-- Server version: 5.6.26
-- PHP Version: 5.5.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_squid`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_customer`
--

CREATE TABLE IF NOT EXISTS `tb_customer` (
  `cs_id` int(5) NOT NULL,
  `cs_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cs_address` text COLLATE utf8_unicode_ci NOT NULL,
  `cs_phone` varchar(10) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tb_customer`
--

INSERT INTO `tb_customer` (`cs_id`, `cs_name`, `cs_address`, `cs_phone`) VALUES
(1, 'customer1', 'address', '0000000000'),
(2, 'customer2', 'address', '0000000000'),
(3, 'customer3', 'address', '0000000000'),
(4, 'customer4', 'address', '0000000000'),
(5, 'customer5', 'address', '0000000000'),
(6, 'customer4', 'address', '0000000000'),
(7, 'customer6', 'address', '0000000000');

-- --------------------------------------------------------

--
-- Table structure for table `tb_member`
--

CREATE TABLE IF NOT EXISTS `tb_member` (
  `mb_id` int(5) NOT NULL,
  `mb_username` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `mb_password` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `mb_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `mb_address` text COLLATE utf8_unicode_ci NOT NULL,
  `mb_phone` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `mb_role` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tb_member`
--

INSERT INTO `tb_member` (`mb_id`, `mb_username`, `mb_password`, `mb_name`, `mb_address`, `mb_phone`, `mb_role`) VALUES
(1, 'chouwhit.j', '1234567890', 'ชูวิทย์&nbsp;จงใจ', 'ท่าเรือสินค้าปลาหมึก ตั้งอยู่ที่ 34/1 หมู่ 7 ตำบลธงชัย อำเภอบางสะพาน จังหวัดประจวบคีรีขันธ์', '9999999999', 1),
(2, 'employee01', '1234567890', 'ลูกจ้าง&nbsp;1', 'ท่าเรือสินค้าปลาหมึก ตั้งอยู่ที่ 34/1 หมู่ 7 ตำบลธงชัย อำเภอบางสะพาน จังหวัดประจวบคีรีขันธ์', '9999999999', 0),
(3, 'employee02', '1234567890', 'ลูกจ้าง&nbsp;2', 'ท่าเรือสินค้าปลาหมึก ตั้งอยู่ที่ 34/1 หมู่ 7 ตำบลธงชัย อำเภอบางสะพาน จังหวัดประจวบคีรีขันธ์', '9999999999', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tb_merchant`
--

CREATE TABLE IF NOT EXISTS `tb_merchant` (
  `mc_id` int(5) NOT NULL,
  `mc_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `mc_address` text COLLATE utf8_unicode_ci NOT NULL,
  `mc_phone` varchar(10) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tb_merchant`
--

INSERT INTO `tb_merchant` (`mc_id`, `mc_name`, `mc_address`, `mc_phone`) VALUES
(1, 'test&nbsp;test', 'test', '0000000000');

-- --------------------------------------------------------

--
-- Table structure for table `tb_purchase`
--

CREATE TABLE IF NOT EXISTS `tb_purchase` (
  `pc_id` int(5) NOT NULL,
  `cs_id` int(5) NOT NULL,
  `pc_date` date NOT NULL,
  `pc_total_price` int(10) NOT NULL,
  `pc_receiver` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `pc_ok` int(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tb_purchase`
--

INSERT INTO `tb_purchase` (`pc_id`, `cs_id`, `pc_date`, `pc_total_price`, `pc_receiver`, `pc_ok`) VALUES
(10, 1, '2015-09-05', 1000, 'ลูกจ้าง&nbsp;1', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_purchase_detail`
--

CREATE TABLE IF NOT EXISTS `tb_purchase_detail` (
  `pd_id` int(5) NOT NULL,
  `pc_id` int(5) NOT NULL,
  `sq_id` int(5) NOT NULL,
  `pd_weight` int(4) NOT NULL,
  `pd_price` int(10) NOT NULL,
  `pd_sum_price` int(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tb_purchase_detail`
--

INSERT INTO `tb_purchase_detail` (`pd_id`, `pc_id`, `sq_id`, `pd_weight`, `pd_price`, `pd_sum_price`) VALUES
(32, 10, 3, 100, 10, 1000);

-- --------------------------------------------------------

--
-- Table structure for table `tb_sell`
--

CREATE TABLE IF NOT EXISTS `tb_sell` (
  `sl_id` int(5) NOT NULL,
  `mc_id` int(5) NOT NULL,
  `sl_date` date NOT NULL,
  `sl_total_price` int(10) NOT NULL,
  `sl_receiver` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `sl_ok` int(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tb_sell`
--

INSERT INTO `tb_sell` (`sl_id`, `mc_id`, `sl_date`, `sl_total_price`, `sl_receiver`, `sl_ok`) VALUES
(1, 0, '2015-09-05', 1000, 'ลูกจ้าง&nbsp;1', 1),
(2, 1, '2015-09-15', 0, 'ชูวิทย์&nbsp;จงใจ', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tb_sell_detail`
--

CREATE TABLE IF NOT EXISTS `tb_sell_detail` (
  `sd_id` int(5) NOT NULL,
  `sl_id` int(5) NOT NULL,
  `sq_id` int(5) NOT NULL,
  `sd_weight` int(3) NOT NULL,
  `sd_price` int(10) NOT NULL,
  `sd_sum_price` int(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tb_sell_detail`
--

INSERT INTO `tb_sell_detail` (`sd_id`, `sl_id`, `sq_id`, `sd_weight`, `sd_price`, `sd_sum_price`) VALUES
(16, 1, 1, 50, 10, 500),
(17, 1, 1, 50, 10, 500);

-- --------------------------------------------------------

--
-- Table structure for table `tb_squid`
--

CREATE TABLE IF NOT EXISTS `tb_squid` (
  `sq_id` int(5) NOT NULL,
  `sq_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `sq_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `sq_amount` int(4) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tb_squid`
--

INSERT INTO `tb_squid` (`sq_id`, `sq_name`, `sq_type`, `sq_amount`) VALUES
(1, 'หมึกกะตอย', 'หมึกกล้วย', 0),
(2, 'หมึกเอ็ม', 'หมึกกล้วย', 100),
(3, 'หมึกนาง', 'หมึกกล้วย', 100),
(4, 'หมึกไข่', 'หมึกกล้วย', 100),
(5, 'หมึกโก๋', 'หมึกกล้วย', 100),
(6, 'หมึกศอก', 'หมึกกล้วย', 100),
(7, 'หมึกกระดองใหญ่', 'หมึกกระดอง', 100),
(8, 'หมึกกระดองเล็ก', 'หมึกกระดอง', 100),
(9, 'หมึกหอมใหญ่', 'หมึกหอม', 100),
(10, 'หมึกหอมเล็ก', 'หมึกหอม', 100),
(11, 'หมึกทะวาย', 'หมึกสาย', 100);

-- --------------------------------------------------------

--
-- Table structure for table `tb_stock`
--

CREATE TABLE IF NOT EXISTS `tb_stock` (
  `st_id` int(5) NOT NULL,
  `sq_id` int(5) NOT NULL,
  `st_amount` int(10) NOT NULL,
  `st_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_customer`
--
ALTER TABLE `tb_customer`
  ADD PRIMARY KEY (`cs_id`);

--
-- Indexes for table `tb_member`
--
ALTER TABLE `tb_member`
  ADD PRIMARY KEY (`mb_id`);

--
-- Indexes for table `tb_merchant`
--
ALTER TABLE `tb_merchant`
  ADD PRIMARY KEY (`mc_id`);

--
-- Indexes for table `tb_purchase`
--
ALTER TABLE `tb_purchase`
  ADD PRIMARY KEY (`pc_id`);

--
-- Indexes for table `tb_purchase_detail`
--
ALTER TABLE `tb_purchase_detail`
  ADD PRIMARY KEY (`pd_id`);

--
-- Indexes for table `tb_sell`
--
ALTER TABLE `tb_sell`
  ADD PRIMARY KEY (`sl_id`);

--
-- Indexes for table `tb_sell_detail`
--
ALTER TABLE `tb_sell_detail`
  ADD PRIMARY KEY (`sd_id`);

--
-- Indexes for table `tb_squid`
--
ALTER TABLE `tb_squid`
  ADD PRIMARY KEY (`sq_id`);

--
-- Indexes for table `tb_stock`
--
ALTER TABLE `tb_stock`
  ADD PRIMARY KEY (`st_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_customer`
--
ALTER TABLE `tb_customer`
  MODIFY `cs_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tb_member`
--
ALTER TABLE `tb_member`
  MODIFY `mb_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tb_merchant`
--
ALTER TABLE `tb_merchant`
  MODIFY `mc_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tb_purchase`
--
ALTER TABLE `tb_purchase`
  MODIFY `pc_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `tb_purchase_detail`
--
ALTER TABLE `tb_purchase_detail`
  MODIFY `pd_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `tb_sell`
--
ALTER TABLE `tb_sell`
  MODIFY `sl_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tb_sell_detail`
--
ALTER TABLE `tb_sell_detail`
  MODIFY `sd_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `tb_squid`
--
ALTER TABLE `tb_squid`
  MODIFY `sq_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `tb_stock`
--
ALTER TABLE `tb_stock`
  MODIFY `st_id` int(5) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
