<div class="row">
  <div class="col-md-12">
  <?php $sl_id = $sl->sl_id+1; ?>
    <form class="form-horizontal well" role="selling" method="post" action="<?php echo site_url('selling/open_bill/'.$sl_id); ?>">
    <div class="form-group">
      <label class="col-sm-3 control-label"></label>
      <div class="col-md-9">
        <button type="submit" class="btn btn-info hidden-print">
			เปิดรายการขายใหม่
        </button>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label">เลือกรายชื่อพ่อค้าคนกลาง</label>
      <div class="col-md-9">
        <select class="form-control" name="merchant">
          <option value="">กรุณาเลือกรายชื่อพ่อค้าคนกลาง</option>
          <?php foreach($merchant as $_c) { ?>
            <option value="<?php echo $_c['mc_id']; ?>"><?php echo $_c['mc_name']; ?></option>
          <?php } ?>
        </select>
      </div>
    </div>
      <div class="form-group">
        <label class="col-sm-3 control-label">เลขกำกับ : รายการที่</label>
        <div class="col-md-9">
          <?php  echo 'SL-'.$sl_id; ?>
        </div>
      </div>
      <div class="form-group">
        <label class="col-sm-3 control-label">วันที่ปัจจุบัน</label>
        <div class="col-md-9">
          <input type="text" class="form-control" value="<?php echo date('d-m-Y'); ?>" disabled />
        </div>
      </div>
    </form>
  </div>
</div>

<script>
$(document).ready(function(){
  $('form[role="selling"]').validate({
    debug:true,
    onkeyup:false,
    errorElement:'label',
    rules:{
      merchant: {
        required:true
      }
    },
    messages:{
      merchant: {
        required:'เลือกรายชื่อ'
      }
    },
    submitHandler: function(form){
      form.submit();
    }
  });
});
</script>
