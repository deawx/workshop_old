<div class="row">
  <?php if( ! $trade->pc_ok) { ?>
  <div class="col-md-12 well hidden-print">
    <form role="bill" method="post" action="<?php echo site_url('trading/add_bill'); ?>">
      <legend> บันทึกรายการสั่งซื้อ </legend>
      <div class="form-group">
        <div class="col-md-4">
          <select class="form-control" name="squid">
            <option value="">เลือกรายการปลาหมึก</option>
            <?php foreach($squid as $_s) { ?>
              <option value="<?php echo $_s['sq_id']; ?>"><?php echo $_s['sq_name']; ?></option>
            <?php } ?>
          </select>
        </div>
        <div class="col-md-3">
          <div class="input-group">
            <input type="number" name="weight" class="form-control" placeholder="น้ำหนักที่รับซื้อ" />
            <span class="input-group-addon">kg.</span>
          </div>
        </div>
        <div class="col-md-3">
          <div class="input-group">
            <input type="number" name="price" class="form-control" placeholder="ราคาต่อกิโลกรัม" />
            <span class="input-group-addon">฿</span>
          </div>
        </div>
        <div class="col-md-2">
          <input type="hidden" name="pc_id" value="<?php echo $this->uri->segment(2); ?>" />
          <button class="btn btn-success btn-sm">เพิ่มรายการ</button>
        </div>
      </div>
    </form>
  </div>
  <?php } ?>
  <span class="alert-warning">
	<?php echo ($this->session->flashdata('error') != '') ? $this->session->flashdata('error') : NULL ; ?>
  </span>

  <div class="com-md-12 pull-right">
    <p class="lead">รายการรับซื้อที่ : PC-<?php echo $trade->pc_id; ?></p>
    <p class="lead">วันที่ : <?php echo $trade->pc_date; ?></p>
    <p class="lead">ผู้ขาย : <?php echo $trade->cs_name; ?></p>
  </div>
  <br />
  <table class="table table-bordered table-hover">
    <thead>
      <tr>
        <th class="text-center">ที่</th>
        <th class="text-center" style="width:20%;">เลขกำกับ</th>
        <th class="text-center" style="width:30%;">รายชื่อสินค้า</th>
        <th class="text-center">น้ำหนักรับซื้อ(กิโลกรัม)</th>
        <th class="text-center">ราคาต่อหน่วย(กิโลกรัม)</th>
        <th class="text-center" style="width:30%;">ราคารวม</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($trade_detail as $_k => $_d) { ?>
      <tr>
        <td class="text-center"><?php echo $_k+1; ?></td>
        <td>PD-<?php echo $_d['pd_id']; ?></td>
        <td>SQ-<?php foreach($squid as $_s) { if($_d['sq_id'] === $_s['sq_id']) { echo $_s['sq_name']; } } ?></td>
        <td class="text-center"><?php echo $_d['pd_weight']; ?></td>
        <td class="text-right"><?php echo $_d['pd_price']; ?></td>
        <td class="text-right"><?php echo $_d['pd_sum_price']; ?></td>
        <?php if( ! $trade->pc_ok) { ?>
        <td class="hidden-print">
          <a href="#" data-toggle="modal" data-target="#confirm-delete" data-body="<?php foreach($squid as $_s) { if($_d['sq_id'] === $_s['sq_id']) { echo $_s['sq_name']; } } ?>" data-href="<?php echo site_url('trading/del_bill').'/'.$_d['pd_id'].'/'.$_d['pd_sum_price'].'/'.$_d['pc_id']; ?>">
            <span class="glyphicon glyphicon-remove"></span>
          </a>
        </td>
        <?php }?>
      </tr>
      <?php } ?>
    </tbody>
    <tfoot>
      <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <th class="text-right">ราคารวมสุทธิ</th>
        <th class="text-right"><?php echo $trade->pc_total_price; ?></th>
      </tr>
      <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <th class="text-right">ผู้รับผิดชอบ</th>
        <th class="text-right"><?php echo $trade->pc_receiver; ?></th>
      </tr>
    </tfoot>
  </table>

  <div class="hidden-print">
    <hr />
    <?php if( ! $trade->pc_ok) { ?>
      <a href="#" class="btn btn-success" data-toggle="modal" data-target="#confirm-delete" data-body="หลังจากยืนยันจะไม่สามารถแก้ไขรายการได้อีก" data-href="<?php echo site_url('trading/add_ok').'/'.$trade->pc_id; ?>">ยืนยันรายการ</a>
    <?php }else{ ?>
      <p>ยืนยันรายการเรียบร้อยแล้ว</p>
    <?php } ?>
    <button class="btn btn-info" onclick="window.print();">สั่งพิมพ์ใบเสร็จ</button>
  </div>

</div>

<script>
$(document).ready(function(){
	$('form[role="bill"]').validate({
		debug:true,
    onkeyup:false,
		errorElement:'label',
		rules:{
			squid: {
				required:true
      },
      weight: {
        required:true
      },
      price: {
        required:true
      }
		},
		messages:{
			squid: {
				required:'เลือกรายชื่อสินค้า'
      },
      weight: {
        required:'ระบุน้ำหนักที่รับซื้อ'
      },
      price: {
        required:'กำหนดราคาต่อกิโลกรัม'
      }
		},
		submitHandler: function(form){
      form.submit();
		}
	});
});
</script>
