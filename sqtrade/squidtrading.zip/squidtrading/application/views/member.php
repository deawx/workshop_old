<div class="row">
  <div class="col-md-6">
    <form class="form-horinzontal" role="member" method="post" action="<?php if( isset($edit)) { echo site_url('member/update_member/'.$edit->mb_id); }else{ echo site_url('member/regis_member'); } ?>">
      <div class="input-group">
        <span class="input-group-addon">
          <span class="glyphicon glyphicon-user"></span>
        </span>
        <input class="form-control" type="text" name="username" <?php if( isset($edit)){ echo 'value="'.$edit->mb_username.'"'; }else{ echo 'placeholder="ชื่อผู้ใช้"'; } ?> />
        <input class="form-control" type="text" name="password" <?php if( isset($edit)){ echo 'value="'.$edit->mb_password.'"'; }else{ echo 'placeholder="รหัสผ่าน"'; } ?> />
      </div>
      <hr />
      <div class="input-group">
        <span class="input-group-addon">
          <span class="glyphicon glyphicon-user"></span>
        </span>
        <input class="form-control" type="text" name="name" <?php if( isset($edit)){ echo 'value="'.explode('&nbsp;',$edit->mb_name)[0].'"'; }else{ echo 'placeholder="ชื่อ"'; } ?> />
        <input class="form-control" type="text" name="lname" <?php if( isset($edit)){ echo 'value="'.explode('&nbsp;',$edit->mb_name)[1].'"'; }else{ echo 'placeholder="นามสกุล"'; } ?> />
      </div>
      <div class="input-group">
        <span class="input-group-addon">
          <span class="glyphicon glyphicon-home"></span>
        </span>
        <textarea rows="3" class="form-control" name="address"><?php if( isset($edit)){ echo $edit->mb_address; } ?></textarea>
      </div>
      <div class="input-group">
        <span class="input-group-addon">
          <span class="glyphicon glyphicon-earphone"></span>
        </span>
        <input class="form-control" type="text" name="phone" <?php if( isset($edit)){ echo 'value="'.$edit->mb_phone.'"'; }else{ echo 'placeholder="081xxxxxxx"'; } ?> />
      </div>
      <hr />
      <div class="input-group">
        <button class="btn btn-primary" type="submit" id="myButton">ยืนยัน</button>
        <button class="btn btn-danger" type="reset">ยกเลิก</button>
      </div>
    </form>
  </div>

  <div class="col-md-6">
    <table class="table table-bordered table-striped datatable">
      <thead>
        <tr>
          <th class="text-center">ที่</th>
          <th class="text-center">ชื่อ-นามสกุล</th>
          <th class="text-center">ที่อยู่</th>
          <th class="text-center">เบอร์โทรศัพท์</th>
          <th class="text-center"></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($member as $_k => $_c) { ?>
        <tr>
          <td class="text-center" style="width:5%;"><?php echo $_k+1; ?></td>
          <td>
            <?php if($this->session->has_userdata('admin')) { ?>
            <a href="<?php echo site_url('member/'.$_c['mb_id']); ?>">
              <?php echo $_c['mb_name']; ?>
            </a>
            <?php }else{ ?>
              <?php echo $_c['mb_name']; ?>
            <?php } ?>
          </td>
          <td style="width:35%;"><?php echo $_c['mb_address']; ?></td>
          <td class="text-center"><?php echo $_c['mb_phone']; ?></td>
		  <?php if($this->session->has_userdata('admin')) { ?>
          <?php if($_c['mb_role'] !== '1') { ?>
          <td class="text-center">
            <a href="#" data-href="<?php echo site_url('member/delete_member/'.$_c['mb_id']); ?>" data-toggle="modal" data-target="#confirm-delete" data-body="ยืนยันการลบสมาชิก">
              <i class="glyphicon glyphicon-remove"></i>
            </a>
          </td>
          <?php }else{ ?>
            <td class="text-center">
              <i class="glyphicon glyphicon-ok"></i>
            </td>
          <?php }} ?>
        </tr>
        <?php } ?>
      </tbody>
    </table>
  </div>
</div>

<script>
$(document).ready(function(){
	$('form[role="member"]').validate({
		debug:true,
    onkeyup:false,
		errorElement:'label',
		rules:{
			username: {
				required:true,
				rangelength:[1,10]
			},
			password: {
				required:true,
				rangelength:[1,10]
			},
			name: {
				required:true,
				rangelength:[1,50]
			},
			lname: {
				required:true,
				rangelength:[1,50]
			},
			address: {
				required:true
			},
			phone: {
				required:true,
        number:true,
        rangelength:[10,10]
			}
		},
		messages:{
			username: {
				required:'กรุณากรอกชื่อผู้ใช้',
				rangelength:'1 ถึง 10 ตัวอักษร'
			},
			password: {
				required:'กรุณากรอกรหัสผ่าน',
				rangelength:'1 ถึง 10 ตัวอักษร'
			},
			name: {
				required:'กรุณากรอกชื่อ',
				rangelength:'1 ถึง 50 ตัวอักษร'
			},
			lname: {
				required:'กรุณากรอกนามสกุล',
				rangelength:'1 ถึง 50 ตัวอักษร'
			},
      address: {
        required:'กรุณากรอกที่อยู่'
      },
      phone: {
				required:'กรุณากรอกเบอร์โทรศัพท์',
				number:'กรุณากรอกข้อมูลตัวเลข',
        rangelength:'ตัวเลข 10 หลัก'
			}
		},
		submitHandler: function(form){
      form.submit();
		}
	});
});
</script>
