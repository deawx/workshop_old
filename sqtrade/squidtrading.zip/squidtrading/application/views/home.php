<div class="row">
	<div class="col-md-8">
		<img class="img-responsive img-rounded" src="<?php echo base_url('assets/img/boat.jpg'); ?>" alt="">
	</div>
	<div class="col-md-4">
		<h1>ระบบการจัดการสินค้าทางทะเลของท่าเรือบ้านกรูด</h1>
		<p>The management system of trading maring port terminal in casestudy squid trading</p>
	</div>
</div>

<hr>

<table class="table table-bordered table-striped">
	<thead>
		<tr>
			<th class="text-center" style="width:10%;">ลำดับที่</th>
			<th class="text-center" style="width:30%;">ประเภทของปลาหมึก</th>
			<th class="text-center" style="width:60%;">ชนิดของปลาหมึก</th>
		</tr>
	</thead>
	<tbody>
	<?php foreach ($squid as $_s) { ?>
		<tr>
			<td class="text-center"><?php echo $_s['sq_id']; ?></td>
			<td><?php echo $_s['sq_type']; ?></td>
			<td><?php echo $_s['sq_name']; ?></td>
		</tr>
	<?php } ?>
	</tbody>
</table>
