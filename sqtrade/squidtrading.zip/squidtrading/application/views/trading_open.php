<div class="row">
  <form class="form-horizontal well" role="trading" method="post" action="<?php echo site_url('trading_open/add_trading'); ?>">
    <div class="form-group">
      <label class="col-sm-3 control-label"></label>
      <div class="col-md-9">
        <button type="submit" class="btn btn-info">
          เปิดรายการซื้อใหม่
        </button>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label">เลือกรายชื่อลูกค้า</label>
      <div class="col-md-9">
        <select class="form-control" name="customer">
          <option value="">กรุณาเลือกรายชื่อลูกค้า</option>
          <?php foreach($customer as $_c) { ?>
            <option value="<?php echo $_c['cs_id']; ?>"><?php echo $_c['cs_name']; ?></option>
          <?php } ?>
        </select>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label">เลขกำกับ : รายการที่</label>
      <div class="col-md-9">
        <?php
          $pc_id = $pc->pc_id+1;
          echo 'PC-'.$pc_id;
        ?>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label">วันที่ปัจจุบัน</label>
      <div class="col-md-9">
        <input type="text" class="form-control" value="<?php echo date('d-m-Y'); ?>" disabled />
      </div>
    </div>
    <hr />
    <div class="form-group">
      <div class="col-md-9 col-md-offset-3">
        <a class="pull-right" href="<?php echo site_url('register'); ?>">เพิ่มลูกค้าใหม่</a>
      </div>
    </div>
  </form>
</div>

<script>
$(document).ready(function(){
  $('form[role="trading"]').validate({
    debug:true,
    onkeyup:false,
    errorElement:'label',
    rules:{
      customer: {
        required:true
      }
    },
    messages:{
      customer: {
        required:'เลือกรายชื่อลูกค้า'
      }
    },
    submitHandler: function(form){
      form.submit();
    }
  });
});
</script>
