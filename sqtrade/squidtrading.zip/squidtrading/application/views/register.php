<div class="row">
  <div class="col-md-6">
    <form class="form-horinzontal" role="register" method="post" action="<?php echo site_url('register/do_regis'); ?>">
      <div class="input-group">
        <span class="input-group-addon">
          <span class="glyphicon glyphicon-user"></span>
        </span>
        <input class="form-control" type="text" name="name" <?php if(isset($edit) != ''){ echo 'value="'.explode('&nbsp;',$edit->mc_name)[0].'"'; }else{ echo 'placeholder="ชื่อ"'; } ?> />
        <input class="form-control" type="text" name="lname" <?php if(isset($edit) != ''){ echo 'value="'.explode('&nbsp;',$edit->mc_name)[1].'"'; }else{ echo 'placeholder="นามสกุล"'; } ?> />
      </div>
      <div class="input-group">
        <span class="input-group-addon">
          <span class="glyphicon glyphicon-home"></span>
        </span>
        <textarea rows="3" class="form-control" name="address"></textarea>
      </div>
      <div class="input-group">
        <span class="input-group-addon">
          <span class="glyphicon glyphicon-earphone"></span>
        </span>
        <input class="form-control" type="text" name="phone" placeholder="08xxxxxxxx" />
      </div>
      <hr />
      <div class="input-group">
        <button class="btn btn-primary" type="submit" id="myButton">Submit</button>
        <button class="btn btn-danger" type="reset">Reset</button>
      </div>
    </form>
  </div>

  <div class="col-md-6">
    <table class="table table-bordered table-striped datatable">
      <thead>
        <tr>
          <th class="text-center">ที่</th>
          <th class="text-center">ชื่อ-นามสกุล</th>
          <th class="text-center">ที่อยู่</th>
          <th class="text-center">เบอร์โทรศัพท์</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($customer as $_k => $_c) { ?>
        <tr class="rows">
          <td class="text-center" style="width:5%;"><?php echo $_k+1; ?></td>
          <td><?php echo $_c['cs_name']; ?></td>
          <td style="width:35%;"><?php echo $_c['cs_address']; ?></td>
          <td class="text-center"><?php echo $_c['cs_phone']; ?></td>
        </tr>
        <?php } ?>
      </tbody>
    </table>
  </div>
</div>

<script type="text/javascript">
$(document).ready(function(){
	$('form[role="register"]').validate({
		debug:true,
    onkeyup:false,
		errorElement:'label',
		rules:{
			name: {
				required:true,
				rangelength:[3,100],
        remote:{
          type: 'POST',
          url : '<?php echo site_url("register/checkName"); ?>',
          data : {
            username : function(){
              return $('#name').val();
            }
          }
        }
			},
			address: {
				required:true
			},
			phone: {
				required:true,
        number:true,
        rangelength:[10,10]
			}
		},
		messages:{
			name: {
				required:'กรุณากรอกชื่อ',
				rangelength:'3 ถึง 100 ตัวอักษร',
        remote:'มีผู้ใช้ชื่อนี้อยู่แล้ว',
			},
      address: {
        required:'กรอกที่อยู่'
      },
      phone: {
				required:'กรอกรายละเอียด',
				number:'กรอกข้อมูลตัวเลข',
        rangelength:'ตัวเลขจำนวน 10 หลัก',
			}
		},
		submitHandler: function(form){
      form.submit();
		}
	});
});
</script>
