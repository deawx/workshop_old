<?php
$address =  read_file('assets/files/address.txt');
?>

<div class="row">
  <div class="col-md-6 col-md-push-3 col-md-pull-3">
  <form class="form-horinzontal" role="login" method="post" action="<?php echo site_url('address/write_address'); ?>">
    <div class="input-group">
      <span class="input-group-addon">
        <span class="glyphicon glyphicon-file"></span>
      </span>
      <textarea class="form-control" type="text" name="address" placeholder="Address"><?=$address;?></textarea>
    </div>
    <hr />
    <div class="input-group">
      <button class="btn btn-primary" type="submit" id="myButton">Submit</button>
      <button class="btn btn-danger" type="reset">Reset</button>
      <?php if($this->session->flashdata('error')) { ?>
        <span class="text-warning h4"><?php echo $this->session->flashdata('error'); ?></span>
      <?php } ?>
    </div>
  </form>
  </div>
</div>
