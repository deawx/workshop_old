<div class="row">
  <div class="col-md-12">
  <div class="col-md-12 hidden-print">
    <table class="table table-bordered table-striped datatable">
      <thead>
        <tr>
          <th class="text-center" style="width:10%;">เลขกำกับ</th>
          <th class="text-center" style="width:15%;">วันที่</th>
          <th class="text-center">ราคารวม</th>
          <th class="text-center"></th>
          <th class="text-center"></th>
          <th class="text-center"></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($sell as $_s) { ?>
        <tr class="rows">
          <td class="text-center"> SL-<?php echo $_s['sl_id']; ?> </td>
          <td class="text-center"><?php echo $_s['sl_date']; ?></td>
          <td class="text-right"><?php echo $_s['sl_total_price']; ?>฿</td>
          <td class="text-center"><?php echo $_s['sl_receiver']; ?></td>
          <td class="text-center" style="width:10%;"><a href="<?php echo site_url('selling').'/'.$_s['sl_id']; ?>"> <span class="glyphicon glyphicon-search"></span></a></td>
          <td class="text-center" style="width:10%;">
          <?php if( ! $_s['sl_ok']) { ?>
            <a href="#" data-href="<?php echo site_url('selling/del_selling').'/'.$_s['sl_id']; ?>" data-toggle="modal" data-target="#confirm-delete" data-body="<?php echo $_s['sl_date'].'&nbsp;'.$_s['sl_receiver']; ?>">
              <span class="glyphicon glyphicon-remove"></span>
            </a>
          <?php }else{ ?>
            <a href="#" data-href="<?php echo site_url('selling/add_cancel').'/'.$_s['sl_id']; ?>" data-toggle="modal" data-target="#confirm-delete" data-body="<?php echo $_s['sl_date'].'&nbsp;'.$_s['sl_receiver']; ?>">
              <span class="glyphicon glyphicon-edit"></span>
            </a>
          <?php } ?>
          </td>
        </tr>
        <?php } ?>
      </tbody>
    </table>
  </div>
</div>
