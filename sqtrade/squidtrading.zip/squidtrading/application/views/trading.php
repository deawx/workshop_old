<div class="row">
  <table class="table table-bordered table-hover datatable">
    <thead>
      <tr>
        <th class="text-center">เลขกำกับ</th>
        <th class="text-center">วันที่</th>
        <th class="text-center">ราคารวม</th>
        <th class="text-center">ผู้รับผิดชอบ</th>
        <th class="text-center"></th>
        <th class="text-center"></th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($trade as $_t) { ?>
      <tr class="rows">
        <td>PC-<?php echo $_t['pc_id']; ?></td>
        <td><?php echo $_t['pc_date']; ?></td>
        <td><?php echo $_t['pc_total_price']; ?></td>
        <td><?php echo $_t['pc_receiver']; ?></td>
        <td class="text-center">
          <a href="<?php echo site_url('trading').'/'.$_t['pc_id']; ?>"> <span class="glyphicon glyphicon-info-sign"></span> </a>
        </td>
        <td class="text-center">
        <?php if( ! $_t['pc_ok']) { ?>
          <a href="#" data-href="<?php echo site_url('trading/del_trading').'/'.$_t['pc_id']; ?>" data-toggle="modal" data-target="#confirm-delete" data-body="<?php echo $_t['pc_date'].'&nbsp;'.$_t['pc_receiver']; ?>">
            <span class="glyphicon glyphicon-remove"></span>
          </a>
        <?php }else{ ?>
          <a href="#" data-href="<?php echo site_url('trading/add_cancel').'/'.$_t['pc_id']; ?>" data-toggle="modal" data-target="#confirm-delete" data-body="<?php echo $_t['pc_date'].'&nbsp;'.$_t['pc_receiver']; ?>">
            <span class="glyphicon glyphicon-edit"></span>
          </a>
        <?php } ?>
        </td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
</div>
