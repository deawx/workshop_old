<?php $price = array(); $sellprice = array(); $mn = ($this->uri->segment(2) != '') ? $this->uri->segment(2) : date('m'); $month = $months[$mn-1]; ?>
<div class="row">
  <div class="col-md-12 hidden-print well">
    <div class="col-md-3">
      <select class="form-control" name="month" onchange="location=this.options[this.selectedIndex].value;">
        <option> <?php echo ($this->uri->segment(2) != '') ? $month : "---เลือกดูรายการแต่ละเดือน---"; ?> </option>
        <?php for($i=0;$i<=date('m')-1;$i++) { ?>
          <option value="<?php echo site_url('stock').'/'.substr_replace("00",$i+1,2-strlen($i));; ?>">
            <?php echo $months[$i]; ?>
          </option>
        <?php } ?>
      </select>
    </div>
    <div class="pull-right hidden-print">
      <button class="btn btn-info" onclick="window.print();">สั่งพิมพ์รายการ</button>
    </div>
  </div>
  <div class="col-md-8 tabpanel">
  <ul class="nav nav-tabs hidden-print" role="tablist">
    <li role="presentation" class="active"><a href="#trading" aria-controls="trading" role="tab" data-toggle="tab">การซื้อ</a></li>
    <li role="presentation"><a href="#selling" aria-controls="selling" role="tab" data-toggle="tab">การขาย</a></li>
  </ul>
  <div class="tab-content">

    <div role="tabpanel" class="tab-pane in active" id="trading">
      <h3> รายการรับซื้อของเดือน <?php echo $month; ?> </h3>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th class="text-center" style="width:10%;">เลขกำกับรายการ</th>
            <th>รายการสินค้า</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($purchase as $_pc) { if(explode('-',$_pc['pc_date'])[1] === $mn) { ?>
          <tr>
            <td class="text-center">PC-<?php echo $_pc['pc_id']; ?></td>
            <td>
              <table class="table" style="border:none;">
              <?php foreach($purchase_detail as $_pd) { if($_pc['pc_id'] === $_pd['pc_id']) { ?>
                <?php foreach($squid as $_sq) { if($_pd['sq_id'] === $_sq['sq_id']) { ?>
                  <tr>
                    <td style="width:60%;border:none;">SQ-<?php echo $_sq['sq_name']; ?></td>
                    <td><?php echo $_pd['pd_weight']; ?>kg.</td>
                    <td><?php echo $_pd['pd_sum_price']; ?>฿</td>
                    <?php $price[] = $_pd['pd_sum_price']; $sumprice = array_sum($price); ?>
                  </tr>
                <?php } } ?>
              <?php } } ?>
              </table>
            </td>
          </tr>
          <?php } } ?>
        </tbody>
        <tr>
          <td></td>
          <td class="text-right" style="padding-right:15%;">
            ราคารวมสุทธิ&nbsp;&nbsp; <?php echo !empty($sumprice) ? $sumprice : NULL; ?> &nbsp;฿
          </td>
        </tr>
        <tr>
          <td></td>
          <td class="text-right" style="padding-right:15%;">
            &nbsp;&nbsp; <?php echo $this->session->userdata('mb_name'); ?>
          </td>
        </tr>
      </table>
    </div>

    <div role="tabpanel" class="tab-pane" id="selling">
      <h3> รายการขาย ของเดือน <?php echo $month; ?> </h3>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th class="text-center" style="width:10%;">เลขกำกับรายการ</th>
            <th>รายการสินค้า</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($sell as $_sl) { if(explode('-',$_sl['sl_date'])[1] === $mn) { ?>
          <tr>
            <td class="text-center">SL-<?php echo $_sl['sl_id']; ?></td>
            <td>
              <table class="table" style="border:none;">
              <?php foreach($sell_detail as $_sd) { if($_sl['sl_id'] === $_sd['sl_id']) { ?>
                <?php foreach($squid as $_sq) { if($_sd['sq_id'] === $_sq['sq_id']) { ?>
                  <tr>
                    <td style="width:60%;border:none;">SQ-<?php echo $_sq['sq_name']; ?></td>
                    <td><?php echo 'วันที่ '.explode('-',$_sl['sl_date'])[1]; ?></td>
                    <td><?php echo $_sd['sd_weight']; ?>kg.</td>
                    <td><?php echo $_sd['sd_sum_price']; ?>฿</td>
                    <?php $sellprice[] = $_sd['sd_sum_price']; $sumsellprice = array_sum($sellprice); ?>
                  </tr>
                <?php } } ?>
              <?php } } ?>
              </table>
            </td>
          </tr>
          <?php } } ?>
        </tbody>
        <tr>
          <td></td>
          <td class="text-right" style="padding-right:15%;">
            ราคารวมสุทธิ&nbsp;&nbsp; <?php echo !empty($sumsellprice) ? $sumsellprice : NULL; ?> &nbsp;฿
          </td>
        </tr>
        <tr>
          <td></td>
          <td class="text-right" style="padding-right:15%;">
            &nbsp;&nbsp; <?php echo $this->session->userdata('mb_name'); ?>
          </td>
        </tr>
      </table>
    </div>
  </div>

  </div>
  <div class="col-md-4 hidden-print">
    <h3>สรุปรายการปัจจุบันในสต็อก</h3>
    <table class="table table-bordered table-striped">
      <thead>
        <tr>
          <th class="text-center" style="width:20%;">ที่</th>
          <th>รายการปลาหมึก</th>
          <th style="width:20%;">สต็อค</th>
        </tr>
      </thead>
      <tbody>
      <form role="stock">
        <?php foreach($stock as $_s) { ?>
        <tr>
          <td class="text-center">SQ-<?php echo $_s['sq_id']; ?></td>
          <td><?php echo $_s['sq_name']; ?></td>
          <td><?php echo $_s['sq_amount']; ?> kg.</td>
        </tr>
        <?php } ?>
      </form>
      </tbody>
    </table>
  </div>
</div>
