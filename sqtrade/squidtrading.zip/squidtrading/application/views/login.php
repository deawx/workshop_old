<div class="row">
  <div class="col-md-6 col-md-push-3 col-md-pull-3">
  <form class="form-horinzontal" role="login" method="post" action="<?php echo site_url('login/do_login'); ?>">
    <div class="input-group">
      <span class="input-group-addon">
        <span class="glyphicon glyphicon-user"></span>
      </span>
      <input class="form-control" type="text" name="username" placeholder="Username" />
    </div>
    <div class="input-group">
      <span class="input-group-addon">
        <span class="glyphicon glyphicon-eye-close"></span>
      </span>
      <input class="form-control" type="password" name="password" id="password" placeholder="Password" />
    </div>
    <hr />
    <div class="input-group">
      <button class="btn btn-primary" type="submit" id="myButton">Submit</button>
      <button class="btn btn-danger" type="reset">Reset</button>
      <?php if($this->session->flashdata('error')) { ?>
        <span class="text-warning h4"><?php echo $this->session->flashdata('error'); ?></span>
      <?php } ?>
    </div>
  </form>
  <!-- <p> <a class="lead" href="<?php echo site_url('signin/register');?>">Register</a> </p> -->
  </div>
</div>

<script>
$(document).ready(function(){
	$('form[role="login"]').validate({
		debug:true,
		errorElement:'label',
		rules:{
			username: {
				required:true,
				rangelength:[10,10]
			},
			password: {
				required:true,
				rangelength:[10,10]
			}
		},
		messages:{
			username: {
				required:'กรุณากรอกชื่อผู้ใช้ด้วย',
				rangelength:'กรุณากรอกข้อมูล 10 ตัวอักษร'
			},
			password: {
				required:'กรุณากรอกรหัสผ่าน',
        rangelength:'กรุณากรอกข้อมูล 10 ตัวอักษร'
			}
		},
		submitHandler: function(form){
      form.submit();
		}
	});
});
</script>
