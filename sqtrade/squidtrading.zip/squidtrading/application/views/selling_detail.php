<div class="row">
  <?php if( ! $sell->sl_ok) { ?>
  <div class="col-md-12 well hidden-print">
    <form role="selling" method="post" action="<?php echo site_url('selling/add_sell'); ?>">
      <legend> บันทึกรายการขาย </legend>
      <div class="form-group">
        <div class="col-md-4">
          <select class="form-control" name="squid">
            <option value="">เลือกรายการปลาหมึก</option>
            <?php foreach($squid as $_s) { ?>
              <option value="<?php echo $_s['sq_id']; ?>"><?php echo $_s['sq_name']; ?></option>
            <?php } ?>
          </select>
        </div>
        <div class="col-md-3">
          <div class="input-group">
            <input type="number" name="weight" class="form-control" placeholder="น้ำหนักที่ขาย" />
            <span class="input-group-addon">กก.</span>
          </div>
        </div>
        <div class="col-md-3">
          <div class="input-group">
            <input type="number" name="price" class="form-control" placeholder="ราคาต่อกิโลกรัม" />
            <span class="input-group-addon">฿</span>
          </div>
        </div>
        <div class="col-md-2">
          <input type="hidden" name="sl_id" value="<?php echo $this->uri->segment(2); ?>" />
          <button class="btn btn-success btn-sm">เพิ่มรายการ</button>
        </div>
      </div>
    </form>
  </div>
  <?php } ?>
  <span class="alert-warning">
	<?php echo ($this->session->flashdata('error') != '') ? $this->session->flashdata('error') : NULL ; ?>
  </span>

  <div class="com-md-12 pull-right">
    <p class="lead">รายการขายที่ : SL-<?php echo isset($sell->sl_id) ? $sell->sl_id : ''; ?></p>
    <p class="lead">วันที่ : <?php echo isset($sell->sl_date) ? $sell->sl_date : ''; ?></p>
    <p class="lead">ผู้ซื้อ : <?php echo isset($sell->mc_name) ? $sell->mc_name : ''; ?></p>
  </div>
  <br />
  <table class="table table-bordered table-hover">
    <thead>
      <tr>
        <th class="text-center">เลขกำกับ</th>
        <th class="text-center" style="width:30%;">รายชื่อสินค้า</th>
        <th class="text-center">น้ำหนักขาย(กิโลกรัม)</th>
        <th class="text-center">ราคาต่อหน่วย(กิโลกรัม)</th>
        <th class="text-center" style="width:30%;">ราคารวม</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($sell_detail as $_sd) { ?>
      <tr>
        <td>PD-<?php echo $_sd['sd_id']; ?></td>
        <td>SQ-<?php foreach($squid as $_s) { if($_sd['sq_id'] == $_s['sq_id']) { echo $_s['sq_name']; } } ?></td>
        <td class="text-center"><?php echo $_sd['sd_weight']; ?></td>
        <td class="text-right"><?php echo $_sd['sd_price']; ?></td>
        <td class="text-right"><?php echo $_sd['sd_sum_price']; ?></td>
        <?php if( ! $sell->sl_ok) { ?>
        <td class="hidden-print">
          <a href="#" data-toggle="modal" data-target="#confirm-delete" data-body="<?php foreach($squid as $_s) { if($_sd['sq_id'] === $_s['sq_id']) { echo $_s['sq_name']; } } ?>" data-href="<?php echo site_url('selling/del_sell').'/'.$_sd['sd_id'].'/'.$_sd['sd_sum_price'].'/'.$_sd['sl_id']; ?>">
            <span class="glyphicon glyphicon-remove"></span>
          </a>
        </td>
        <?php } ?>
      </tr>
      <?php } ?>
    </tbody>
    <tfoot>
      <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td></td>
        <td></td>
        <td></td>
        <th class="text-right">ราคารวมสุทธิ</th>
        <th class="text-right"><?php echo isset($sell->sl_total_price) ? $sell->sl_total_price : ''; ?></th>
      </tr>
      <tr>
        <td></td>
        <td></td>
        <td></td>
        <th class="text-right">ผู้รับผิดชอบ</th>
        <th class="text-right"><?php echo isset($sell->sl_receiver) ? $sell->sl_receiver : ''; ?></th>
      </tr>
    </tfoot>
  </table>

  <div class="hidden-print">
    <hr />
    <?php if( ! $sell->sl_ok) {?>
      <a href="#" class="btn btn-success" data-toggle="modal" data-target="#confirm-delete" data-body="หลังจากยืนยันจะไม่สามารถแก้ไขรายการได้อีก" data-href="<?php echo site_url('selling/add_ok').'/'.$sell->sl_id; ?>">ยืนยันรายการ</a>
    <?php }else{ ?>
      <p>ยืนยันรายการเรียบร้อยแล้ว</p>
    <?php } ?>
    <button class="btn btn-info" onclick="window.print();">สั่งพิมพ์ใบเสร็จ</button>
  </div>
</div>

<script>
$(document).ready(function(){
	$('form[role="selling"]').validate({
		debug:true,
    onkeyup:false,
		errorElement:'label',
		rules:{
			squid: {
				required:true
      },
      weight: {
        required:true
      },
      price: {
        required:true
      }
		},
		messages:{
			squid: {
				required:'เลือกรายชื่อสินค้า'
      },
      weight: {
        required:'ระบุน้ำหนักที่ขาย'
      },
      price: {
        required:'กำหนดราคาต่อกิโลกรัม'
      }
		},
		submitHandler: function(form){
      form.submit();
		}
	});
});
</script>
