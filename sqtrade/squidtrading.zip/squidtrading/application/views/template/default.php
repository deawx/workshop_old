<html>
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>The management system of trading marine port terminal in casestudy squid trading</title>

  <link href="<?php echo base_url('assets/css/bootstrap.min.css');?>" rel="stylesheet">
  <link href="<?php echo base_url('assets/css/bootstrap.datatable.min.css');?>" rel="stylesheet">
  <link href="<?php echo base_url('assets/css/bootstrap.datepicker.min.css');?>" rel="stylesheet">
  <?php if(isset($css)): foreach($css as $_css): ?>
    <link href="<?php echo base_url('assets/css/'.$_css.'.css');?>" rel="stylesheet">
  <?php endforeach; endif; ?>
  <link href="<?php echo base_url('assets/css/main.css');?>" rel="stylesheet">

  <script src="<?php echo base_url('assets/js/jquery-1.11.2.min.js');?>"></script>
  <script src="<?php echo base_url('assets/js/bootstrap.min.js');?>"></script>
  <script src="<?php echo base_url('assets/js/bootstrap.datepicker.min.js');?>"></script>
  <script src="<?php echo base_url('assets/js/bootstrap.datepicker.th.min.js');?>"></script>
  <script src="<?php echo base_url('assets/js/jquery.datatable.min.js');?>"></script>
  <?php if(isset($js)): foreach($js as $_js): ?>
      <script src="<?php echo base_url('assets/js/'.$_js.'.js');?>"></script>
  <?php endforeach; endif; ?>
  <script src="<?php echo base_url('assets/js/main.js');?>"></script>

</head>

<body>

  <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
      </div>
      <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
        <ul class="nav navbar-nav">
          <li <?php if($this->uri->segment(1) === 'home') echo 'class="active"'; ?>>
            <a href="<?php echo site_url('home'); ?>"><i class="glyphicon glyphicon-home"></i></a>
          </li>
          <?php if($this->session->has_userdata('login')) { ?>
		  <li class="dropdown">
		    <a id="dLabel" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			จัดการข้อมูล<span class="caret"></span>
			</a>
			<ul class="dropdown-menu" aria-labelledby="dLabel">
				<li <?php if($this->uri->segment(1) === 'trading_open') echo 'class="active"'; ?>>
				  <a href="<?php echo site_url('trading_open'); ?>">บันทึกการซื้อ</a>
				</li>
				<li <?php if($this->uri->segment(1) === 'selling_open') echo 'class="active"'; ?>>
				  <a href="<?php echo site_url('selling_open'); ?>">บันทึกการขาย</a>
				</li>
				</li>
			</ul>
		  </li>
		  <li class="dropdown">
		    <a id="dLabel" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			จัดการรายการ<span class="caret"></span>
			</a>
			<ul class="dropdown-menu" aria-labelledby="dLabel">
				<li <?php if($this->uri->segment(1) === 'trading') echo 'class="active"'; ?>>
				  <a href="<?php echo site_url('trading'); ?>">รายการซื้อ</a>
				</li>
				<li <?php if($this->uri->segment(1) === 'selling') echo 'class="active"'; ?>>
				  <a href="<?php echo site_url('selling'); ?>">รายการขาย</a>
				<li <?php if($this->uri->segment(1) === 'stock') echo 'class="active"'; ?>>
				  <a href="<?php echo site_url('stock'); ?>">รายการสต็อค</a>
				</li>
				<li <?php if($this->uri->segment(1) === 'register') echo 'class="active"'; ?>>
				  <a href="<?php echo site_url('register'); ?>">รายการลูกค้า</a>
				</li>
			</ul>
		  </li>
            <?php if($this->session->has_userdata('admin')) { ?>
              <li <?php if($this->uri->segment(1) === 'member') echo 'class="active"'; ?>>
                <a href="<?php echo site_url('member'); ?>">สมาชิก</a>
              </li>
              <li <?php if($this->uri->segment(1) === 'merchant') echo 'class="active"'; ?>>
                <a href="<?php echo site_url('merchant'); ?>">พ่อค้าคนกลาง</a>
              </li>
              <li <?php if($this->uri->segment(1) === 'address') echo 'class="active"'; ?>>
                <a href="<?php echo site_url('address'); ?>">ที่อยู่</a>
              </li>
            <?php }else{ ?>
              <li <?php if($this->uri->segment(1) === 'member') echo 'class="active"'; ?>>
                <a href="<?php echo site_url('member').'/'.$this->session->userdata('mb_id'); ?>">สมาชิก</a>
              </li>
            <?php } ?>
          <?php }else{ ?>
            <li <?php if($this->uri->segment(1) === 'login') echo 'class="active"'; ?>><a href="<?php echo site_url('login'); ?>">เข้าสู่ระบบ</a></li>
          <?php } ?>
        </ul>
        <?php if($this->session->has_userdata('login')) { ?>
        <ul class="nav navbar-nav navbar-right">
          <li><p class="navbar-text"><?php echo $this->session->userdata('mb_name'); ?> : กำลังใช้งานระบบ</p></li>
          <li><a href="<?php echo site_url('logout'); ?>"><i class="glyphicon glyphicon-log-out"></i></a></li>
        </ul>
        <?php } ?>
      </div>
    </div>
  </nav>

  <div class="container">
    <?php if(isset($content)): $this->load->view($content); endif; ?>
  </div>

  <div class="container">
    <div class="row">
      <footer>
        <p>
          <?php
          $this->load->helper('file');
          echo read_file('assets/files/address.txt');
          ?>
        </p>
      </footer>
    </div>
  </div>

  <div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header"> </div>
        <div class="modal-body"> </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">ยกเลิก</button>
          <a class="btn btn-danger">ยืนยัน</a>
        </div>
      </div>
    </div>
  </div>

<script type="text/javascript">
$(document).ready(function(){
  $('.datepicker').datepicker({language:'th',format:'dd/mm/yyyy'});
  $('.datatable').DataTable();
});
</script>
</body>
</html>
