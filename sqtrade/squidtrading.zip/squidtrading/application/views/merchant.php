<div class="row">
  <div class="col-md-6">
    <form class="form-horinzontal" role="merchant" method="post" action="<?php if(isset($edit)) { echo site_url('merchant/update_merchant/'.$edit->mc_id); }else{ echo site_url('merchant/regis_merchant'); } ?>">
      <div class="input-group">
        <span class="input-group-addon">
          <span class="glyphicon glyphicon-user"></span>
        </span>
        <input class="form-control" type="text" name="name" <?php if(isset($edit) != ''){ echo 'value="'.explode('&nbsp;',$edit->mc_name)[0].'"'; }else{ echo 'placeholder="ชื่อ"'; } ?> />
        <input class="form-control" type="text" name="lname" <?php if(isset($edit) != ''){ echo 'value="'.explode('&nbsp;',$edit->mc_name)[1].'"'; }else{ echo 'placeholder="นามสกุล"'; } ?> />
      </div>
      <div class="input-group">
        <span class="input-group-addon">
          <span class="glyphicon glyphicon-home"></span>
        </span>
        <textarea rows="3" class="form-control" name="address"><?php if(isset($edit) != ''){ echo $edit->mc_address; } ?></textarea>
      </div>
      <div class="input-group">
        <span class="input-group-addon">
          <span class="glyphicon glyphicon-earphone"></span>
        </span>
        <input class="form-control" type="text" name="phone" <?php if(isset($edit) != ''){ echo 'value="'.$edit->mc_phone.'"'; }else{ echo 'placeholder="081xxxxxxx"'; } ?> />
      </div>
      <hr />
      <div class="input-group">
        <button class="btn btn-primary" type="submit" id="myButton">ยืนยัน</button>
        <button class="btn btn-danger" type="reset">ยกเลิก</button>
      </div>
    </form>
  </div>

  <div class="col-md-6">
    <table class="table table-bordered table-striped datatable">
      <thead>
        <tr>
          <th class="text-center">ที่</th>
          <th class="text-center">ชื่อ-นามสกุล</th>
          <th class="text-center">ที่อยู่</th>
          <th class="text-center">เบอร์โทรศัพท์</th>
          <th class="text-center"></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($merchant as $_k => $_c) { ?>
        <tr>
          <td class="text-center" style="width:5%;"><?php echo $_k+1; ?></td>
          <td>
            <?php if($this->session->has_userdata('admin')) { ?>
            <a href="<?php echo site_url('merchant/'.$_c['mc_id']); ?>">
              <?php echo $_c['mc_name']; ?>
            </a>
            <?php }else{ ?>
              <?php echo $_c['mc_name']; ?>
            <?php } ?>
          </td>
          <td style="width:35%;"><?php echo $_c['mc_address']; ?></td>
          <td class="text-center"><?php echo $_c['mc_phone']; ?></td>
          <td class="text-center">
            <a href="#" data-href="<?php echo site_url('merchant/delete_merchant/'.$_c['mc_id']); ?>" data-toggle="modal" data-target="#confirm-delete" data-body="ยืนยันการลบสมาชิก">
              <i class="glyphicon glyphicon-remove"></i>
            </a>
          </td>
        </tr>
        <?php } ?>
      </tbody>
    </table>
  </div>
</div>

<script>
$(document).ready(function(){
	$('form[role="merchant"]').validate({
		debug:true,
    onkeyup:false,
		errorElement:'label',
		rules:{
			name: {
				required:true,
				rangelength:[1,50]
			},
			lname: {
				required:true,
				rangelength:[1,50]
			},
			address: {
				required:true
			},
			phone: {
				required:true,
        number:true,
        rangelength:[10,10]
			}
		},
		messages:{
			name: {
				required:'กรุณากรอกชื่อ',
				rangelength:'1 ถึง 50 ตัวอักษร'
			},
			lname: {
				required:'กรุณากรอกนามสกุล',
				rangelength:'1 ถึง 50 ตัวอักษร'
			},
      address: {
        required:'กรุณากรอกที่อยู่'
      },
      phone: {
				required:'กรุณากรอกเบอร์โทรศัพท์',
				number:'กรุณากรอกข้อมูลตัวเลข',
        rangelength:'ตัวเลข 10 หลัก'
			}
		},
		submitHandler: function(form){
      form.submit();
		}
	});
});
</script>
