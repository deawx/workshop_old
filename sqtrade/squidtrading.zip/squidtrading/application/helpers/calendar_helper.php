<?php
defined('BASEPATH') OR exit('No direct script access allowed');

if( ! function_exists('months_less')) {

  function months_less($month = FALSE)
  {
    if($month = '')
    {
      return '';
    }
    $month = int($month);
    $months = date('m');
    if($month)
    return $months_less;
  }

}
