<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Selling_open extends CI_Controller {

	protected $data = array(
		'js' => array('jquery.validate.min')
	);

	public function __construct()
	{
		parent::__construct();
		if( ! $this->session->has_userdata('login')) { redirect('login'); }
		$this->load->library('user_agent');
	}

	function index()
	{
		$this->data['sl'] = $this->db->select_max('sl_id')->get('tb_sell')->row();
		$this->data['squid'] = $this->db->get_where('tb_squid','sq_amount > 0')->result_array();
		$this->data['merchant'] = $this->db->get('tb_merchant')->result_array();
		$this->data['content'] = 'selling_open';
		$this->load->view('template/default', $this->data);
	}

	function open_bill($id)
	{
		$p = array(
			'sl_id' => $id,
			'mc_id' => $this->input->post('merchant'),
			'sl_date' => date('Y-m-d'),
			'sl_receiver' => $this->session->userdata('mb_name')
		);
		$this->db->insert('tb_sell',$p);
		redirect('selling/'.$id);
	}

}
