<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Trading_open extends CI_Controller {

	protected $data = array(
		'js' => array('jquery.validate.min')
	);

	public function __construct()
	{
		parent::__construct();
		if( ! $this->session->has_userdata('login')) { redirect('login'); }
		$this->load->library('user_agent');
	}

	function index()
	{
		$this->data['pc'] = $this->db->select_max('pc_id')->get('tb_purchase')->row();
		$this->data['squid'] = $this->db->get('tb_squid')->result_array();
		$this->data['trade'] = $this->db->order_by('pc_ok')->order_by('pc_id','DESC')->get('tb_purchase')->result_array();
		$this->data['customer'] = $this->db->get('tb_customer')->result_array();
		$this->data['content'] = 'trading_open';
		$this->load->view('template/default', $this->data);
	}

	function add_trading()
	{
		$c = array(
			'cs_id' => $this->input->post('customer'),
			'pc_date' => date('Y-m-d'),
			'pc_receiver' => $this->session->userdata('mb_name')
		);
		$this->db->insert('tb_purchase',$c);
		$id = $this->db->insert_id();
		redirect('trading/'.$id);
	}

}
