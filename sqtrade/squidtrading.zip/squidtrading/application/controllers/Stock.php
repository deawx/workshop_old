<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Stock extends CI_Controller {

	protected $data = array();

	protected $months = array(
		"มกราคม","กุมภาพันธ์","มีนาคม","เมษายน","พฤษภาคม","มิถุนายน","กรกฎาคม","สิงหาคม","กันยายน","ตุลาคม","พฤศจิกายน","ธันวาคม"
	);

	public function __construct()
	{
		parent::__construct();
		if( ! $this->session->has_userdata('login')) { redirect('login'); }
	}

	function index()
	{
		$this->data['months'] = $this->months;
		$this->data['squid'] = $this->db->get('tb_squid')->result_array();

		$this->data['purchase'] = $this->db->get_where('tb_purchase',array('pc_ok'=>'1'))->result_array();
		$this->data['purchase_detail'] = $this->db->get('tb_purchase_detail')->result_array();

		$this->data['sell'] = $this->db->get_where('tb_sell',array('sl_ok'=>'1'))->result_array();
		$this->data['sell_detail'] = $this->db->get('tb_sell_detail')->result_array();

		$this->data['stock'] = $this->db->order_by('sq_amount','DESC')->get('tb_squid')->result_array();

		// $this->data['stock'] = $this->db
		// 	->select('sq.sq_name')
		// 	->select_sum('pd.pd_weight')
		// 	->group_by('pd.sq_id')
		// 	->order_by('pd.pd_weight')
		// 	->join('tb_squid as sq','pd.sq_id = sq.sq_id')
		// 	->get('tb_purchase_detail as pd')
		// 	->result_array();

		$this->data['content'] = 'stock';
		$this->load->view('template/default',$this->data);
	}

}
