<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Member extends CI_Controller {

	protected $data = array(
    'js' => array('jquery.validate.min','jquery.additional-methods.min')
  );

	public function __construct()
	{
		parent::__construct();
	}

	function index($id = '')
	{
		if($id)
		{
			$this->data['edit'] = $this->db->get_where('tb_member','mb_id = '.$id)->row();
		}
		$this->data['member'] = $this->db->get('tb_member')->result_array();
		$this->data['content'] = 'member';
		$this->load->view('template/default', $this->data);
	}

	function regis_member()
	{
		$s = array(
			'mb_username' => $this->input->post('username'),
			'mb_password' => $this->input->post('password'),
			'mb_name' => $this->input->post('name').'&nbsp;'.$this->input->post('lname'),
			'mb_address' => $this->input->post('address'),
			'mb_phone' => $this->input->post('phone')
		);
		$this->db->insert('tb_member',$s);
		redirect('member');
	}

	function update_member($id)
	{
		if( ! $id) { redirect('member'); }
		$s = array(
			'mb_username' => $this->input->post('username'),
			'mb_password' => $this->input->post('password'),
			'mb_name' => $this->input->post('name').'&nbsp;'.$this->input->post('lname'),
			'mb_address' => $this->input->post('address'),
			'mb_phone' => $this->input->post('phone')
		);
		$this->db->where('mb_id',$id)->set($s)->update('tb_member');
		redirect('member');
	}

	function delete_member($id)
	{
		if( ! $id) { redirect('member'); }
		$r = $this->db->get_where('tb_member',array('mb_id'=>$id))->row();
		if($r->mb_role === '1') { redirect('member'); }
		$this->db->delete('tb_member','mb_id = '.$id);
		redirect('member');
	}

}
