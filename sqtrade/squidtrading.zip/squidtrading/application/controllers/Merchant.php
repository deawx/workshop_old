<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Merchant extends CI_Controller {

	protected $data = array(
    'js' => array('jquery.validate.min','jquery.additional-methods.min')
  );

	public function __construct()
	{
		parent::__construct();
	}

	function index($id = '')
	{
		if($id)
		{
			$this->data['edit'] = $this->db->get_where('tb_merchant','mc_id = '.$id)->row();
		}
		$this->data['merchant'] = $this->db->get('tb_merchant')->result_array();
		$this->data['content'] = 'merchant';
		$this->load->view('template/default', $this->data);
	}

	function regis_merchant()
	{
		$s = array(
			'mc_name' => $this->input->post('name').'&nbsp;'.$this->input->post('lname'),
			'mc_address' => $this->input->post('address'),
			'mc_phone' => $this->input->post('phone')
		);
		$this->db->insert('tb_merchant',$s);
		redirect('merchant');
	}

	function update_merchant($id)
	{
		if( ! $id) { redirect('merchant'); }
		$s = array(
			'mc_name' => $this->input->post('name').'&nbsp;'.$this->input->post('lname'),
			'mc_address' => $this->input->post('address'),
			'mc_phone' => $this->input->post('phone')
		);
		$this->db->where('mc_id',$id)->set($s)->update('tb_merchant');
		redirect('merchant');
	}

	function delete_merchant($id)
	{
		if( ! $id) { redirect('merchant'); }
		$r = $this->db->get_where('tb_merchant',array('mc_id'=>$id))->row();
		$this->db->delete('tb_merchant','mc_id = '.$id);
		redirect('merchant');
	}

}
