<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Trading extends CI_Controller {

	protected $data = array(
		'js' => array('jquery.validate.min')
	);

	public function __construct()
	{
		parent::__construct();
		if( ! $this->session->has_userdata('login')) { redirect('login'); }
		$this->load->library('user_agent');
	}

	function index($id = FALSE)
	{
		$this->data['squid'] = $this->db->get('tb_squid')->result_array();
		if($id)
		{
			$this->data['trade'] = $this->db->join('tb_customer as cs','cs.cs_id = pc.cs_id')->get_where('tb_purchase as pc',array('pc_id'=>$id))->row();
			$this->data['trade_detail'] = $this->db->get_where('tb_purchase_detail',array('pc_id'=>$id))->result_array();
			$this->data['content'] = 'trading_bill';
			$this->load->view('template/default', $this->data);
		} else {
			$this->data['trade'] = $this->db->order_by('pc_ok')->order_by('pc_id','DESC')->get('tb_purchase')->result_array();
			$this->data['content'] = 'trading';
			$this->load->view('template/default', $this->data);
		}
	}

	function search()
	{
		$s = $this->input->post('search');
		$sc = $this->db->escape_like_str($s);
		$this->data['sl'] = $this->db->select_max('sl_id')->get('tb_sell')->row();
		$this->data['trade'] = $this->db->like('pc_date',$sc,'both')->get('tb_purchase')->result_array();
		$this->data['content'] = 'trading';
		$this->load->view('template/default', $this->data);
	}

	function add_trading()
	{
		$c = array(
			'cs_id' => $this->input->post('customer'),
			'pc_date' => date('Y-m-d'),
			'pc_receiver' => $this->session->userdata('mb_name')
		);
		$this->db->insert('tb_purchase',$c);
		redirect($this->agent->referrer());
	}

	function add_bill()
	{
		$s = array(
			'pc_id' => $this->input->post('pc_id'),
			'sq_id' => $this->input->post('squid'),
			'pd_weight' => $this->input->post('weight'),
			'pd_price' => $this->input->post('price'),
			'pd_sum_price' => $this->input->post('weight')*$this->input->post('price')
		);
		$this->db->insert('tb_purchase_detail',$s);
		$this->db
			->set('pc_total_price','pc_total_price+'.$s['pd_sum_price'],FALSE)
			->where('pc_id',$s['pc_id'])
			->update('tb_purchase');
		redirect($this->agent->referrer());
	}

	function add_ok($id)
	{
		$this->db->update('tb_purchase',array('pc_ok'=>'1'),'pc_id = '.$id);
		$d = $this->db->get_where('tb_purchase_detail',array('pc_id'=>$id))->result_array();
		foreach($d as $_d)
		{
			$this->db
				->set('sq_amount','sq_amount+'.$_d['pd_weight'],FALSE)
				->where('sq_id',$_d['sq_id'])
				->update('tb_squid');
		}
		redirect($this->agent->referrer());
	}

	function add_cancel($id)
	{
		$this->db->update('tb_purchase',array('pc_ok'=>'0'),'pc_id = '.$id);
		$d = $this->db->get_where('tb_purchase_detail',array('pc_id'=>$id))->result_array();
		foreach($d as $_d)
		{
			$this->db
				->set('sq_amount','sq_amount-'.$_d['pd_weight'],FALSE)
				->where('sq_id',$_d['sq_id'])
				->update('tb_squid');
		}
		redirect($this->agent->referrer());
	}

	function del_bill($id,$price,$pid)
	{
		$this->db->delete('tb_purchase_detail',array('pd_id'=>$id));
		$this->db
			->set('pc_total_price','pc_total_price-'.$price,FALSE)
			->where('pc_id',$pid)
			->update('tb_purchase');
		redirect($this->agent->referrer());
	}

	function del_trading($id)
	{
		$this->db->delete('tb_purchase',array('pc_id'=>$id));
		$this->db->delete('tb_purchase_detail',array('pc_id'=>$id));
		redirect('trading');
	}

}
