<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Selling extends CI_Controller {

	protected $data = array(
		'js' => array('jquery.validate.min')
	);

	public function __construct()
	{
		parent::__construct();
		if( ! $this->session->has_userdata('login')) { redirect('login'); }
		$this->load->library('user_agent');
	}

	function index($id = '')
	{
		$this->data['squid'] = $this->db->get_where('tb_squid')->result_array();
		if($id)
		{
			$this->data['sell'] = $this->db->join('tb_merchant as mc','mc.mc_id = sl.mc_id')->get_where('tb_sell as sl','sl.sl_id = '.$id)->row();
			$this->data['sell_detail'] = $this->db->get_where('tb_sell_detail','sl_id = '.$id)->result_array();
			$this->data['content'] = 'selling_detail';
			$this->load->view('template/default', $this->data);
		}
		else
		{
			$this->data['sl'] = $this->db->select_max('sl_id')->get('tb_sell')->row();
			$this->data['sell'] = $this->db->order_by('sl_ok')->order_by('sl_id','DESC')->get('tb_sell')->result_array();
			$this->data['sell_detail'] = $this->db->get('tb_sell_detail')->result_array();
			$this->data['content'] = 'selling';
			$this->load->view('template/default', $this->data);
		}
	}

	function search()
	{
		$s = $this->input->post('search');
    $sc = $this->db->escape_like_str($s);
		$this->data['sl'] = $this->db->select_max('sl_id')->get('tb_sell')->row();
		$this->data['sell'] = $this->db->like('sl_date',$sc,'both')->get('tb_sell')->result_array();
		$this->data['content'] = 'selling';
		$this->load->view('template/default', $this->data);
	}

	function open_bill($id)
	{
		$p = array(
			'sl_id' => $id,
			'mc_id' => $this->input->post('merchant'),
			'sl_date' => date('Y-m-d'),
			'sl_receiver' => $this->session->userdata('mb_name')
		);
		$this->db->insert('tb_sell',$p);
		redirect('selling/'.$id);
	}

	function add_sell()
	{

		$s = array(
			'sl_id' => $this->input->post('sl_id'),
			'sq_id' => $this->input->post('squid'),
			'sd_weight' => $this->input->post('weight'),
			'sd_price' => $this->input->post('price'),
			'sd_sum_price' => $this->input->post('weight')*$this->input->post('price')
		);
		$ck = $this->db
			->select('sq_amount')
			->where('sq_id',$s['sq_id'])
			->get('tb_squid')
			->row();
		if($ck->sq_amount < $s['sd_weight'])
		{
			$this->session->set_flashdata('error','จำนวนในสต็อกคือ'.$ck->sq_amount);
			redirect($this->agent->referrer());
		}
		$sd = $this->db->select_sum('sd_weight')->get_where('tb_sell_detail',array('sl_id'=>$s['sl_id'],'sq_id'=>$s['sq_id']))->row();
		$w = $sd->sd_weight + $s['sd_weight'];
		if($ck->sq_amount < $w)
		{
			$this->session->set_flashdata('error','จำนวนในสต็อกคือ'.$ck->sq_amount);
			redirect($this->agent->referrer());
		}
		$this->db->insert('tb_sell_detail',$s);
		$this->db
			->set('sl_total_price','sl_total_price+'.$s['sd_sum_price'],FALSE)
			->where('sl_id',$s['sl_id'])
			->update('tb_sell');
		redirect($this->agent->referrer());
	}

	function add_ok($id)
	{
		$this->db->update('tb_sell',array('sl_ok'=>'1'),'sl_id = '.$id);
		$d = $this->db->get_where('tb_sell_detail',array('sl_id'=>$id))->result_array();
		foreach($d as $_d)
		{
			$this->db
				->set('sq_amount','sq_amount-'.$_d['sd_weight'],FALSE)
				->where('sq_id',$_d['sq_id'])
				->update('tb_squid');
		}
		redirect($this->agent->referrer());
	}

	function add_cancel($id)
	{
		$this->db->update('tb_sell',array('sl_ok'=>'0'),'sl_id = '.$id);
		$d = $this->db->get_where('tb_sell_detail',array('sl_id'=>$id))->result_array();
		foreach($d as $_d)
		{
			$this->db
				->set('sq_amount','sq_amount+'.$_d['sd_weight'],FALSE)
				->where('sq_id',$_d['sq_id'])
				->update('tb_squid');
		}
		redirect($this->agent->referrer());
	}

	function del_sell($id,$price,$pid)
	{
		$this->db->delete('tb_sell_detail',array('sd_id'=>$id));
		$this->db
			->set('sl_total_price','sl_total_price-'.$price,FALSE)
			->where('sl_id',$pid)
			->update('tb_sell');
		redirect($this->agent->referrer());
	}

	function del_selling($id)
	{
		$this->db->delete('tb_sell',array('sl_id'=>$id));
		$this->db->delete('tb_sell_detail',array('sl_id'=>$id));
		redirect('selling');
	}

}
