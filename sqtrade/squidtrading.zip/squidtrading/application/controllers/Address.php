<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Address extends CI_Controller {

	protected $data = array();

	public function __construct()
	{
		parent::__construct();
		$this->load->helper(['file','form']);
	}

	function index()
	{
		$this->data['content'] = 'address';
		$this->load->view('template/default', $this->data);
	}

	function write_address()
	{
		write_file('assets/files/address.txt',$this->input->post('address'));
		redirect('address');
	}

}
