<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {

	protected $data = array(
    'js' => array('jquery.validate.min','jquery.additional-methods.min')
  );

	public function __construct()
	{
		parent::__construct();
		$this->load->library('user_agent');
	}

	function index()
	{
		$this->data['customer'] = $this->db->get('tb_customer')->result_array();
		$this->data['content'] = 'register';
		$this->load->view('template/default', $this->data);
	}

	function do_regis()
	{
		$s = array(
			'cs_name' => $this->input->post('name').'&nbsp;'.$this->input->post('lname'),
			'cs_address' => $this->input->post('address'),
			'cs_phone' => $this->input->post('phone')
		);
		$this->db->insert('tb_customer',$s);
		redirect($this->agent->referrer());
	}

	function checkName()
	{
		$s = $this->db->get_where('tb_customer',array('cs_name'=>$this->input->post('name')));
		if($s->num_rows() > 0) { echo 'false'; }else{ echo 'true'; }
	}

	function update_regis($id)
	{
		if( ! $id) { redirect('register'); }
		$s = array(
			'cs_name' => $this->input->post('name').'&nbsp;'.$this->input->post('lname'),
			'cs_address' => $this->input->post('address'),
			'cs_phone' => $this->input->post('phone')
		);
		$this->db->where('cs_id',$id)->set($s)->update('tb_customer');
		redirect('register');
	}

	function remove_regis($id)
	{
		if( ! $id) { redirect('register'); }
		$this->db
			->where('cs_id',$id)
			->set('cs_stat','1')
			->update('tb_customer');
	}

}
