<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	protected $data = array();

	public function __construct()
	{
		parent::__construct();
	}

	function index()
	{
		$this->data['squid'] = $this->db->get('tb_squid')->result_array();
		$this->data['content'] = 'home';
		$this->load->view('template/default', $this->data);
	}

}
