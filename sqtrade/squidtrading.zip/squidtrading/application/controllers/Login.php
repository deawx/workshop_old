<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	protected $data = array(
		'js' => array(
			'jquery.validate.min'
		)
	);

	public function __construct()
	{
		parent::__construct();
	}

	function index()
	{
		$this->data['content'] = 'login';
		$this->load->view('template/default', $this->data);
	}

	function do_login()
	{
		$s = array(
			'mb_username' => $this->input->post('username'),
			'mb_password' => $this->input->post('password')
		);
		$c = $this->db->limit(1)->get_where('tb_member',$s);
		if($c->num_rows() > 0 ) {
			$this->session->set_userdata($c->row_array());
			$this->session->set_userdata('login',TRUE);
			$d = $c->row();
			if($d->mb_role === '1')
			{
				$this->session->set_userdata('admin',TRUE);
			}
			redirect('trading_open');
		}else{
			redirect('login');
		}
	}

}
