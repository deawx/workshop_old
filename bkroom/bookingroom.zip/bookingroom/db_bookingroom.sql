-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 12, 2015 at 07:29 PM
-- Server version: 5.6.24
-- PHP Version: 5.5.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_bookingroom`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_agent`
--

CREATE TABLE IF NOT EXISTS `tb_agent` (
  `ag_id` int(5) NOT NULL,
  `ag_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tb_agent`
--

INSERT INTO `tb_agent` (`ag_id`, `ag_name`) VALUES
(1, 'คณะวิศวกรรมศาสตร์'),
(2, 'คณะอุตสาหกรรมและเทคโนโลยี'),
(3, 'คณะบริหารธุรกิจ'),
(4, 'คณะอุตสาหกรรมการโรงแรมและการท่องเที่ยว');

-- --------------------------------------------------------

--
-- Table structure for table `tb_borrow`
--

CREATE TABLE IF NOT EXISTS `tb_borrow` (
  `br_id` int(5) NOT NULL,
  `rs_id` int(5) NOT NULL,
  `dv_id` int(5) NOT NULL,
  `br_amount` int(2) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tb_borrow`
--

INSERT INTO `tb_borrow` (`br_id`, `rs_id`, `dv_id`, `br_amount`) VALUES
(4, 27, 2, 3),
(5, 27, 5, 1),
(8, 29, 1, 1),
(9, 29, 2, 1),
(10, 29, 3, 1),
(11, 29, 4, 1),
(12, 29, 5, 1),
(13, 29, 6, 1),
(14, 65, 3, 1),
(15, 65, 4, 1),
(16, 65, 5, 1),
(17, 66, 3, 1),
(18, 66, 4, 1),
(19, 66, 5, 1),
(20, 66, 6, 1),
(21, 68, 2, 1),
(22, 73, 6, 1),
(23, 73, 7, 1),
(24, 73, 8, 1),
(25, 73, 9, 1),
(26, 74, 4, 1),
(27, 74, 5, 1),
(28, 74, 6, 1),
(29, 74, 7, 1),
(30, 74, 8, 1),
(31, 75, 4, 1),
(32, 75, 5, 1),
(33, 75, 6, 1),
(34, 75, 7, 1),
(35, 77, 6, 1),
(43, 79, 5, 1),
(44, 79, 6, 1),
(45, 79, 7, 1),
(46, 82, 5, 1),
(47, 82, 6, 1),
(48, 83, 5, 1),
(49, 86, 4, 1),
(50, 86, 5, 1),
(51, 86, 6, 1),
(52, 86, 7, 1),
(53, 87, 4, 1),
(54, 87, 5, 1),
(55, 87, 6, 1),
(56, 87, 7, 1),
(57, 88, 4, 1),
(58, 88, 5, 1),
(59, 88, 6, 1),
(60, 88, 8, 1),
(61, 88, 9, 1),
(62, 89, 4, 1),
(63, 89, 5, 1),
(64, 92, 5, 1),
(65, 92, 6, 1),
(66, 92, 7, 1),
(67, 92, 8, 1),
(68, 92, 9, 1),
(69, 92, 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_contact`
--

CREATE TABLE IF NOT EXISTS `tb_contact` (
  `ct_id` int(5) NOT NULL,
  `ct_date` date NOT NULL,
  `ct_detail` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tb_contact`
--

INSERT INTO `tb_contact` (`ct_id`, `ct_date`, `ct_detail`) VALUES
(1, '2015-07-10', '<p>ชื่อ</p>\r\n<p>ที่อยู่</p>\r\n<p>เบอร์โทรศัพท์</p>\r\n<p>อีเมล์</p>\r\n<p>อื่นๆ...</p>\r\n<p>----------</p>\r\n<p><em><strong>เริ่ม.</strong></em></p>');

-- --------------------------------------------------------

--
-- Table structure for table `tb_device`
--

CREATE TABLE IF NOT EXISTS `tb_device` (
  `dv_id` int(5) NOT NULL,
  `dv_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `dt_id` int(5) NOT NULL,
  `dv_detail` text COLLATE utf8_unicode_ci NOT NULL,
  `dv_picture` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `dv_used` int(3) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tb_device`
--

INSERT INTO `tb_device` (`dv_id`, `dv_name`, `dt_id`, `dv_detail`, `dv_picture`, `dv_used`) VALUES
(1, 'จอโปรเจคเตอร์', 2, 'VERTEX ประกอบด้วย\n- ขาตั้ง\n- จอรับแสง\nตัวที่ 1: 2-09-17-0604-006-0003-2-50\nตัวที่ 2: 2-09-17-0604-006-0004-2-50', 'IMG_1413.jpg', 2),
(4, 'ขาตั้งกล้องถ่ายรูป', 1, 'ทำจากเหล็กโครงเสาอาคารน้ำมาเชื่อมติดกันเป็นขารูปทรงสามเหลี่ยม', 'IMG_1421.jpg', 7),
(5, 'Notebook ATEC Vequs 989', 5, 'Notebook ATEC Vequs 989\nประกอบด้วย\n- กระเป๋า 1ใบ\n- Notebook 1 เครื่อง', 'dv1434038346.jpg', 16),
(6, 'ไมโครโฟน (Microphone)', 1, 'ไมโครโฟน แบบไดนามิก\nทิศทางการรับเสียงแบบ คาร์ดิออยด์\nช่วงย่านความถี่ 70 Hz - 15 kHz \nไมค์ชนิดแบบ ไดนามิค\n มีสวิตช์ เปิด(ON)/ปิด(OFF)', 'propic682553170851.jpg', 9),
(7, 'Projector ยี่ห้อ SANYO', 2, 'SANYO XGA PROJECTOR \nประกอบด้วย\n- สายไฟเลี้ยง 2 เส้น\n- สาย VGA 1 เส้น\n- กระเป๋า 1 ใบ', 'IMG_1394.jpg', 11),
(8, 'NPE CF-50DN (ชุดไมโครโฟนประชุมสำหรับผู้ร่วมประชุม)', 3, 'มีสวิตช์เปิด-ปิด และสัญญาณไฟแสดงการทำงานของระบบมีวอลลุ่มควบคุมระดับเสียงพูดและเสียงเตือนสำหรับชุดประชุมแบบแยกอิสระ  มีสวิตช์พิเศษสำหรับกดตัดการทำงานของไมค์เฉพาะชุดประชุมมีช่องต่อสัญญาณ REC และ Phone อย่างละ 1ช่องสามารถต่อชุดร่วมประชุมมากถึง 50 ชุด ', '1356334004.jpg', 5),
(9, 'AUDIOSENSE AS-100 ขาตั้งไมโครโฟน ตั้งโต๊ะ', 1, 'Stand Microphone Table\r\nขาตั้งไมโครโฟนตั้งโต๊ะ แบบข้องอ สีเงิน\r\nพร้อมฐานกลมสีดำ เหล็กหล่อ\r\nพร้อมคอจับไมโครโฟน', 'product1782553143405.jpg', 4),
(10, 'sssss', 2, 'sssss', 'dv1444199438.jpg', 1),
(11, 'n;;;;;;;;;;;;;;', 2, ';;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', 'dv1444670861.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tb_devicetype`
--

CREATE TABLE IF NOT EXISTS `tb_devicetype` (
  `dt_id` int(5) NOT NULL,
  `dt_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tb_devicetype`
--

INSERT INTO `tb_devicetype` (`dt_id`, `dt_name`) VALUES
(1, 'อุปกรณ์เสริม'),
(2, 'โปรเจคเตอร์'),
(3, 'ไมโครโฟน'),
(4, 'สายไฟ'),
(5, 'คอมพิวเตอร์โน็ตบุ๊ค');

-- --------------------------------------------------------

--
-- Table structure for table `tb_member`
--

CREATE TABLE IF NOT EXISTS `tb_member` (
  `mb_id` int(5) NOT NULL,
  `mb_username` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `mb_password` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `mb_fullname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `mb_phone` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `mb_position` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `mb_group` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `ag_id` int(5) NOT NULL,
  `mb_stat` tinyint(1) NOT NULL,
  `mb_role` int(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tb_member`
--

INSERT INTO `tb_member` (`mb_id`, `mb_username`, `mb_password`, `mb_fullname`, `mb_phone`, `mb_position`, `mb_group`, `ag_id`, `mb_stat`, `mb_role`) VALUES
(1, 'admin', 'password', 'ผู้ดูแล&nbsp;คนเดียว', '9990090099', 'ไม่รู้', 'ไม่ทราบ', 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_picture`
--

CREATE TABLE IF NOT EXISTS `tb_picture` (
  `pt_id` int(5) NOT NULL,
  `rm_id` int(5) NOT NULL,
  `pt_thumb` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tb_picture`
--

INSERT INTO `tb_picture` (`pt_id`, `rm_id`, `pt_thumb`) VALUES
(72, 3, '11733485_942317649158414_516338685_n.jpg'),
(73, 3, '11717013_942317912491721_874879317_n.jpg'),
(74, 3, 'IMG_1511.jpg'),
(75, 3, '143750614011759576_947402665316579_763729122_n.jpg.jpg'),
(76, 3, 'IMG_1510.jpg'),
(77, 3, '143749659211751285_947402668649912_878325043_n.jpg.jpg'),
(78, 3, '143749660111759576_947402665316579_763729122_n.jpg.jpg'),
(79, 2, '11721143_942317542491758_800365746_n.jpg'),
(80, 2, '11693055_942317499158429_1498563972_n.jpg'),
(81, 2, '11733229_942317539158425_935785924_n.jpg'),
(83, 2, '11737068_942317475825098_1774193539_n.jpg'),
(84, 2, 'IMG_1439.jpg'),
(85, 2, 'IMG_1448.jpg'),
(86, 2, 'IMG_1455.jpg'),
(87, 1, '11651178_942317409158438_1781183295_n.jpg'),
(88, 1, '11668258_942317379158441_645348777_n.jpg'),
(89, 1, '11717213_942317302491782_1536042054_n.jpg'),
(90, 1, '11719909_942317369158442_132089310_n.jpg'),
(91, 1, '11721808_942317299158449_1406546314_n.jpg'),
(92, 1, '11737143_942317305825115_1986167013_n.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tb_reservation`
--

CREATE TABLE IF NOT EXISTS `tb_reservation` (
  `rs_id` int(5) NOT NULL,
  `mb_id` int(5) NOT NULL,
  `rm_id` int(5) NOT NULL,
  `rs_title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `rs_date` date NOT NULL,
  `rs_time` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `rs_phone` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `rs_stat` int(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_room`
--

CREATE TABLE IF NOT EXISTS `tb_room` (
  `rm_id` int(5) NOT NULL,
  `rm_name` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `rt_id` int(5) NOT NULL,
  `rm_device` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `rm_detail` text COLLATE utf8_unicode_ci NOT NULL,
  `rm_fill` int(4) NOT NULL,
  `rm_used` int(4) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tb_room`
--

INSERT INTO `tb_room` (`rm_id`, `rm_name`, `rt_id`, `rm_device`, `rm_detail`, `rm_fill`, `rm_used`) VALUES
(1, 'ห้องประชุมปกเกล้าราชมงคล', 1, 'จอโปรเจคเตอร์ไมโครโฟน (Microphone)ขาตั้งไมค์AUDIOSENSE AS-100 ขาตั้งไมโครโฟน ตั้งโต๊ะ', 'ตั้งอยู่ภายในอาคารภาควิชาระบบสารสนเทศ', 600, 13),
(2, 'ห้องประชุมรำไพภักดิ์', 2, 'จอโปรเจคเตอร์ไมโครโฟน (Microphone)ขาตั้งไมค์AUDIOSENSE AS-100 ขาตั้งไมโครโฟน ตั้งโต๊ะยังไม่ได้ติดตั้งเลย', 'ตั้งอยู่ชั้น 4 อาคารเอกประสงค์ (บนโรงอาหาร)\nภายในห้องสามารถนั่งและยืนได้', 100, 7),
(3, 'ห้องประชุมVideo Conference', 3, 'จอโปรเจคเตอร์ProjectorNPE CF-50DN (ชุดไมโครโฟนประชุมสำหรับผู้ร่วมประชุม)', 'สามารถใช้ประชุมทางไกลผ่านVideo Conference อย่างทันสมัย', 50, 5);

-- --------------------------------------------------------

--
-- Table structure for table `tb_roomtype`
--

CREATE TABLE IF NOT EXISTS `tb_roomtype` (
  `rt_id` int(5) NOT NULL,
  `rt_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tb_roomtype`
--

INSERT INTO `tb_roomtype` (`rt_id`, `rt_name`) VALUES
(1, 'ห้องประชุมใหญ่'),
(2, 'ห้องประชุมกลาง'),
(3, 'ห้องประชุมเล็ก');

-- --------------------------------------------------------

--
-- Table structure for table `tb_rule`
--

CREATE TABLE IF NOT EXISTS `tb_rule` (
  `rl_id` int(5) NOT NULL,
  `rl_date` date NOT NULL,
  `rl_detail` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tb_rule`
--

INSERT INTO `tb_rule` (`rl_id`, `rl_date`, `rl_detail`) VALUES
(3, '2015-10-13', '<h3 class="MsoNormal" style="margin-bottom: 7.5pt; line-height: 15.0pt; background: white;"><span style="color: #339933; font-family: ''Angsana New'', serif;"><span style="font-size: 18.6667px; line-height: 20px;">คำแนะนำการใช้งานระบบจองห้องประชุมออนไลน์ (จองได้เฉพาะเวลาราชการเท่านั้น)</span></span></h3>\r\n<h3 class="MsoNormal" style="margin-bottom: 7.5pt; line-height: 15.0pt; background: white;"><span style="color: #339933; font-family: ''Angsana New'', serif;"><span style="font-size: 18.6667px; line-height: 20px;">ล็อกอินเข้าสู่ระบบจองห้องประชุมออนไลน์</span></span></h3>\r\n<h3 class="MsoNormal" style="margin-bottom: 7.5pt; line-height: 15.0pt; background: white;"><span style="color: #339933; font-family: ''Angsana New'', serif;"><span style="font-size: 18.6667px; line-height: 20px;">เข้าเมนูการจองห้องประชุม</span></span></h3>\r\n<h3 class="MsoNormal" style="margin-bottom: 7.5pt; line-height: 15.0pt; background: white;"><span style="color: #339933; font-family: ''Angsana New'', serif;"><span style="font-size: 18.6667px; line-height: 20px;">- ระบุห้องประชุม (เลือกรายการ)</span></span></h3>\r\n<h3 class="MsoNormal" style="margin-bottom: 7.5pt; line-height: 15.0pt; background: white;"><span style="color: #339933; font-family: ''Angsana New'', serif;"><span style="font-size: 18.6667px; line-height: 20px;">- ระบุวัน เวลา ที่้ต้องการใช้ พร้อมตรวจสอบรายการห้องประชุมที่เลือก</span></span></h3>\r\n<h3 class="MsoNormal" style="margin-bottom: 7.5pt; line-height: 15.0pt; background: white;"><span style="color: #339933; font-family: ''Angsana New'', serif;"><span style="font-size: 18.6667px; line-height: 20px;">- ระบุจำนวน ผู้เข้าร่วมประชุม</span></span></h3>\r\n<h3 class="MsoNormal" style="margin-bottom: 7.5pt; line-height: 15.0pt; background: white;"><span style="color: #339933; font-family: ''Angsana New'', serif;"><span style="font-size: 18.6667px; line-height: 20px;">- ระบุสิ่งที่ขอสำหรับการใช้ประชุม</span></span></h3>\r\n<h3 class="MsoNormal" style="margin-bottom: 7.5pt; line-height: 15.0pt; background: white;"><span style="color: #339933; font-family: ''Angsana New'', serif;"><span style="font-size: 18.6667px; line-height: 20px;">- ระบุชื่อและเบอร์โทรศัพท์ผู้จอง หรือผู้ที่ติดต่อประสานงาน</span></span></h3>\r\n<h3 class="MsoNormal" style="margin-bottom: 7.5pt; line-height: 15.0pt; background: white;"><span style="color: #339933; font-family: ''Angsana New'', serif;"><span style="font-size: 18.6667px; line-height: 20px;">- ระบุรายละเอียดเพิ่มเติม (ถ้ามี)</span></span></h3>\r\n<h3 class="MsoNormal" style="margin-bottom: 7.5pt; line-height: 15.0pt; background: white;"><span style="color: #339933; font-family: ''Angsana New'', serif;"><span style="font-size: 18.6667px; line-height: 20px;">- กดปุ่มบันทึกข้อมูล</span></span></h3>\r\n<h3 class="MsoNormal" style="margin-bottom: 7.5pt; line-height: 15.0pt; background: white;"><span style="color: #339933; font-family: ''Angsana New'', serif;"><span style="font-size: 18.6667px; line-height: 20px;">พิมพ์รายงานการจอง ส่งกองกลางล่วงหน้าก่อนอย่างน้อย 2 วัน ก่อนวันใช้งานจริง เจ้าหน้าที่ ตรวจสอบเอกสารการจอง เพื่ออนุมัติการจอง ตรวจสอบสถานะการจองห้องประชุม - หากมีข้อความว่า อนุมัติ แสดงว่าการจองห้องประชุม สมบูรณ์ ข้อแนะนำในการใช้ห้องประชุม&nbsp;</span></span></h3>\r\n<h3 class="MsoNormal" style="margin-bottom: 7.5pt; line-height: 15.0pt; background: white;"><span style="color: #339933; font-family: ''Angsana New'', serif;"><span style="font-size: 18.6667px; line-height: 20px;">&nbsp;</span></span></h3>\r\n<h3 class="MsoNormal" style="margin-bottom: 7.5pt; line-height: 15.0pt; background: white;"><span style="color: #339933; font-family: ''Angsana New'', serif;"><span style="font-size: 18.6667px; line-height: 20px;">การจองห้องประชุม ควรจองล่วงหน้าอย่างน้อย 2 วัน ก่อนวันใช้งานจริง&nbsp;</span></span></h3>\r\n<h3 class="MsoNormal" style="margin-bottom: 7.5pt; line-height: 15.0pt; background: white;"><span style="color: #339933; font-family: ''Angsana New'', serif;"><span style="font-size: 18.6667px; line-height: 20px;">กรณียกเลิกการใช้ห้องประชุม ควรยกเลิกก่อน 1 วัน ก่อนวันใช้งานจริง และหากเป็นกรณียกเลิกเร่งด่วน กรุณาแจ้งเจ้าหน้าที่โดยตรงอย่างน้อย 2 ชั่วโมง ก่อนการใช้งานจริง</span></span></h3>');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_agent`
--
ALTER TABLE `tb_agent`
  ADD PRIMARY KEY (`ag_id`);

--
-- Indexes for table `tb_borrow`
--
ALTER TABLE `tb_borrow`
  ADD PRIMARY KEY (`br_id`);

--
-- Indexes for table `tb_contact`
--
ALTER TABLE `tb_contact`
  ADD PRIMARY KEY (`ct_id`);

--
-- Indexes for table `tb_device`
--
ALTER TABLE `tb_device`
  ADD PRIMARY KEY (`dv_id`);

--
-- Indexes for table `tb_devicetype`
--
ALTER TABLE `tb_devicetype`
  ADD PRIMARY KEY (`dt_id`);

--
-- Indexes for table `tb_member`
--
ALTER TABLE `tb_member`
  ADD PRIMARY KEY (`mb_id`);

--
-- Indexes for table `tb_picture`
--
ALTER TABLE `tb_picture`
  ADD PRIMARY KEY (`pt_id`);

--
-- Indexes for table `tb_reservation`
--
ALTER TABLE `tb_reservation`
  ADD PRIMARY KEY (`rs_id`);

--
-- Indexes for table `tb_room`
--
ALTER TABLE `tb_room`
  ADD PRIMARY KEY (`rm_id`);

--
-- Indexes for table `tb_roomtype`
--
ALTER TABLE `tb_roomtype`
  ADD PRIMARY KEY (`rt_id`);

--
-- Indexes for table `tb_rule`
--
ALTER TABLE `tb_rule`
  ADD PRIMARY KEY (`rl_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_agent`
--
ALTER TABLE `tb_agent`
  MODIFY `ag_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tb_borrow`
--
ALTER TABLE `tb_borrow`
  MODIFY `br_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=70;
--
-- AUTO_INCREMENT for table `tb_contact`
--
ALTER TABLE `tb_contact`
  MODIFY `ct_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tb_device`
--
ALTER TABLE `tb_device`
  MODIFY `dv_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `tb_devicetype`
--
ALTER TABLE `tb_devicetype`
  MODIFY `dt_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tb_member`
--
ALTER TABLE `tb_member`
  MODIFY `mb_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tb_picture`
--
ALTER TABLE `tb_picture`
  MODIFY `pt_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=93;
--
-- AUTO_INCREMENT for table `tb_reservation`
--
ALTER TABLE `tb_reservation`
  MODIFY `rs_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=94;
--
-- AUTO_INCREMENT for table `tb_room`
--
ALTER TABLE `tb_room`
  MODIFY `rm_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tb_roomtype`
--
ALTER TABLE `tb_roomtype`
  MODIFY `rt_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tb_rule`
--
ALTER TABLE `tb_rule`
  MODIFY `rl_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
