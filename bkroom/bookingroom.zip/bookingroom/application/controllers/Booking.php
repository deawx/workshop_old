<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Booking extends CI_Controller {

  protected $data = array(
    'js' => array('jquery.validate.min')
  );

  public function __construct()
  {
    parent::__construct();
    if( ! $this->session->userdata('admin')) { redirect('login'); }
  }

  public function index($id = '')
  {
    if($id)
    {
      $this->data['booking'] = $this->db
        ->join('tb_room as rm','rs.rm_id = rm.rm_id')
        ->join('tb_member as mb','rs.mb_id = mb.mb_id')
        ->where('rs.rs_id',$id)
        ->get('tb_reservation as rs')->row();
      $this->data['device'] = $this->db
        ->join('tb_device as dv','dv.dv_id = br.dv_id')
        ->get_where('tb_borrow as br',array('br.rs_id'=>$id))
        ->result_array();
      $this->data['content'] = 'admin/booking_detail';
    }else{
      $this->data['member'] = $this->db->get('tb_member')->result_array();
      $this->data['device'] = $this->db->get('tb_device')->result_array();
      $this->data['room'] = $this->db->join('tb_roomtype as rt','rt.rt_id = rm.rt_id')->get('tb_room as rm')->result_array();
      $this->data['booking'] = $this->db->order_by('rs.rs_stat','ASC')->order_by('rs.rs_date','DESC')->join('tb_member as mb','mb.mb_id = rs.mb_id')->get('tb_reservation as rs')->result_array();
      $this->data['content'] = 'admin/booking';
    }
    $this->load->view('template/back',$this->data);
  }

  function add_booking()
  {
    $e = array(
      'mb_id' => $this->input->post('mb_id'),
      'rm_id' => $this->input->post('room'),
      'rs_title' => $this->input->post('title'),
      'rs_date' => $this->input->post('date'),
      'rs_time' => $this->input->post('time'),
      'rs_phone' => $this->input->post('phone')
    );
    $this->db->insert('tb_reservation',$e);

    $rs_id = $this->db->insert_id();

    $device = ($this->input->post('device')) ? $this->input->post('device') : array();
    $devicenum = ($this->input->post('devicenum')) ? $this->input->post('devicenum') : array();
    foreach($device as $_k => $_v)
    {
      $d = array(
        'rs_id' => $rs_id,
        'dv_id' => $_v,
        'br_amount' => $devicenum[$_k]
      );
      // echo '<pre>'; print_r($d);
      $this->db->insert('tb_borrow',$d);
      $this->db->set('dv_used','dv_used+1',FALSE)->where('dv_id',$_v)->update('tb_device');
    }
    $this->session->set_flashdata('error','การทำงานเสร็จสิ้น'); redirect($this->agent->referrer());
  }

  function give_booking($id,$room,$date,$time)
  {
    switch ($time) {
      case '1':
        $s = $this->db
          ->where('rm_id',$room)
          ->where('rs_date',$date)
          ->where('rs_stat','1')
          ->where_in('rs_time',array('8:30-12:00','8:30-16:00'))
          ->get('tb_reservation');
        break;
      case '2':
        $s = $this->db
          ->where('rm_id',$room)
          ->where('rs_date',$date)
          ->where('rs_stat','1')
          ->where_in('rs_time',array('13:00-16:00','8:30-16:00'))
          ->get('tb_reservation');
        break;
      case '3':
        $s = $this->db
          ->where('rm_id',$room)
          ->where('rs_date',$date)
          ->where('rs_stat','1')
          ->get('tb_reservation');
        break;
    }
    if($s->num_rows() > 0)
    {
      $this->session->set_flashdata('error','การจองห้องประชุมทับซ้อน ไม่สามารถทำรายการได้');
      redirect($this->agent->referrer());
    }else{
      $this->db->update('tb_reservation',array('rs_stat'=>'1'),array('rs_id'=>$id));
      $this->db->set('rm_used','rm_used+1',FALSE)->where('rm_id',$room)->update('tb_room');
      $this->session->set_flashdata('error','การทำงานเสร็จสิ้น');
      redirect($this->agent->referrer());
    }
  }

  function del_booking($id)
  {
    $this->db->delete('tb_reservation',array('rs_id'=>$id));
    $this->db->delete('tb_borrow',array('rs_id'=>$id));
    $this->session->set_flashdata('error','การทำงานเสร็จสิ้น');
    redirect('booking');
  }

}
