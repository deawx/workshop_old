<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Contact extends CI_Controller {

  protected $data = array(
    'js' => array('tinymce.min')
  );

  public function __construct()
  {
    parent::__construct();
    if( ! $this->session->userdata('admin')) { redirect('login'); }
  }

  public function index()
  {
    $this->data['contact'] = $this->db->get('tb_contact')->row();
    $this->data['content'] = 'admin/contact';
    $this->load->view('template/back',$this->data);
  }

  function add_contact()
  {
    $m = array(
      'ct_date' => date('Y-m-d'),
      'ct_detail' => $this->input->post('detail')
    );
    $this->db->insert('tb_contact',$m);
    $this->session->set_flashdata('error','บันทึกข้อมูลเสร็จสิ้น');
    redirect('contact');
  }

  function update_contact($id)
  {
    if( ! $id) { redirect('contact'); }
    $m = array(
      'ct_date' => date('Y-m-d'),
      'ct_detail' => $this->input->post('detail')
    );
    $this->db->update('tb_contact',$m,'ct_id = '.$id);
    $this->session->set_flashdata('error','บันทึกข้อมูลเสร็จสิ้น');
    redirect('contact');
  }

}
