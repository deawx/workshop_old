<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event extends CI_Controller {

  protected $data = array(
    'js' => array('jquery.validate.min')
  );

  public function __construct()
  {
    parent::__construct();
    if($this->session->has_userdata('login') === FALSE) { redirect('home'); }
  }

  public function index($day = '')
  {
    $day = $this->input->post('date');
    if($day)
    {
      $this->data['search'] = $this->db->like('rs_date',$day)->join('tb_room as rm','rm.rm_id = rs.rm_id')->get_where('tb_reservation as rs',array('rs_stat'=>'1'))->result_array();
    }else{
      $this->data['search'] = '';
    }
    $this->data['device'] = $this->db->get('tb_device')->result_array();
    $this->data['room'] = $this->db->join('tb_roomtype as rt','rt.rt_id = rm.rt_id')->get('tb_room as rm')->result_array();
    $this->data['reserve'] = $this->db->like('rs_date',date('Y-m'))->join('tb_room as rm','rm.rm_id = rs.rm_id')->get_where('tb_reservation as rs',array('rs_stat'=>'1'))->result_array();
    $this->data['content'] = 'event';
    $this->load->view('template/front',$this->data);
  }

  function add_event()
  {
    $date = date('Y-m-d'); if($this->input->post('date') <= $date) { $this->session->set_flashdata('error','การกำหนดวันที่ไม่ถูกต้อง'); redirect($this->agent->referrer()); }
    $e = array(
      'mb_id' => $this->input->post('fullname'),
      'rm_id' => $this->input->post('room'),
      'rs_title' => $this->input->post('title'),
      'rs_date' => $this->input->post('date'),
      'rs_time' => $this->input->post('time'),
      'rs_phone' => $this->input->post('phone')
    );
    $this->db->insert('tb_reservation',$e);
    $rs_id = $this->db->insert_id();
    $device = ($this->input->post('device')) ? $this->input->post('device') : array();
    $devicenum = ($this->input->post('devicenum')) ? $this->input->post('devicenum') : array();
    foreach($device as $_k => $_v)
    {
      $d = array(
        'rs_id' => $rs_id,
        'dv_id' => $_v,
        'br_amount' => $devicenum[$_k]
      );
      $this->db->insert('tb_borrow',$d);
    }
    $exist = $this->db
      ->where('rs_date',$this->input->post('date'))
      ->where('rs_time',$this->input->post('time'))
      ->where('rm_id',$this->input->post('room'))
      ->get('tb_reservation');
    if($exist->num_rows() > 1)
    {
      $this->session->set_flashdata('error','การทำงานเสร็จสิ้น รอการยืนยันจากผู้ดูแลระบบ | หมายเหตุ : พบรายการจองห้องประชุมในวันและเวลาเดียวกัน'); redirect($this->agent->referrer());
    }
    else
    {
      $this->session->set_flashdata('error','การทำงานเสร็จสิ้น รอการยืนยันจากผู้ดูแลระบบ'); redirect($this->agent->referrer());
    }
  }

}
