<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Member extends CI_Controller {

  protected $data = array(
    'js' => array('jquery.validate.min','jquery.additional-methods.min')
  );

  public function __construct()
  {
    parent::__construct();
    if( ! $this->session->userdata('login')) { redirect('login'); }
  }

  public function index($id)
  {
    if( ! $id) { redirect('member'); }
    $this->data['member'] = $this->db->get_where('tb_member','mb_id = '.$id)->row();
    $this->data['agent'] = $this->db->get('tb_agent')->result_array();
    $this->data['content'] = 'member';
    $this->load->view('template/front',$this->data);
  }

  function update_member($id)
  {
    if( ! $id) { redirect('member'); }
    $s = array(
      // 'mb_username' => $this->input->post('username'),
      // 'mb_password' => $this->input->post('password'),
      'mb_fullname' => $this->input->post('name').'&nbsp;'.$this->input->post('lastname'),
      'mb_phone' => $this->input->post('phone'),
      'mb_position' => $this->input->post('position'),
      'mb_group' => $this->input->post('group'),
      'ag_id' => $this->input->post('agent')
    );
    $this->db->update('tb_member',$s,'mb_id ='.$id);
    $this->session->sess_destroy();
    $this->session->set_flashdata('error','การแก้ไขข้อมูลเสร็จสิ้น กรุณาล็อกอินใหม่อีกครั้ง');
    redirect('login');
  }

  // function check_name()
  // {
  //   $s = $this->db->get_where('tb_member',array('mb_username'=>$this->input->post('username')));
  //   if($s->num_rows() > 0) { echo 'false'; }else{ echo 'true'; }
  // }

  // function check_password()
  // {
  //   $s = $this->db->get_where('tb_member',array('mb_username'=>$this->input->post('username'),'mb_password'=>$this->input->post('oldpassword')));
  //   if($s->num_rows() > 0) { echo 'true'; }else{ echo 'false'; }
  // }

}
