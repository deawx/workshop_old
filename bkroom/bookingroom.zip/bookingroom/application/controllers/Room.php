<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Room extends CI_Controller {

  protected $data = array(
    'js' => array(
      'jquery.validate.min',
      'jquery.additional-methods.min'
      )
  );

  public function __construct()
  {
    parent::__construct();
    if( ! $this->session->userdata('admin')) { redirect('login'); }
  }

  public function index($id = '')
  {
    $this->data['roomtype'] = $this->db->get('tb_roomtype')->result_array();
    if($id)
    {
      $this->data['picture'] = $this->db->get_where('tb_picture',array('rm_id'=>$id))->result_array();
      $this->data['room'] = $this->db->get_where('tb_room',array('rm_id'=>$id))->row();
      $this->data['content'] = 'admin/room_detail';
    }
    else
    {
      $this->data['room'] = $this->db->join('tb_roomtype as rt','rt.rt_id = rm.rt_id')->get('tb_room as rm')->result_array();
      $this->data['content'] = 'admin/room';
    }
    $this->load->view('template/back',$this->data);
  }

  function add_room()
  {
    // if($_FILES['picture']['name'])
    // {
    //   $config['upload_path'] = APPPATH.'../uploads/room/';
    //   $config['allowed_types'] = 'jpeg|jpg';
    //   $config['file_ext_tolower'] = TRUE;
    //   $config['file_name'] = 'rm'.time();
    //   $this->load->library('upload');
    //   $this->upload->initialize($config);
    //   if ($this->upload->do_upload('picture'))
    //   {
        $f = array(
          'rm_name' => $this->input->post('name'),
          'rt_id' => $this->input->post('type'),
          'rm_device' => trim($this->input->post('device')),
          'rm_detail' => trim($this->input->post('detail')),
          'rm_fill' => (int)$this->input->post('fill')
          // 'rm_picture' => $config['file_name'].'.jpg'
        );
        $this->db->insert('tb_room',$f);
        $this->session->set_flashdata('error','เพิ่มข้อมูลเสร็จสิ้น');
        redirect('room');
    //   }
    //   else
    //   {
    //     $this->session->set_flashdata('error',$this->upload->display_errors());
    //     redirect($this->agent->referrer());
    //   }
    // }
  }

  function update_room_picture($id)
  {
    if( ! $id) { $this->session->set_flashdata('error','พบการทำงานผิดพลาด กรุณาลองใหม่อีกครั้ง'); redirect($this->agent->referrer()); }
    if($_FILES['picture']['name'][0])
    {
      $files = $_FILES['picture'];
      foreach($files['name'] as $_filenum => $_filename)
      {
        $allowed = array('jpeg','jpg','png','bmp');
        $file_tmp = $files['tmp_name'][$_filenum];
        $file_size = $files['size'][$_filenum];
        $file_error = $files['error'][$_filenum];

        $file_ext = explode('.',$_filename);
        $file_ext = strtolower(end($file_ext));
        if(in_array($file_ext,$allowed))
        {
          if($file_error === 0)
          {
            if($file_size <= 1000000)
            {
              $file_newname = time().$_filename.'.'.$file_ext;
              $file_path = APPPATH.'../uploads/room/'.$file_newname;
              if(move_uploaded_file($file_tmp,$file_path))
              {
                $p = array(
                  'rm_id' => $id,
                  'pt_thumb' => $file_newname
                );
                $this->db->insert('tb_picture',$p);
                $this->session->set_flashdata('error','การอัพโหลดไฟล์เสร็จสิ้น');
              }
              else
              {
                $this->session->set_flashdata('error', $_filename[$_filenum].'ไม่สามารถอัพโหลดไฟล์ได้');
                redirect($this->agent->referrer());
              }
            }
            else
            {
              $this->session->set_flashdata('error', $_filename[$_filenum].'ขนาดของไฟล์เกินจำนวน 1000000kb');
              redirect($this->agent->referrer());
            }
          }
          else
          {
            $this->session->set_flashdata('error', $_filename[$_filenum].'พบการทำงานผิดพลาด');
            redirect($this->agent->referrer());
          }
        }
        else
        {
          $this->session->set_flashdata('error', $_filename[$_filenum].'ชนิดของไฟล์ไม่ถูกต้อง');
          redirect($this->agent->referrer());
        }
      }
      redirect($this->agent->referrer());
    }
    else
    {
      redirect($this->agent->referrer());
    }
    redirect($this->agent->referrer());
  }

  function update_room($id)
  {
    $f = array(
      'rm_name' => $this->input->post('name'),
      'rt_id' => $this->input->post('type'),
      'rm_device' => trim($this->input->post('device')),
      'rm_detail' => trim($this->input->post('detail')),
      'rm_fill' => (int)$this->input->post('fill')
    );
    $this->db->update('tb_room',$f,array('rm_id'=>$id));
    $this->session->set_flashdata('error','การแก้ไขข้อมูลเสร็จสิ้น');
    redirect($this->agent->referrer());
  }

  function add_roomtype()
  {
    $this->db->insert('tb_roomtype',array('rt_name'=>$this->input->post('name')));
    if( ! $id) { $this->session->set_flashdata('error','เพิ่มข้อมูลเสร็จสิ้น'); }
    redirect('room');
  }

  function del_roomtype($id)
  {
    $t = $this->db
      ->join('tb_room as rm','rm.rm_id = rs.rm_id')
      ->join('tb_roomtype as rt','rt.rt_id = rm.rt_id')
      ->where('rm.rt_id',$id)
      ->get('tb_reservation as rs');
    if($t->num_rows() > 0)
    {
      $this->session->set_flashdata('error','พบการใช้งานในระบบ ไม่สามารถลบข้อมูล');
      redirect($this->agent->referrer());
    }else{
      $this->db->delete('tb_roomtype','rt_id ='.$id);
      redirect('room');
    }
  }

  function del_room($id)
  {
    $t = $this->db
      ->join('tb_room as rm','rm.rm_id = rs.rm_id')
      ->where('rm.rm_id',$id)
      ->get('tb_reservation as rs');
    if($t->num_rows() > 0)
    {
      $this->session->set_flashdata('error','พบการใช้งานในระบบ ไม่สามารถลบข้อมูล');
      redirect('room');
    }else{
      $thumb = $this->db->get_where('tb_picture',array('rm_id'=>$id));
      if($thumb->num_rows() > 0)
      {
        $thumb = $thumb->result_array();
        foreach($thumb as $_t)
        {
          $file_path = APPPATH.'../uploads/room/'.$_t['pt_thumb'];
          unlink($file_path);
          $this->db->delete('tb_picture','rm_id ='.$id);
        }
      }
      $this->db->delete('tb_room','rm_id ='.$id);
      $this->session->set_flashdata('error','การทำงานเสร็จสิ้น');
      redirect('room');
    }
  }

  function del_picture($thumb,$id)
  {
    if( ! $id && ! $thumb) { redirect($this->agent->referrer()); }
    $file_path = APPPATH.'../uploads/room/'.$thumb;
    unlink($file_path);
    $this->db->delete('tb_picture','pt_id = '.$id);
    $this->session->set_flashdata('error','การทำงานเสร็จสิ้น');
    redirect($this->agent->referrer());
  }

}
