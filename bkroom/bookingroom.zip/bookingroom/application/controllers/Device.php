<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Device extends CI_Controller {

  protected $data = array(
    'js' => array('jquery.validate.min','jquery.additional-methods.min')
  );

  public function __construct()
  {
    parent::__construct();
    if( ! $this->session->userdata('admin')) { redirect('login'); }
  }

  public function index($id = '')
  {
    $this->data['devicetype'] = $this->db->get('tb_devicetype')->result_array();
    $this->data['device'] = $this->db->join('tb_devicetype as dt','dt.dt_id = dv.dt_id')->get('tb_device as dv')->result_array();
    if($id)
    {
      $this->data['device_detail'] = $this->db->get_where('tb_device',array('dv_id'=>$id))->row();
      $this->data['content'] = 'admin/device_detail';
    }else{
      $this->data['content'] = 'admin/device';
    }
    $this->load->view('template/back',$this->data);
  }

  function add_device()
  {
    if($_FILES['picture']['name'])
    {
      $config['upload_path'] = APPPATH.'../uploads/device/';
      $config['allowed_types'] = 'jpeg|jpg';
      $config['file_ext_tolower'] = TRUE;
      $config['file_name'] = 'dv'.time();
      $this->load->library('upload');
      $this->upload->initialize($config);
      if ($this->upload->do_upload('picture'))
      {
        $d = array(
          'dv_name' => $this->input->post('name'),
          'dt_id' => $this->input->post('type'),
          'dv_detail' => $this->input->post('detail'),
          'dv_picture' => $config['file_name'].'.jpg'
        );
        $this->db->insert('tb_device',$d);
        redirect('device');
      }
      else
      {
        $this->session->set_flashdata('error',$this->upload->display_errors());
        redirect($this->agent->referrer());
      }
    }
  }

  function update_device()
  {
    $id = ($this->input->post('id')) ? $this->input->post('id') : '';
    $picturename = ($this->input->post('picturename')) ? $this->input->post('picturename') : 'dv'.time().'.jpg';
    if($_FILES['picture']['name'])
    {
      $config['upload_path'] = APPPATH.'../uploads/device/';
      $config['allowed_types'] = 'jpeg|jpg';
      $config['file_ext_tolower'] = TRUE;
      $config['file_name'] = $picturename;
      $config['overwrite'] = TRUE;
      $this->load->library('upload');
      $this->upload->initialize($config);
      if ($this->upload->do_upload('picture'))
      {
        $d = array(
          'dv_name' => $this->input->post('name'),
          'dt_id' => $this->input->post('type'),
          'dv_detail' => $this->input->post('detail'),
          'dv_picture' => $config['file_name']
        );
        $this->db->update('tb_device',$d,array('dv_id'=>$id));
        $this->session->set_flashdata('error','อัพเดทข้อมูลเสร็จสิ้น');
        redirect('device');
      }
      else
      {
        $this->session->set_flashdata('error',$this->upload->display_errors());
        redirect($this->agent->referrer());
      }
    }
    else
    {
      $d = array(
        'dv_name' => $this->input->post('name'),
        'dt_id' => $this->input->post('type'),
        'dv_detail' => $this->input->post('detail')
      );
      $this->db->update('tb_device',$d,array('dv_id'=>$id));
      $this->session->set_flashdata('error','อัพเดทข้อมูลเสร็จสิ้น');
      redirect('device');
    }
  }

  function add_devicetype()
  {
    $name = $this->input->post('name');
    $c = $this->db->get_where('tb_devicetype',array('dt_name'=>$name));
    if($c->num_rows() > 0)
    {
      $this->session->set_flashdata('error','พบรายการซ้ำในฐานข้อมูล');
      redirect($this->agent->referrer());
    }
    else
    {
      $this->db->insert('tb_devicetype',array('dt_name'=>$name));
      $this->session->set_flashdata('error','เพิ่มข้อมูลเสร็จสิ้น');
      redirect('device');
    }
  }

  function del_devicetype($id)
  {
    $t = $this->db->where('dv.dt_id',$id)->get('tb_device as dv');
    if($t->num_rows() > 0)
    {
      $this->session->set_flashdata('error','พบการใช้งานในระบบ ไม่สามารถลบข้อมูล');
      redirect($this->agent->referrer());
    }else{
      $this->db->delete('tb_devicetype','dt_id ='.$id);
      $this->session->set_flashdata('error','ลบข้อมูลเสร็จสิ้น');
      redirect('device');
    }
  }

  function del_device($id)
  {
    $d = $this->db->get_where('tb_borrow',array('dv_id'=>$id));
    if($d->num_rows() > 0)
    {
      $this->session->set_flashdata('error','พบการใช้งานในระบบ ไม่สามารถลบข้อมูล');
      redirect($this->agent->referrer());
    }else{
      $this->db->delete('tb_device','dv_id ='.$id);
      $this->session->set_flashdata('error','ลบข้อมูลเสร็จสิ้น');
      redirect('device');
    }
  }

}
