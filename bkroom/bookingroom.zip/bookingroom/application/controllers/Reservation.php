<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Reservation extends CI_Controller {

    protected $data = array();

    public function __construct() {
        parent::__construct();
    }

    public function index($year = '', $month = '') {
        $year = ($this->uri->segment(2)) ? $this->uri->segment(2) : date('Y');
        $month = ($this->uri->segment(3)) ? $this->uri->segment(3) : date('m');
        $events = $this->db->select('rs_date,rs_stat')->like('rs_date', "$year-$month", 'after')/* ->where('rs_stat','1') */->get('tb_reservation')->result_array();
        $link = array();
        $con = array();
//                    $c =($_e['rs_stat']==1)?'<p class="show">อนุมัติแล้ว</p> ': '<p class="show">มีการจอง</p>';

        foreach ($events as $_e) {
            $d = (int) explode('-', $_e['rs_date'])[2];
            $link[$d] = ($_e['rs_stat'] == 1) ? '<p class="show" id="textSuccss">อนุมัติแล้ว</p> ' : '<p class="show"><img src="' . base_url("assets/img/listjong.png") . '"></p><p id="textWait">รออนุมัติ</p>';
//            $c = ($_e['rs_stat']==1)?'<p class="show">อนุมัติแล้ว</p> ': '<p class="show">มีการจอง</p>';
//           $con[$d] = $c ;
        }
        $conf = array(
            'start_day' => 'sunday',
            'month_type' => 'long',
            'show_next_prev' => TRUE,
            'next_prev_url' => site_url('reservation'),
            'template' => '
        {table_open}<table class="table calendar bartitle"  border="0" cellpadding="0" cellspacing="0">{/table_open}
        {heading_row_start}<tr>{/heading_row_start}
        {heading_previous_cell}<th class="text-center"><a href="{previous_url}">&lt;&lt;</a></th>{/heading_previous_cell}
        {heading_title_cell}<th class="text-center h4 well" colspan="{colspan}">{heading}</th>{/heading_title_cell}
        {heading_next_cell}<th class="text-center"><a href="{next_url}">&gt;&gt;</a></th>{/heading_next_cell}
        {heading_row_end}</tr>{/heading_row_end}
        {week_row_start}<tr>{/week_row_start}
        {week_day_cell}<td class="text-center well">{week_day}</td>{/week_day_cell}
        {week_row_end}</tr>{/week_row_end}

        {cal_row_start}<tr class="days">{/cal_row_start}
        {cal_cell_start}<td class="day">{/cal_cell_start}
        {cal_cell_start_today}<td>{/cal_cell_start_today}
        {cal_cell_start_other}<td class="other-month">{/cal_cell_start_other}

        {cal_cell_content}<div class="day_num day_use" data-toggle="tooltip">{day}</div>{content}{/cal_cell_content}


        {cal_cell_content_today}<div class="day_num day_use hightlight">{day}</div><p class="show"></p>{/cal_cell_content_today}
        {cal_cell_no_content}<div class="day_num">{day}</div>{/cal_cell_no_content}
        {cal_cell_no_content_today}<div class="day_num hightlight">{day}</div>{/cal_cell_no_content_today}

        {cal_cell_blank}&nbsp;{/cal_cell_blank}
        {cal_cell_other}{day}{cal_cel_other}
        {cal_cell_end}</td>{/cal_cell_end}
        {cal_cell_end_today}</td>{/cal_cell_end_today}
        {cal_cell_end_other}</td>{/cal_cell_end_other}
        {cal_row_end}</tr>{/cal_row_end}
        {table_close}</table>{/table_close} '
        );


//    มันขึ้นแบบนี้ แต่หนูอยากให้ขึ้นคำว่า อนุมัติ
//กับมีรายการจอง
//
//    ตารางชื่อ tb_reservation
//ข้อมูลที่เก็บคือ
//mb_id ไอดีของผู้จอง
//rs_title หัวเรื่อง
//date , time , phone ตรงตัวเลย
//แล้วก็ rs_stat ระบุสถานะว่า 1 = ผ่านการอนุมัติ

        $this->load->library('calendar', $conf);
        $this->data['calendar'] = $this->calendar->generate($year, $month, $link, $con);
        $this->data['reserve'] = $this->db->join('tb_room as rm', 'rm.rm_id = rs.rm_id')->get_where('tb_reservation as rs', array('rs.rs_date' => date('Y-m-d'), 'rs.rs_stat !=' => '0'))->result_array();
//        echo "<pre>";
//        var_dump($this->data['reserve']);
//        die();
        $this->data['content'] = 'reservation';
        $this->load->view('template/front', $this->data);
    }

    function show_detail() {
        $d = $this->input->post('d');
        $m = $this->input->post('m');
        $y = $this->input->post('y');
        $rs = $this->db
                ->select('mb.mb_fullname,rs.rs_id,rs.rs_title,rm.rm_name,rs.rs_stat')
                ->join('tb_member as mb', 'mb.mb_id = rs.mb_id')
                ->join('tb_room as rm', 'rm.rm_id = rs.rm_id')
                ->get_where('tb_reservation as rs', array('rs.rs_date' => $y . '-' . $m . '-' . $d));
        // ->get_where('tb_reservation as rs',array('rs.rs_date'=>$y.'-'.$m.'-'.$d,'rs.rs_stat'=>'1'));
        if ($rs->num_rows() > 0) {
            $txt = $rs->result_array();
            foreach ($txt as $_t) {
                $tb = "
          <table class='table table-hover'>
            <tr>
              <td class='text-left' style='width:40%;'>" . $_t['rs_title'] . "</td>
              <td class='text-left' style='width:30%;'>" . $_t['rm_name'] . "</td>
              <td class='text-left' style='width:20%;'>" . $_t['mb_fullname'] . "</td>
              <td class='text-center' style='width:10%;'>
          ";
                if ($_t['rs_stat'] === '1') {
                    $tb .= "
                <a class='btn btn-default' target='_blank' href='" . site_url('reservation/print_detail') . '/' . $_t['rs_id'] . "'>
                  <i class='glyphicon glyphicon-print'></i>
                </a>
          ";
                }
                $tb .= "
              </td>
            </tr>
          </table>
        ";
                echo $tb;
            }
        } else {


            $rs = $this->db
                    ->select('*')
                    ->get('tb_room');
            $data['option_array'] = $rs->result_array();
            $data['rs_date']=  $y . '-' . $m . '-' . $d;
//            $tb = '
//            <form name="form_submit" id ="form_submit">
//            <input name="rs_date" type="hidden" value="'.$rs_date.'">
//             <div>
//             <div class="form-group">
//             <label for="exampleInputEmail1">ขอบเขตเวลา:</label>
//                <select class="form-control" name ="timeSet">
//                <option value="8:30-12:00">8:30-12:00</option>
//                <option value="13:00-16:00">13:00-16:00</option>
//                <option value="8:30-16:00">8:30-16:00</option>
//                </select>
//              </div>
//
//
//              </div>
//              <div class="form-group ">
//              <label for="exampleInputEmail1">เหตุการณ์:</label>
//              <input type="text" class="form-control" id="exampleInputEmail1" name="rs_title">
//              </div>
//
//              <div class="form-group">
//              <label for="exampleInputFile">เลือกห้องประชุม:</label>
//              <select class="form-control" name ="rm_id" >';
//            foreach ($option_array as $option) {
//                $tb .= '<option value="' . $option['rm_id'] . '">' . $option['rm_name'] . '</option>';
//            }
//
//            $tb .='</select>
//              </div>
//              <br>
//              <button type="button" class="btn btn-primary" onclick="reservAjax()">บันทึกการจอง</button>
//            </form>';
           echo  $this->load->view('resev_form',$data,true);
            //echo $tb;
        }
    }

    function reservation_add() {
        if($this->input->post('rs_title')){
            $rs_date = $this->input->post('rs_date');
            $rm_id = $this->input->post('rm_id');
            $rs_title = $this->input->post('rs_title');

            $timeSet = $this->input->post('timeSet');
            $user = $this->session->userdata('user_id');
            $mb_phone = $user['mb_phone'];
            $mb_id = $user['mb_id'];
            $sql = "INSERT INTO tb_reservation(mb_id,rm_id,rs_title,rs_date,rs_time,rs_phone,rs_stat)VALUES('$mb_id', '$rm_id','$rs_title','$rs_date','8:30-16:00','$mb_phone','0')";
            $this->db->query($sql);
            $this->session->set_flashdata('error','บันทึกการจองเรียบร้อยแล้ว');
            redirect('reservation');
        }else{
            $this->session->set_flashdata('error_input','กรุณาระบุข้อมูลให้ครบถ้วนลอง ใหม่อีกครั้ง!');
            redirect('reservation');
        }

    }

    function print_detail($id) {
        $this->data['device'] = $this->db
                ->join('tb_device as dv', 'dv.dv_id = br.dv_id')
                ->join('tb_devicetype as dt', 'dv.dt_id = dt.dt_id')
                ->where('br.rs_id', $id)
                ->order_by('dt.dt_id')
                ->get('tb_borrow as br')
                ->result_array();
        $this->data['reservation'] = $this->db
                ->join('tb_member as mb', 'mb.mb_id = rs.mb_id')
                ->join('tb_agent as ag', 'mb.ag_id = ag.ag_id')
                ->join('tb_room as rm', 'rm.rm_id = rs.rm_id')
                ->where('rs.rs_id', $id)
                ->get('tb_reservation as rs')
                ->row_array();
        $this->load->view('reservation_detail', $this->data);
    }

}
