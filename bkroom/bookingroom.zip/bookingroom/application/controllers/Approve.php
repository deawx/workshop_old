<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Approve extends CI_Controller {

  protected $data = array(
    'js' => array('jquery.validate.min')
  );

  public function __construct()
  {
    parent::__construct();
    if( ! $this->session->userdata('admin')) { redirect('login'); }
  }

  public function index()
  {
    $this->data['agent'] = $this->db->get('tb_agent')->result_array();
    $this->data['approve'] = $this->db->join('tb_agent as ag','ag.ag_id = mb.ag_id')->get('tb_member as mb')->result_array();
    $this->data['content'] = 'admin/approve';
    $this->load->view('template/back',$this->data);
  }

  function add_member()
  {
    $m = array(
      'mb_username' => $this->input->post('username'),
      'mb_password' => $this->input->post('password'),
      'mb_fullname' => $this->input->post('name').'&nbsp;'.$this->input->post('lastname'),
      'mb_phone' => $this->input->post('phone'),
      'ag_id' => $this->input->post('agent')
    );
    $this->db->insert('tb_member',$m);
    redirect('approve');
  }

  function conf_member($id)
  {
    if( ! $id) { redirect('approve'); }
    $this->db->set('mb_stat','1')->where('mb_id',$id)->update('tb_member');
    $this->session->set_flashdata('error','อนุมัติข้อมูลสมาชิกเรียบร้อยแล้ว');
    redirect($this->agent->referrer());
  }

  function del_member($id)
  {
    $mb = $this->db->get_where('tb_reservation','mb_id = '.$id);
    if($mb->num_rows() > 0) { $this->session->set_flashdata('error','พบการใช้งานในระบบ ไม่สามารถลบข้อมูล'); redirect($this->agent->referrer()); }
    $this->db->delete('tb_member',array('mb_id'=>$id));
    redirect('approve');
  }

}
