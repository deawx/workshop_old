<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Rule extends CI_Controller {

  protected $data = array(
    'js' => array('tinymce.min')
  );

  public function __construct()
  {
    parent::__construct();
    if( ! $this->session->userdata('admin')) { redirect('login'); }
  }

  public function index()
  {
    $this->data['rule'] = $this->db->get('tb_rule')->row();
    $this->data['content'] = 'admin/rule';
    $this->load->view('template/back',$this->data);
  }

  function add_rule()
  {
    $m = array(
      'rl_date' => date('Y-m-d'),
      'rl_detail' => $this->input->post('detail')
    );
    $this->db->insert('tb_rule',$m);
    $this->session->set_flashdata('error','บันทึกข้อมูลเสร็จสิ้น');
    redirect('rule');
  }

  function update_rule($id)
  {
    if( ! $id) { redirect('rule'); }
    $m = array(
      'rl_date' => date('Y-m-d'),
      'rl_detail' => $this->input->post('detail')
    );
    $this->db->update('tb_rule',$m,'rl_id = '.$id);
    $this->session->set_flashdata('error','บันทึกข้อมูลเสร็จสิ้น');
    redirect('rule');
  }

}
