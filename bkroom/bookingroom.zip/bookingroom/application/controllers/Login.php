<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {

  protected $data = array('js' => array('jquery.validate.min'));

  public function __construct()
  {
    parent::__construct();
    if($this->session->has_userdata('login')) { redirect('home'); }
  }

  public function index()
  {
    $this->data['content'] = 'login';
    $this->load->view('template/front',$this->data);
  }

  function do_login()
  {
    $s = array(
      'mb_username' => $this->input->post('username'),
      'mb_password' => $this->input->post('password'),
      'mb_stat' => '1'
    );
    $c = $this->db->limit(1)->get_where('tb_member',$s);
		if($c->num_rows() === 1 ) {
			$this->session->set_userdata('user_id',$c->row_array());
			$this->session->set_userdata('login',TRUE);
			$d = $c->row();
      if($d->mb_role === '1'){
        $this->session->set_userdata('admin',TRUE);
        $this->session->set_flashdata('error','ยินดีต้อนรับเข้าสู่ระบบผู้ดูแล');
        redirect('approve');
      }else{
        $this->session->set_flashdata('error','ยินดีต้อนรับเข้าสู่ระบบจองห้องประชุมออนไลน์');
        redirect('home');
      }
		}else{
      $this->session->set_flashdata('error','ไม่พบรายชื่อ หรือ ยังไม่ได้รับการอนุมัติ?');
			redirect('login');
		}
  }

}
