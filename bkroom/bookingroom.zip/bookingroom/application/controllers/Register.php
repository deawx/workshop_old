<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Register extends CI_Controller {

  protected $data = array(
    'js' => array('jquery.validate.min')
  );

  public function __construct()
  {
    parent::__construct();
  }

  public function index()
  {
    $this->data['agent'] = $this->db->get('tb_agent')->result_array();
    $this->data['content'] = 'register';
    $this->load->view('template/front',$this->data);
  }

  function do_register()
  {
    $s = array(
      'mb_username' => $this->input->post('username'),
      'mb_password' => $this->input->post('password'),
      'mb_fullname' => $this->input->post('name').'&nbsp;'.$this->input->post('lastname'),
      'mb_phone' => $this->input->post('phone'),
      'mb_position' => $this->input->post('position'),
      'mb_group' => $this->input->post('group'),
      'ag_id' => $this->input->post('agent')
    );
    $this->db->insert('tb_member',$s);
    $this->session->set_flashdata('error','การลงทะเบียนเสร็จสิ้น');
    redirect('login');
  }

  function check_name()
  {
    $s = $this->db->get_where('tb_member',array('mb_username'=>$this->input->post('username')));
    if($s->num_rows() > 0) { echo 'false'; }else{ echo 'true'; }
  }

}
