<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

  protected $data = array(
    'css' => array('lightbox'),
    'js' => array('lightbox')
  );

  public function __construct()
  {
    parent::__construct();
    $this->load->helper('download');
  }

  public function index($room = '')
  {
    if($room)
    {
      $this->data['picture'] = $this->db->where('rm_id',$room)->get('tb_picture')->result_array();
      $this->data['room'] = $this->db->join('tb_roomtype as rt','rt.rt_id = rm.rt_id')->where('rm.rm_id',$room)->get('tb_room as rm')->row();
      $this->data['content'] = 'room';
    }
    else
    {
      $this->data['picture'] = $this->db->group_by('rm_id')->get('tb_picture')->result_array();
      $this->data['room'] = $this->db->join('tb_roomtype as rt','rt.rt_id = rm.rt_id')->get('tb_room as rm')->result_array();
      $this->data['rule'] = $this->db->limit(1)->get('tb_rule')->row();
      $this->data['contact'] = $this->db->limit(1)->get('tb_contact')->row();
      $this->data['device'] = $this->db->join('tb_devicetype as dt','dt.dt_id = dv.dt_id')->get('tb_device as dv')->result_array();
      $this->data['content'] = 'home';
    }
    $this->load->view('template/front',$this->data);
  }

}
