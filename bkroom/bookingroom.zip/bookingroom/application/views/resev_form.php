<form id="form_submit"  method="post" action="<?= site_url('reservation/reservation_add') ?>">

    <input name="rs_date" type="hidden" value="<?= $rs_date ?>">
    <div>
        <div class="form-group">
            <label for="exampleInputEmail1">ขอบเขตเวลา:</label>
            <select class="form-control" name ="timeSet">
                <option value="8:30-12:00">8:30-12:00</option>
                <option value="13:00-16:00">13:00-16:00</option>
                <option value="8:30-16:00">8:30-16:00</option>
            </select>
        </div>

    </div>
    <div class="form-group ">
        <label for="exampleInputEmail1">เหตุการณ์:</label>
        <input type="text" class="form-control" id="exampleInputEmail1" name="rs_title" >
    </div>

    <div class="form-group">
        <label for="exampleInputFile">เลือกห้องประชุม:</label>
        <select class="form-control" name ="rm_id" >';
            <?php foreach ($option_array as $option) { ?>
                <option value="<?= $option['rm_id'] ?>"><?= $option['rm_name'] ?></option>';
            <?php } ?>

        </select>
    </div>
    <br>
    <button type="submit" class="btn btn-primary" >บันทึกการจอง</button>
</form>

