<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>ระบบจองห้องประชุมออนไลน์</title>

  <link href="<?php echo base_url('assets/css/bootstrap.min.css');?>" rel="stylesheet">
  <link href="<?php echo base_url('assets/css/toast.min.css');?>" rel="stylesheet">
  <?php if(isset($css)): foreach($css as $_css): ?>
    <link href="<?php echo base_url('assets/css/'.$_css.'.css');?>" rel="stylesheet">
  <?php endforeach; endif; ?>
  <link href="<?php echo base_url('assets/css/admin.css');?>" rel="stylesheet">

  <script src="<?php echo base_url('assets/js/jquery-1.11.2.min.js');?>"></script>
  <script src="<?php echo base_url('assets/js/bootstrap.min.js');?>"></script>
  <script src="<?php echo base_url('assets/js/toast.min.js');?>"></script>
  <?php if(isset($js)): foreach($js as $_js): ?>
    <script src="<?php echo base_url('assets/js/'.$_js.'.js');?>"></script>
  <?php endforeach; endif; ?>

</head>

<body>
  <?php
  $apr = $this->db->where('mb_stat','0')->count_all_results('tb_member');
  $bkk = $this->db->where('rs_stat','0')->count_all_results('tb_reservation');
  ?>

<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="">ส่วนงานของผู้ดูแลระบบ</a>
    </div>
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li> <a href="<?php echo site_url('approve'); ?>"></a> </li>
      </ul>
    </div>
  </div>
</nav>

<div class="container">
  <div class="row">
    <div class="col-md-3">
      <p class="lead">เมนูการทำงาน</p>
      <div class="list-group">
        <a href="<?php echo site_url('approve'); ?>" class="list-group-item">จัดการอนุมัติคำขอเข้าใช้ระบบ
          <span class="badge"><?php echo ($apr != '') ? $apr : ''; ?></span>
        </a>
        <a href="<?php echo site_url('booking'); ?>" class="list-group-item">จัดการอนุมัติการจองห้องประชุม
          <span class="badge"><?php echo ($bkk != '') ? $bkk : ''; ?></span>
        </a>
        <a href="<?php echo site_url('room'); ?>" class="list-group-item">จัดการข้อมูลห้องประชุม</a>
        <a href="<?php echo site_url('device'); ?>" class="list-group-item">จัดการข้อมูลอุปกรณ์</a>
        <a href="<?php echo site_url('rule'); ?>" class="list-group-item">จัดการข้อมูลกฎระเบียบ</a>
        <a href="<?php echo site_url('contact'); ?>" class="list-group-item">จัดการข้อมูลการติดต่อ</a>
        <hr />
        <a href="<?php echo site_url('logout'); ?>" class="list-group-item">ออกจากระบบ</a>
      </div>
    </div>
    <div class="col-md-9">
      <?php if(isset($content)): $this->load->view($content); endif; ?>
    </div>
  </div>
</div>

<div class="container">
  <hr />
  <footer>
    <div class="row">
      <div class="col-lg-12">
        <p>&nbsp;</p>
      </div>
    </div>
  </footer>
</div>

<div id="ss" data-value="<?php echo ($this->session->flashdata('error') != '') ? $this->session->flashdata('error') : NULL; ?>"></div>

<div class="modal fade" id="confirm" tabindex="-1" role="dialog" aria-labelledby="label" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header"></div>
      <div class="modal-body"></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">ยกเลิก</button>
        <a class="btn btn-danger">ยืนยัน</a>
      </div>
    </div>
  </div>
</div>

<script>
$(document).ready(function(){

	//confirm delete
	$('#confirm').on('show.bs.modal',function(e) {
		var target = $(e.relatedTarget);
		var title = 'ยืนยันการทำงาน';
		var body = target.data('body');
		var href = target.data('href');
		var modal = $(this);
		modal.find('.modal-header').text(title);
		modal.find('.modal-body').text(body);
		modal.find('a.btn').attr('href',href);
	});

  //show toast
  if($('div#ss').data('value'))
  {
    toastr.options = {
      "closeButton": true,
      "debug": false,
      "newestOnTop": false,
      "progressBar": false,
      "positionClass": "toast-center",
      "preventDuplicates": false,
      "onclick": null
    }
    toastr.success($('div#ss').data('value'));
  }

});
</script>

</body>
</html>
