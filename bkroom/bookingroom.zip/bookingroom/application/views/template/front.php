<html>
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>ระบบจองห้องประชุมออนไลน์</title>

  <link href="<?php echo base_url('assets/css/bootstrap.min.css');?>" rel="stylesheet">
  <link href="<?php echo base_url('assets/css/toast.min.css');?>" rel="stylesheet">
  <?php if(isset($css)): foreach($css as $_css): ?>
      <link href="<?php echo base_url('assets/css/'.$_css.'.css');?>" rel="stylesheet">
  <?php endforeach; endif; ?>
  <link href="<?php echo base_url('assets/css/main.css');?>" rel="stylesheet">

  <script src="<?php echo base_url('assets/js/jquery-1.11.2.min.js');?>"></script>
  <script src="<?php echo base_url('assets/js/bootstrap.min.js');?>"></script>
  <script src="<?php echo base_url('assets/js/toast.min.js');?>"></script>
  <?php if(isset($js)): foreach($js as $_js): ?>
      <script src="<?php echo base_url('assets/js/'.$_js.'.js');?>"></script>
  <?php endforeach; endif; ?>

<style type="text/css">
<!--
.style1 {color: #9DACBF}
-->
</style></head>

<body>
<div class="logo"></div>
  <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
      </div>

      <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
        <ul class="nav navbar-nav">
          <li <?php if($this->uri->segment(1) === 'home') echo 'class="active"'; ?>><a href="<?php echo site_url('home'); ?>">หน้าหลัก</a></li>
          <li <?php if($this->uri->segment(1) === 'reservation') echo 'class="active"'; ?>><a href="<?php echo site_url('reservation'); ?>">ตารางการใช้ห้อง</a></li>
          <?php if($this->session->has_userdata('login')) { ?>
          <li <?php if($this->uri->segment(1) === 'event') echo 'class="active"'; ?>><a href="<?php echo site_url('event'); ?>">จองห้องประชุม</a></li>
          <li><a href="<?php echo site_url('logout'); ?>">ออกจากระบบ</a></li>
          <?php }else{ ?>
          <li <?php if($this->uri->segment(1) === 'login') echo 'class="active"'; ?>><a href="<?php echo site_url('login'); ?>">เข้าสู่ระบบ</a></li>
          <?php } ?>
        </ul>
        <?php if($this->session->has_userdata('login')) { ?>
        <ul class="nav navbar-nav navbar-right">
          <li>
            <p class="navbar-text">
              <a href="<?php echo site_url('member').'/'.$this->session->userdata('mb_id'); ?>">
                <?php echo $this->session->userdata('mb_fullname'); ?>
              </a>
            : กำลังใช้งานระบบ
            </p>
          </li>
        </ul>
        <?php } ?>
      </div>
    </div>
  </nav>

  <div class="container">
    <?php if(isset($content)): $this->load->view($content); endif; ?>
  </div>

  <div id="ss" data-value="<?php echo ($this->session->flashdata('error') != '') ? $this->session->flashdata('error') : NULL; ?>"></div>
  <div id="ssc" data-value="<?php echo ($this->session->flashdata('error_input') != '') ? $this->session->flashdata('error_input') : NULL; ?>"></div>

  <div class="modal fade" id="confirm" tabindex="-1" role="dialog" aria-labelledby="label" aria-hidden="true">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header"></div>
        <div class="modal-body"> </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">ยกเลิก</button>
          <a class="btn btn-danger">ยืนยัน</a>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="detail" tabindex="-1" role="dialog" aria-labelledby="label" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header"></div>
        <div class="modal-body"> </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal"></button>
        </div>
      </div>
    </div>
  </div>

<script>
$(document).ready(function(){

	//confirm delete
	$('#confirm').on('show.bs.modal',function(e) {
		var target = $(e.relatedTarget);
		var title = 'ยืนยันการทำงาน';
		var body = target.data('body');
		var href = target.data('href');
		var modal = $(this);
		modal.find('.modal-header').text(title);
		modal.find('.modal-body').text(body);
		modal.find('a.btn').attr('href',href);
	});

  //call reservation_detail
  $('#detail').on('show.bs.modal',function(e) {
    var target = $(e.relatedTarget);
    var title = target.data('title');
    var body = target.data('body');
    var modal = $(this);
    modal.find('.modal-header').text(title);
    modal.find('.modal-body').text(body);
  });

  //show toast
  if($('div#ss').data('value'))
  {
    toastr.options = {
      "debug": false,
      "progressBar": false,
      "positionClass": "toast-center",
      "onclick": null
    }
    toastr.success($('div#ss').data('value'));
  }

});
</script>

</body>
</html>
