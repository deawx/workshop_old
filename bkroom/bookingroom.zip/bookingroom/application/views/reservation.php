<style>
.calendar
.hightlight {
  color:blue;
}
.calendar
.days td {
  width:100px;
  height:100px;
}
.calendar
.days td>.day_use{
  display:block;
  /*padding:15px;*/
  //background-color:#66FF66;
}
.calendar
.days td:hover {
  background-color:#fff;
}
#textWait {
    color: #09f;
    text-decoration: none;
}
.calendar .days td{
   background-color:#fff;
}
.table > tbody > tr > td, .table > tbody > tr > th, .table > tfoot > tr > td, .table > tfoot > tr > th, .table > thead > tr > td, .table > thead > tr > th {
    border: 1px solid #ddd;
    border-radius: 0px;
}
.table > tbody > tr > th:first-child{
      border-radius: 0px;
}
.bartitle {
    background-color: #b6b0bb;
    border: 1px solid #ccc;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
    margin: 0;
    padding: 3px;
    text-align: center;
}
#textSuccss{
    color: #5cb85c;
}
.row.hidden-print{
    width: 1100px;
}

</style>
<div id="ss" data-value="<?php echo ($this->session->flashdata('error') != '') ? $this->session->flashdata('error') : NULL; ?>"></div>

<div class="row hidden-print" >
  <div class="col-md-8">
    <br />
    <?php echo $calendar; ?>
  </div>
  <div class="col-md-4">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title">ตารางการใช้ห้องของวันนี้</h3>
      </div>
      <div class="panel-body">
        *ได้รับการอนุมัติแล้ว
      </div>
        <table class="table table-bordered">
          <thead>
            <tr>
              <th width="17" class="text-center">ที่</th>
              <th width="57" class="text-center">รายการ</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($reserve as $_k => $_r) { ?>
            <tr>
              <td class="text-center"><?php echo $_k+1; ?></td>
              <td>
                <table class="table">
                  <tr>
                    <td><?php echo $_r['rs_title']; ?></td>
                  </tr>
                  <tr>
                    <td><?php echo $_r['rm_name']; ?></td>
                  </tr>
                  <tr>
                    <td><?php echo $_r['rs_time']; ?></td>
                  </tr>
                </table>
              </td>
            </tr>
            <?php } ?>
          </tbody>
        </table>
    </div>
    <p> *สามารถคลิกดูตารางการใช้ห้องตามวันในปฎิทิน </p>
    <input type="hidden" name="year" value="<?php echo ($this->uri->segment(2) != '') ? $this->uri->segment(2) : date('Y'); ?>" />
    <input type="hidden" name="month" value="<?php echo ($this->uri->segment(2) != '') ? $this->uri->segment(3) : date('m'); ?>" />
  </div>
</div>

<script>
$(document).ready(function(){

  $('#year').html(parseInt($('#year').html())+parseInt(543));

  $('td.day').children('div.day_use').css('background-color:#66FF66');

  year = $('input[name="year"]').val();
  month = $('input[name="month"]').val();
<?php if( ! $this->session->userdata('login')) { ?>
  $('.calendar .day>[data-toggle="tooltip"]').on('click',function(e){
    day = $(this).text();
    year = $('input[name="year"]').val();
    month = $('input[name="month"]').val();
    $.ajax({
      url: "<?=site_url('reservation/show_detail');?>",
      type: 'post',
      data: {d:day,m:month,y:year},
      success: function(e){
        $('#detail').modal('show',function(){
          $(this).find(".modal-header").text(' ตารางการใช้ห้องประชุมของวันที่ '+day+'-'+month+'-'+year);
          $(this).find(".modal-body").html(e);
        });
      }
    });
  });
<?php }else{?>
   $('.calendar .day>.day_num').on('click',function(e){
    day = $(this).text();
    year = $('input[name="year"]').val();
    month = $('input[name="month"]').val();
    $.ajax({
      url: "<?=site_url('reservation/show_detail');?>",
      type: 'post',
      data: {d:day,m:month,y:year},
      success: function(e){
        $('#detail').modal('show',function(){
          $(this).find(".modal-header").text(' ตารางการใช้ห้องประชุมของวันที่ '+day+'-'+month+'-'+year);
          $(this).find(".modal-body").html(e);
        });
      }
    });

  });
<?php }?>

});
//function reservAjax(){
//    var form = $("#form_submit");
//    $.ajax({
//      url: "<?=site_url('reservation/reservation_add');?>",
//      type: 'post',
//      data: form.serialize(),
//      success: function(e){
//        if(e ==1){
//            $('#detail').modal("hide");
////            location.reload();
//        }else{
//
//      }
//    }
//
//  });
//  }
</script>
