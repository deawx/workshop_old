<div class="row">
  <br />
  <br />
  <div class="col-md-6 col-md-push-3 col-md-pull-3">
    <form class="form-horizontal well" role="member" method="post" action="<?php echo site_url('member/update_member').'/'.$member->mb_id; ?>">
      <div class="form-group">
        <label class="col-md-4 control-label" for="name">ชื่อผู้ใช้</label>
        <div class="col-md-8">
          <input class="form-control" type="text" name="username" id="username" value="<?php echo $member->mb_username; ?>" disabled />
        </div>
      </div>
      <div class="form-group">
        <label class="col-md-4 control-label" for="name">ชื่อ</label>
        <div class="col-md-8">
          <input class="form-control" type="text" name="name" value="<?php echo explode('&nbsp;',$member->mb_fullname)[0]; ?>" />
        </div>
      </div>
      <div class="form-group">
        <label class="col-md-4 control-label" for="lastname">นามสกุล</label>
        <div class="col-md-8">
          <input class="form-control" type="text" name="lastname" value="<?php echo explode('&nbsp;',$member->mb_fullname)[1]; ?>" />
        </div>
      </div>
      <div class="form-group">
        <label class="col-md-4 control-label" for="position">ตำแหน่ง</label>
        <div class="col-md-8">
          <input class="form-control" type="text" name="position" value="<?php echo $member->mb_position; ?>" />
        </div>
      </div>
      <div class="form-group">
        <label class="col-md-4 control-label" for="group">ฝ่าย/แผนก</label>
        <div class="col-md-8">
          <input class="form-control" type="text" name="group" value="<?php echo $member->mb_group; ?>" />
        </div>
      </div>
      <div class="form-group">
        <label class="col-md-4 control-label" for="agent">หน่วยงาน</label>
        <div class="col-md-8">
          <select class="form-control" name="agent">
            <option value="">----เลือกหน่วยงาน----</option>
            <?php foreach($agent as $_a) { ?>
            <option value="<?php echo $_a['ag_id']; ?>" <?php if($_a['ag_id'] === $member->ag_id) { echo 'selected="selected"'; } ?>><?php echo $_a['ag_name']; ?></option>
            <?php } ?>
          </select>
        </div>
      </div>
      <div class="form-group">
        <label class="col-md-4 control-label" for="phone">เบอร์โทรศัพท์</label>
        <div class="col-md-8">
          <input class="form-control" type="phone" name="phone" value="<?php echo $member->mb_phone; ?>" />
        </div>
      </div>
      <hr />
      <div class="form-group">
        <label class="col-md-4 label-control" for=""></label>
        <div class="col-md-8">
          <button class="btn btn-success" type="submit">แก้ไขข้อมูล</button>
          <button class="btn btn-default" type="reset">ยกเลิก</button>
        </div>
      </div>
      <?php if($this->session->flashdata('error')) { ?>
        <span class="text-warning h4"><div id="ss" data-value="<?php echo ($this->session->flashdata('error') != '') ? $this->session->flashdata('error') : NULL; ?>"></div></span>
      <?php } ?>
    </form>

</div>
</div>

<script>
$(document).ready(function(){

	$('form[role="member"]').validate({
		debug:true,
    onkeyup:false,
		errorElement:'label',
		rules:{
			username: {
				required:true,
				rangelength:[5,20]
        // remote: {
        //   type: 'POST',
        //   url : '<?php echo site_url("member/check_name"); ?>',
        //   data : {
        //     username : function(){
        //       return $('#username').val();
        //     }
        //   }
        // }
			},
			// oldpassword: {
			// 	required:true,
			// 	rangelength:[8,10],
      //   remote: {
      //     type: 'POST',
      //     url : '<?php echo site_url("member/check_password"); ?>',
      //     data : {
      //       oldpassword : function(){
      //         return $('#oldpassword').val();
      //       }
      //     }
      //   }
			// },
			// password: {
			// 	required:true,
			// 	rangelength:[8,10]
			// },
			// confirmPassword: {
			// 	required:true,
			// 	equalTo: '#password'
			// },
			name: {
				required:true,
				rangelength:[2,30]
			},
			lastname: {
				required:true,
				rangelength:[3,30]
			},
			phone: {
				required:true,
        number:true
			},
			position: {
				required:true,
        rangelength:[1,30]
			},
			group: {
				required:true,
        rangelength:[1,30]
			},
			agent: {
				required:true
			}
		},
		messages:{
			// username: {
			// 	required:'กรุณากรอกชื่อผู้ใช้ด้วยครับ !',
      //   rangelength:'กรุณากรอกข้อมูล 5 ถึง 20 ตัวอักษร !',
      //   remote : 'มีชื่อผู้ใช้อยู่แล้วในระบบ ไม่สามารถใช้ชื่อนี้ได้'
			// },
			// oldpassword: {
			// 	required:'กรุณากรอกรหัสผ่านด้วยครับ !',
      //   rangelength:'กรุณากรอกข้อมูล 8 ถึง 10 ตัวอักษร !',
      //   remote : 'รหัสผ่านเดิมไม่ถูกต้อง'
			// },
			// password: {
			// 	required:'กรุณากรอกรหัสผ่านด้วยครับ !',
      //   rangelength:'กรุณากรอกข้อมูล 8 ถึง 10 ตัวอักษร !'
			// },
			// confirmPassword: {
			// 	required:'กรุณากรอกรหัสผ่านให้ตรงกันด้วยครับ !',
      //   equalTo:'กรุณากรอกรหัสผ่านให้ตรงกันด้วยครับ !'
			// },
			name: {
				required:'กรุณากรอกชื่อด้วยครับ !',
        rangelength:'ไม่เกิน 30 ตัวอักษร !'
			},
			lastname: {
				required:'กรุณากรอกนามสกุลด้วยครับ !',
        rangelength:'ไม่เกิน 30 ตัวอักษร !'
			},
      phone: {
				required:'กรุณากรอกเบอร์โทร !',
				number:'กรุณกรอกข้อมูลตัวเลขด้วยครับ !'
			},
      position: {
				required:'กรอกข้อมูลตำแหน่งงาน !',
        rangelength:'ไม่เกิน 30 ตัวอักษร !'
			},
      group: {
				required:'กรอกข้อมูลตำแหน่งงาน !',
        rangelength:'ไม่เกิน 30 ตัวอักษร !'
			},
      agent: {
				required:'เลือกหน่วยงาน !'
			}
		},
		submitHandler: function(form){
      form.submit();
		}
	});
});
</script>
