<div class="row">
  <div class="col-md-7">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title">ค้นหาตารางการใช้ห้อง</h3>
      </div>
      <div class="panel-body">
        <form role="search" method="post" action="<?php echo site_url('event'); ?>">
          <label class="control-label col-md-4" for="date">วันที่</label>
          <div class="col-md-6">
            <input type="date" min="2000-01-01" class="form-control" name="date" />
          </div>
          <button class="btn btn-success col-md-2" type="submit">
            <span class="glyphicon glyphicon-search"></span>
          </button>
        </form>
      </div>
        <table class="table table-bordered">
          <thead>
            <tr>
              <th class="text-center">รายการ</th>
              <th class="text-center">สถานที่</th>
              <th class="text-center">วันที่</th>
              <th class="text-center">เวลา</th>
            </tr>
          </thead>
          <tbody>
          <?php if($search != '') { ?>
            <?php foreach($search as $_s) { ?>
            <tr>
              <td class="text-left"><?php echo $_s['rs_title']; ?></td>
              <td class="text-left"><?php echo $_s['rm_name']; ?></td>
              <td class="text-right"><?php echo $_s['rs_date']; ?></td>
              <td class="text-right"><?php echo $_s['rs_time']; ?></td>
            </tr>
            <?php } ?>
          </tbody>
          <?php }else{ ?>
            <tr>
              <td colspan="4" class="text-center">ไม่มีข้อมูล</td>
            </tr>
          <?php } ?>
        </table>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title">ตารางการใช้ห้องของเดือนปัจจุบัน</h3>
      </div>
      <div class="panel-body">
        *ได้รับการอนุมัติแล้ว
      </div>
        <table class="table table-bordered">
          <thead>
            <tr>
              <th class="text-center">รายการ</th>
              <th class="text-center">สถานที่</th>
              <th class="text-center">วันที่</th>
              <th class="text-center">เวลา</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($reserve as $_r) { ?>
            <tr>
              <td class="text-left"><?php echo $_r['rs_title']; ?></td>
              <td class="text-left"><?php echo $_r['rm_name']; ?></td>
              <td class="text-right"><?php echo $_r['rs_date']; ?></td>
              <td class="text-right"><?php echo $_r['rs_time']; ?></td>
            </tr>
            <?php } ?>
          </tbody>
        </table>
    </div>
  </div>
  <div class="col-md-5">
    <form class="form-horizontal well" role="event" method="post" action="<?php echo site_url('event/add_event'); ?>">
      <div class="form-group">
        <label class="col-md-4" for="date">เลือกวันที่</label>
        <div class="col-md-8">
        <input name="date" type="date" class="form-control" />
        </div>
      </div>
      <div class="form-group">
        <label class="col-md-4" for="title">ระบุชื่อเรื่อง</label>
        <div class="col-md-8">
        <input name="title" type="text" placeholder="ระบุชื่อเรื่อง" class="form-control" />
        </div>
      </div>
      <div class="form-group">
        <label class="col-md-4" for="room">เลือกห้องประชุม</label>
        <div class="col-md-8">
          <select class="form-control" name="room">
            <option></option>
            <?php foreach($room as $_r) { ?>
              <option value="<?php echo $_r['rm_id']; ?>"><?php echo $_r['rm_name']; ?></option>
            <?php } ?>
          </select>
        </div>
      </div>
      <div class="form-group">
        <label class="col-md-4" for="radio">ช่วงเวลา</label>
        <div class="col-md-8">
          <div class="radio">
            <label for="radio">
              <input type="radio" name="time" value="8:30-12:00" checked="checked">8:30-12:00
            </label>
          </div>
          <div class="radio">
            <label for="radio">
              <input type="radio" name="time" value="​13:00-16:00">13:00-16:00
            </label>
          </div>
          <div class="radio">
            <label for="radio">
              <input type="radio" name="time" value="8:30-16:00">8:30-16:00
            </label>
          </div>
        </div>
      </div>
      <div class="form-group">
        <label class="col-md-4" for="device">รายการเบิกอุปกรณ์</label>
        <?php foreach($device as $_d) { ?>
        <label class="col-md-4" for=""></label>
        <div class="col-sm-5">
          <div class="checkbox">
            <label for="device">
              <input type="checkbox" name="device[]" value="<?php echo $_d['dv_id']; ?>">
              <?php echo $_d['dv_name']; ?>
            </label>
          </div>
        </div>
        <div class="col-sm-3">
          <input type="number" class="form-control devicenum hidden" id="<?php echo $_d['dv_id']; ?>" placeholder="จำนวน" />
        </div>
        <?php } ?>
      </div>
      <div class="form-group">
        <label class="col-md-4" for="phone">เบอร์โทรศัพท์</label>
        <div class="col-md-8">
          <input name="phone" class="form-control" type="text" placeholder="เบอร์โทรศัพท์" />
        </div>
      </div>
      <div class="form-group">
        <label class="col-md-4" for="fullname">ชื่อผู้จอง</label>
        <div class="col-md-8">
          <input type="hidden" name="fullname" value="<?php echo $this->session->userdata('mb_id'); ?>" />
          <input class="form-control" value="<?php echo $this->session->userdata('mb_fullname'); ?>" disabled />
        </div>
      </div>
      <div class="form-group">
        <label class="col-md-4"></label>
        <div class="col-md-8">
          <button type="submit" class="btn btn-primary">เพิ่มข้อมูล</button>
        </div>
      </div>
    </form>
    <div class="alert-warning">
      <div id="ss" data-value="<?php echo ($this->session->flashdata('error') != '') ? $this->session->flashdata('error') : NULL; ?>"></div>
    <hr />
    <p>
      *ระบบรองรับการจองห้องประชุม <mark>ในวันถัดจากวันที่ปัจจุบันเท่านั้น</mark>
    </p>
  </div>
</div>

<script>
$(document).ready(function(){
  $(':checkbox').click(function(){
    chk = $(this);
    id = $(this).val();
    if($(this).is(':checked'))
    {
      $('.devicenum[id="'+id+'"]').removeClass('hidden').attr('name','devicenum[]').val('1');
    }
    else
    {
      $('.devicenum[id="'+id+'"]').addClass('hidden').removeAttr('name');
    }
  });
	$('form[role="event"]').validate({
		debug:true,
    onkeyup:false,
		errorElement:'label',
		rules:{
			date: {
				required:true
			},
			title: {
				required:true
			},
			room: {
				required:true
			},
			time: {
				required:true
			},
			phone: {
				required:true,
        min:0
			}
		},
		messages:{
      date: {
        required:'กรุณาเลือกวันที่ !'
			},
			title: {
				required:'กรุณาระบุชื่อเรื่อง !'
			},
			room: {
				required:'กรุณาเลือกห้อง !'
			},
			phone: {
				required:'กรุณากรอกเบอร์โทรศัพท์ !',
				min:'ค่าตัวเลขต้องมากกว่า 0 !'
			}
		},
		submitHandler: function(form){
      form.submit();
		}
	});
});
</script>
