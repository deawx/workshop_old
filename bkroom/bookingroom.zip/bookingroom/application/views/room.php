<div class="row">
  <div class="thumbnail">
    <?php foreach($picture as $_p) { ?>
      <div class="col-md-3">
        <a
          href="<?php echo base_url('uploads/room/'.$_p['pt_thumb']); ?>"
          data-lightbox="lightbox"
          data-title="<?php echo $room->rm_name; ?>">
          <img
            class="img-thumbnail"
            src="<?php echo base_url('uploads/room/'.$_p['pt_thumb']); ?>"
            style="width:300px;height:300px;margin-bottom:30px;"
          />
        </a>
      </div>
    <?php } ?>
    <div class="caption">
      <table class="table">
        <tbody>
          <tr>
            <td class="text-center well">ชื่อห้อง</td>
            <td class="text-left"><?php echo $room->rm_name; ?></td>
          </tr>
          <tr>
            <td class="text-center well">ประเภทห้อง</td>
            <td class="text-left"><?php echo $room->rt_name; ?></td>
          </tr>
          <tr>
            <td class="text-center well">ประเภทห้อง</td>
            <td class="text-left"><?php echo $room->rm_name; ?></td>
          </tr>
          <tr>
            <td class="text-center well">อุปกรณ์</td>
            <td class="text-left"><?php echo $room->rm_device; ?></td>
          </tr>
          <tr>
            <td class="text-center well">รายละเอียด</td>
            <td class="text-left"><?php echo $room->rm_detail; ?></td>
          </tr>
          <tr>
            <td class="text-center well">การรองรับ</td>
            <td class="text-left"><?php echo $room->rm_fill; ?>/คน</td>
          </tr>
          <tr>
            <td class="text-center well">การใช้งาน</td>
            <td class="text-left"><?php echo $room->rm_used; ?>/ครั้ง</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</div>
