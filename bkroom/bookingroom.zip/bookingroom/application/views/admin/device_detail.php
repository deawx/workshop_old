<div class="row">
  <form class="form-horizontal well" role="device" enctype="multipart/form-data" method="post" action="<?php echo site_url('device/update_device'); ?>">
    <div class="form-group">
      <label class="control-label col-md-4" for=""></label>
      <div class="col-md-8">
        <img id="preview" class="img-thumbnail" src="<?php echo base_url('uploads/device/'.$device_detail->dv_picture); ?>" />
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-md-4" for="picture">รูปภาพประกอบ</label>
      <div class="col-md-8">
        <input type="file" id="picture" class="form-control" name="picture" />
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-md-4" for="name">ชื่ออุปกรณ์</label>
      <div class="col-md-8">
      <input name="name" type="text" class="form-control" value="<?php echo $device_detail->dv_name; ?>" />
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-md-4" for="type">ประเภทอุปกรณ์</label>
      <div class="col-md-8">
        <select name="type" class="form-control">
          <?php foreach($devicetype as $_dt) { ?>
          <option <?php if($device_detail->dt_id === $_dt['dt_id']) { echo 'selected'; } ?> value="<?php echo $_dt['dt_id']; ?>"><?php echo $_dt['dt_name']; ?></option>
          <?php } ?>
        </select>
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-md-4" for="detail">รายละเอียด</label>
      <div class="col-md-8">
        <textarea rows="10" name="detail" class="form-control"><?php echo $device_detail->dv_detail; ?></textarea>
      </div>
    </div>
    <div class="form-group">
      <label class="col-md-4"></label>
      <div class="col-md-8">
        <input type="hidden" name="picturename" value="<?php echo $device_detail->dv_picture; ?>" />
        <input type="hidden" name="id" value="<?php echo $this->uri->segment(2); ?>" />
        <button type="submit" class="btn btn-success">เพิ่มข้อมูล</button>
        <button type="reset" class="btn btn-warning">ล้างรายการ</button>
      </div>
    </div>
  </form>
  <div class="alert-warning">
    <?php echo ($this->session->flashdata('error') != '') ? $this->session->flashdata('error') : ''; ?>
  </div>
</div>

<script>
$(document).ready(function(){
  function read_file(input) {
    if (input.files && input.files[0]) {
      var reader = new FileReader();
      reader.onload = function (e) {
        $('#preview').attr('src', e.target.result);
      }
      reader.readAsDataURL(input.files[0]);
    }
  }
  $('#picture').change(function(){
    read_file(this);
  });

  $('form[role="device"]').validate({
  	debug:true,
  	errorElement:'label',
  	rules:{
  		picture: {
        extension:'jpg'
  		},
  		name: {
  			required:true,
  			rangelength:[1,50]
  		},
      type: {
        required:true
      },
  		detail: {
  			required:true
  		}
  	},
  	messages:{
      picture: {
        extension:'ใช้รูปภาพลักษณะ jpg !'
      },
  		name: {
  			required:'กรอกชื่ออุปกรณ์ !',
  			rangelength:'1 ถึง 50 ตัวอักษร !'
  		},
      type: {
        required:'เลือกประเภทอุปกรณ์ !'
      },
  		detail: {
  			required:'กรุณากรอกรายละเอียด !'
  		}
  	},
  	submitHandler: function(form){
      form.submit();
  	}
  });
});
</script>
