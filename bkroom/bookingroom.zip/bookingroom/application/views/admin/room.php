<div class="row">
  <h3>ข้อมูลห้องประชุม</h3>
  <div class="col-md-12">
    <form class="form-horizontal well" role="room" enctype="multipart/form-data" method="post" action="<?php echo site_url('room/add_room'); ?>">
      <!-- <div class="form-group">
        <label class="control-label col-md-4" for=""></label>
        <div class="col-md-8">
          <img class="img-thumbnail" id="preview" src="#" alt="" />
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-md-4" for="picture">รูปภาพประกอบ</label>
        <div class="col-md-8">
          <input type="file" id="picture" class="form-control" name="picture" multiple="true"/>
        </div>
      </div> -->
      <div class="form-group">
        <label class="control-label col-md-4" for="name">ชื่อห้องประชุม</label>
        <div class="col-md-8">
          <input type="text" class="form-control" name="name" placeholder="ชื่อห้องประชุม" />
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-md-4" for="type">ประเภทห้องประชุม</label>
        <div class="col-md-7">
          <select name="type" class="form-control">
            <?php foreach($roomtype as $_rt) { ?>
              <option value="<?php echo $_rt['rt_id']; ?>"><?php echo $_rt['rt_name']; ?></option>
            <?php } ?>
          </select>
        </div>
        <div class="col-md-1 text-right">
          <a href="" data-toggle="modal" data-target="#form" >แก้ไข</a>
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-md-4" for="">อุปกรณ์ห้องประชุม</label>
        <div class="col-md-8">
          <input type="text" name="device" class="form-control" placeholder="อุปกรณ์ห้องประชุม" />
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-md-4" for="">รายละเอียดห้องประชุม</label>
        <div class="col-md-8">
          <textarea class="form-control" name="detail" rows="6"></textarea>
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-md-4" for="number">จำนวนการรองรับ</label>
        <div class="col-md-8">
          <input type="number" class="form-control" name="fill" placeholder="จำนวนการรองรับ" />
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-md-4" for=""></label>
        <div class="col-md-8">
          <button type="submit" class="btn btn-success">บันทึกข้อมูล</button>
          <button type="reset" class="btn btn-default">ล้างรายการ</button>
        </div>
      </div>
    </form>
    <div class="alert-warning">
      <div id="ss" data-value="<?php echo ($this->session->flashdata('error') != '') ? $this->session->flashdata('error') : NULL; ?>"></div>
    </div>
  </div>

  <div class="col-md-12">
    <table class="table table-bordered">
      <thead>
        <tr>
          <th class="text-center" style="width:5%">ที่</th>
          <th class="text-center" style="width:40%">ห้องประชุม</th>
          <th class="text-center">ประเภท</th>
          <th class="text-center">จำนวน</th>
          <th class="text-center">การใช้งาน</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($room as $_k => $_r) { ?>
        <tr>
          <td class="text-center"><?php echo $_k+1; ?></td>
          <td class="text-left"><?php echo $_r['rm_name']; ?></td>
          <td class="text-left"><?php echo $_r['rt_name']; ?></td>
          <td class="text-center"><?php echo $_r['rm_fill']; ?></td>
          <td class="text-center"><?php echo $_r['rm_used']; ?>/ครั้ง</td>
          <td class="text-center">
            <a href="<?php echo site_url('room/'.$_r['rm_id']); ?>">
            <i class="glyphicon glyphicon-eye-open"></i>
            </a>
          </td>
        </tr>
        <?php } ?>
      </tbody>
    </table>
  </div>
</div>

<div class="modal fade" id="form" tabindex="-1" role="dialog" aria-labelledby="label" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">เพิ่มประเภทห้องประชุม</h4>
      </div>
      <form class="form-horizontal" role="roomtype" method="post" action="<?php echo site_url('room/add_roomtype'); ?>">
      <div class="modal-body">
          <div class="form-group">
            <label class="control-label col-md-4" for="name">ชื่อห้องประชุม</label>
            <div class="col-md-8">
              <input type="text" class="form-control" name="name" />
            </div>
          </div>
          <div class="form-group">
            <label class="control-label col-md-4" for="detail"></label>
            <div class="col-md-8">
              <table class="table">
                <?php foreach($roomtype as $_rt) { ?>
                <tr>
                  <td><?php echo $_rt['rt_name']; ?></td>
                  <td class="text-right" style="width:10%;">
                    <a href="#" data-toggle="modal" data-target="#confirm" data-body="<?php echo $_rt['rt_name']; ?>" data-href="<?php echo site_url('room/del_roomtype/'.$_rt['rt_id']); ?>">
                    <i class="glyphicon glyphicon-remove"></i>
                    </a>
                  </td>
                </tr>
                <?php } ?>
              </table>
            </div>
          </div>
      </div>
      <div class="modal-footer">
        <label class="control-label col-md-4" for="detail"></label>
        <div class="col-md-8">
          <button type="submit" class="btn btn-success btn-block">เพิ่มข้อมูล</button>
        </div>
      </div>
      </form>
    </div>
  </div>
</div>

<script>
$(document).ready(function(){

  // function read_file(input) {
  //   if (input.files && input.files[0]) {
  //     var reader = new FileReader();
  //     reader.onload = function (e) {
  //       $('#preview').attr('src', e.target.result);
  //     }
  //     reader.readAsDataURL(input.files[0]);
  //   }
  // }
  // $('#picture').change(function(){
  //   read_file(this);
  // });

	$('form[role="room"]').validate({
		debug:true,
		errorElement:'label',
		rules:{
      picture: {
        required:true,
        extension:'jpg'
      },
			name: {
				required:true,
				rangelength:[1,100]
			},
			detail: {
				required:true
			},
			fill: {
				required:true,
        number:true,
        min:1,
				rangelength:[1,5]
			}
		},
		messages:{
      picture: {
        required:'กรุณาใส่รูปภาพ !',
        extension:'ใช้รูปภาพลักษณะ jpg !'
      },
			name: {
				required:'กรุณากรอกชื่อห้อง !',
				rangelength:'ชื่อห้องมีความยาวตั้งแต่ 1 ถึง 100 ตัวอักษร !'
			},
			detail: {
				required:'กรุณากรอกรายละเอียด !'
			},
			fill: {
				required:'ระบุปริมาณการรองรับ !',
        min:'ใช้ตัวเลขที่มีค่ามากกว่า 1 !',
        number:'ใช้ตัวเลขเท่านั้น !',
				rangelength:'ตัวเลขความจุไม่เกิน 4 หลัก !'
			}
		},
		submitHandler: function(form){
      form.submit();
		}
	});

  $('form[role="roomtype"]').validate({
		debug:true,
		errorElement:'label',
		rules:{
			name: {
				required:true,
				rangelength:[1,50]
			}
		},
		messages:{
			name: {
				required:'กรุณากรอกประเภทห้อง !',
				rangelength:'ประเภทห้องมีความยาวตั้งแต่ 1 ถึง 50 ตัวอักษร !'
			}
		},
		submitHandler: function(form){
      form.submit();
		}
	});
});
</script>
