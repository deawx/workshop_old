<div class="row"><img src="../../../assets/img/foot.jpg" width="1100" height="200" />
  
</div>
