<div class="row">
  <h3>ข้อมูลผู้ใช้งานระบบ</h3>
  <div class="col-md-12">
    <form class="form-horizontal well" role="approve" method="post" action="<?php echo site_url('approve/add_member'); ?>">
      <div class="form-group">
        <label class="control-label col-md-4" for="name">ชื่อ</label>
        <div class="col-md-8">
          <input type="text" class="form-control" name="name" placeholder="ขื่อจริง" />
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-md-4" for="name">นามสกุล</label>
        <div class="col-md-8">
          <input type="text" class="form-control" name="lastname" placeholder="นามสกุล" />
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-md-4" for="name">เบอร์โทรศัพท์</label>
        <div class="col-md-8">
          <input type="text" class="form-control" name="phone" placeholder="เบอร์โทรศัพท์" />
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-md-4" for="name">หน่วยงาน</label>
        <div class="col-md-8">
          <select name="agent" class="form-control">
            <?php foreach($agent as $_a) { ?>
            <option value="<?php echo $_a['ag_id']; ?>"><?php echo $_a['ag_name']; ?></option>
            <?php } ?>
          </select>
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-md-4" for="name">ชื่อผู้ใช้</label>
        <div class="col-md-8">
          <input type="text" class="form-control" name="username" placeholder="ชื่อผู้ใช้" />
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-md-4" for="name">รหัสผ่าน</label>
        <div class="col-md-8">
          <input type="text" class="form-control" name="password" placeholder="รหัสผ่าน" />
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-md-4" for=""></label>
        <div class="col-md-8">
          <button type="submit" class="btn btn-success">บันทึกข้อมูล</button>
          <button type="reset" class="btn btn-default">ล้างรายการ</button>
        </div>
      </div>
    </form>
    <div class="alert-warning">
      <div id="ss" data-value="<?php echo ($this->session->flashdata('error') != '') ? $this->session->flashdata('error') : NULL; ?>"></div>
    </div>
  </div>
  <div class="col-md-12">
    <table class="table table-bordered table-striped">
      <thead>
        <tr>
          <th class="text-center" style="width:10%;">ที่</th>
          <th class="text-center" style="width:50%;">ชื่อ - นามสกุล</th>
          <th class="text-center">ชื่อผู้ใช้</th>
          <th class="text-center">หน่วยงาน</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($approve as $_a) { ?>
        <tr>
          <td class="text-center">MB-<?php echo $_a['mb_id']; ?></td>
          <td class="text-left"><?php echo $_a['mb_fullname']; ?></td>
          <td class="text-left"><?php echo $_a['mb_username']; ?></td>
          <td class="text-left"><?php echo $_a['ag_name']; ?></td>
          <?php if($_a['mb_role'] !== '1') { ?>
            <?php if($_a['mb_stat'] !== '1') { ?>
            <td class="text-center">
              <a href="#" data-toggle="modal" data-target="#confirm" data-body="อนุมัติการใช้งาน" data-href="<?php echo site_url('approve/conf_member/'.$_a['mb_id']); ?>">
              <i class="glyphicon glyphicon-floppy-saved"></i>
              </a>
            </td>
            <?php } ?>
          <td class="text-center">
            <a href="#" data-toggle="modal" data-target="#confirm" data-body="<?php echo $_a['mb_username'].'&nbsp;:'.$_a['mb_fullname']; ?>" data-href="<?php echo site_url('approve/del_member/'.$_a['mb_id']); ?>">
            <i class="glyphicon glyphicon-trash"></i>
            </a>
          </td>
          <?php } ?>
        </tr>
        <?php } ?>
      </tbody>
    </table>
  </div>
</div>

<script>
$(document).ready(function(){
  $('form[role="approve"]').validate({
  	debug:true,
  	errorElement:'label',
  	rules:{
  		name: {
  			required:true,
  			rangelength:[1,50]
  		},
  		lastname: {
  			required:true,
  			rangelength:[1,50]
  		},
  		phone: {
  			required:true,
        min:0
  		},
      agent: {
  			required:true,
  		},
  		username: {
  			required:true
  		},
  		password: {
  			required:true
  		}
  	},
  	messages:{
      name: {
  			required:'กรอกข้อมูลชื่อ',
  			rangelength:'กรอกข้อมูล 1 ถึง 50 ตัวอักษรเท่านั้น'
  		},
  		lastname: {
  			required:'กรอกข้อมูลนามสกุล',
  			rangelength:'กรอกข้อมูล 1 ถึง 50 ตัวอักษรเท่านั้น'
  		},
  		phone: {
  			required:'กรอกเบอร์โทรศัพท์',
        min:'ตัวเลขจำนวนเต็ม'
  		},
  		agent: {
  			required:'เลือกหน่วยงาน',
  		},
  		username: {
  			required:'กรอกข้อมูลชื่อผู้ใช้'
  		},
  		password: {
  			required:'กรอกข้อมูลรหัสผ่าน'
  		}
  	},
  	submitHandler: function(form){
      form.submit();
  	}
  });
});
</script>
