<div class="row">
  <h3>ข้อมูลการติดต่อผู้ดูแลระบบ</h3>
  <form role="rule" class="form-horizontal well" method="post" action="<?php if($contact != '') { echo site_url('contact/update_contact/'.$contact->ct_id); }else{ echo site_url('contact/add_contact'); } ?>">
    <div class="form-group">
      <label class="col-md-4" for="date">วันที่</label>
      <div class="col-md-8">
      <input type="text" name="date" class="form-control" value="<?php echo date('Y-m-d'); ?>" disabled/>
      </div>
    </div>
    <div class="form-group">
      <label class="col-md-4" for="detail">รายละเอียด</label>
      <div class="col-md-8">
        <textarea name="detail" class="form-control" rows="12"><?php if($contact != '') { echo $contact->ct_detail; } ?>
        </textarea>
      </div>
    </div>
    <div class="form-group">
      <label class="col-md-4" for=""></label>
      <div class="col-md-8">
        <button type="submit" class="btn btn-success">บันทึกข้อมูล</button>
        <button type="reset" class="btn btn-default">ยกเลิก</button>
      </div>
    </div>
  </form>
  <div class="alert-warning">
    <div id="ss" data-value="<?php echo ($this->session->flashdata('error') != '') ? $this->session->flashdata('error') : NULL; ?>"></div>
  </div>
</div>

<script>
$(document).ready(function(){
  tinymce.init({
    selector: "textarea",
    menubar: false,
    toolbar: "undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent"
  });
});
</script>
