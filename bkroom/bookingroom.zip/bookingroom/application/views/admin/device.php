<div class="row">
  <h3>ข้อมูลอุปกรณ์</h3>
  <div class="col-md-12">
    <form class="form-horizontal well" role="device" enctype="multipart/form-data" method="post" action="<?php echo site_url('device/add_device'); ?>">
      <div class="form-group">
        <label class="control-label col-md-4" for=""></label>
        <div class="col-md-8">
          <img class="img-thumbnail" id="preview" src="#" alt="" />
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-md-4" for="picture">รูปภาพประกอบ</label>
        <div class="col-md-8">
          <input type="file" id="picture" class="form-control" name="picture" />
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-md-4" for="name">ชื่ออุปกรณ์</label>
        <div class="col-md-8">
        <input name="name" type="text" class="form-control" />
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-md-4" for="type">ประเภทอุปกรณ์</label>
        <div class="col-md-7">
          <select name="type" class="form-control">
            <option></option>
            <?php foreach($devicetype as $_dt) { ?>
            <option value="<?php echo $_dt['dt_id']; ?>"><?php echo $_dt['dt_name']; ?></option>
            <?php } ?>
          </select>
        </div>
        <div class="col-md-1 text-right">
          <a href="" data-toggle="modal" data-target="#form" >แก้ไข</a>
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-md-4" for="detail">รายละเอียด</label>
        <div class="col-md-8">
          <textarea rows="10" name="detail" class="form-control"></textarea>
        </div>
      </div>
      <div class="form-group">
        <label class="col-md-4"></label>
        <div class="col-md-8">
          <button type="submit" class="btn btn-success">เพิ่มข้อมูล</button>
          <button type="reset" class="btn btn-warning">ล้างรายการ</button>
        </div>
      </div>
    </form>
    <div class="alert-warning">
      <div id="ss" data-value="<?php echo ($this->session->flashdata('error') != '') ? $this->session->flashdata('error') : NULL; ?>"></div>
    </div>
  </div>

  <table class="table table-bordered table-hover">
    <thead>
      <tr>
        <th class="text-center" style="width:5%;">ที่</th>
        <th class="text-center">รูปภาพ</th>
        <th class="text-center">ชื่ออุปกรณ์</th>
        <th class="text-center">ประเภท</th>
        <th class="text-center" style="width:35%;">รายละเอียด</th>
        <th class="text-center" style="width:10%;">การใช้งาน</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($device as $_k => $_d) { ?>
      <tr>
        <td class="text-center"><?php echo $_k+1; ?></td>
        <td><img class="img-thumbnail" src="<?php echo base_url('uploads/device/'.$_d['dv_picture']); ?>" style="width:50px;height:50px;" /></td>
        <td class="text-left"><?php echo $_d['dv_name']; ?></td>
        <td class="text-left"><?php echo $_d['dt_name']; ?></td>
        <td class="text-left"><?php echo $_d['dv_detail']; ?></td>
        <td class="text-center"><?php echo $_d['dv_used']; ?></td>
        <td class="text-center" style="width:5%;">
          <a href="<?php echo site_url('device/'.$_d['dv_id']); ?>"><i class="glyphicon glyphicon-wrench"></i></a>
        </td>
        <td class="text-center" style="width:5%;">
          <a href="#" data-toggle="modal" data-target="#confirm" data-body="<?php echo $_d['dv_name']; ?>" data-href="<?php echo site_url('device/del_device/'.$_d['dv_id']); ?>">
          <i class="glyphicon glyphicon-trash"></i>
          </a>
        </td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
</div>

<div class="modal fade" id="form" tabindex="-1" role="dialog" aria-labelledby="label" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">เพิ่มประเภทอุปกรณ์</h4>
      </div>
      <form class="form-horizontal" role="devicetype" method="post" action="<?php echo site_url('device/add_devicetype'); ?>">
      <div class="modal-body">
          <div class="form-group">
            <label class="control-label col-md-4" for="name">ชื่ออุปกรณ์</label>
            <div class="col-md-8">
              <input type="text" class="form-control" name="name" />
            </div>
          </div>
          <div class="form-group">
            <label class="control-label col-md-4" for=""></label>
            <div class="col-md-8">
              <table class="table">
                <?php foreach($devicetype as $_dt) { ?>
                <tr>
                  <td><?php echo $_dt['dt_name']; ?></td>
                  <td class="text-right" style="width:10%;">
                    <a href="#" data-toggle="modal" data-target="#confirm" data-body="<?php echo $_dt['dt_name']; ?>" data-href="<?php echo site_url('device/del_devicetype/'.$_dt['dt_id']); ?>">
                    <i class="glyphicon glyphicon-remove"></i>
                    </a>
                  </td>
                </tr>
                <?php } ?>
              </table>
            </div>
          </div>
      </div>
      <div class="modal-footer">
        <label class="control-label col-md-4" for=""></label>
        <div class="col-md-8">
          <button type="submit" class="btn btn-success btn-block">เพิ่มข้อมูล</button>
        </div>
      </div>
      </form>
    </div>
  </div>
</div>

<script>
$(document).ready(function(){
  function read_file(input) {
    if (input.files && input.files[0]) {
      var reader = new FileReader();
      reader.onload = function (e) {
        $('#preview').attr('src', e.target.result);
      }
      reader.readAsDataURL(input.files[0]);
    }
  }
  $('#picture').change(function(){
    read_file(this);
  });

  $('form[role="device"]').validate({
  	debug:true,
  	errorElement:'label',
  	rules:{
  		picture: {
  			required:true,
        extension:'jpg'
  		},
  		name: {
  			required:true,
  			rangelength:[1,50]
  		},
      type: {
        required:true
      },
  		detail: {
  			required:true
  		}
  	},
  	messages:{
      picture: {
        required:'กรุณาใส่รูปภาพ !',
        extension:'ใช้รูปภาพลักษณะ jpg !'
      },
  		name: {
  			required:'กรอกชื่ออุปกรณ์ !',
  			rangelength:'1 ถึง 50 ตัวอักษร !'
  		},
      type: {
        required:'เลือกประเภทอุปกรณ์ !'
      },
  		detail: {
  			required:'กรุณากรอกรายละเอียด !'
  		}
  	},
  	submitHandler: function(form){
      form.submit();
  	}
  });

  $('form[role="devicetype"]').validate({
    debug:true,
    errorElement:'label',
    rules:{
      name: {
        required:true,
        rangelength:[1,50]
      }
    },
    messages:{
      name: {
        required:'กรอกชื่ออุปกรณ์ !',
        rangelength:'1 ถึง 50 ตัวอักษร !'
      }
    },
    submitHandler: function(form){
      form.submit();
    }
  });
});
</script>
