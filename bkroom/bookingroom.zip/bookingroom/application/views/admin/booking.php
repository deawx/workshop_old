<style type="text/css">
<!--
.style1 {color: #000000
}
.style2 {color: #FF0000}
-->
</style>
<div class="row">
  <h3>ข้อมูลการจองห้องประชุม</h3>
  <div class="col-md-12">
  <form class="form-horizontal well" role="booking" method="post" action="<?php echo site_url('booking/add_booking'); ?>">
    <div class="form-group">
      <label class="col-md-4" for="date">เลือกวันที่</label>
      <div class="col-md-8">
      <input name="date" type="date" class="form-control" />
      </div>
    </div>
    <div class="form-group">
      <label class="col-md-4" for="title">ระบุชื่อเรื่อง</label>
      <div class="col-md-8">
      <input name="title" type="text" placeholder="ระบุชื่อเรื่อง" class="form-control" />
      </div>
    </div>
    <div class="form-group">
      <label class="col-md-4" for="room">เลือกห้องประชุม</label>
      <div class="col-md-8">
        <select class="form-control" name="room">
          <option></option>
          <?php foreach($room as $_r) { ?>
            <option value="<?php echo $_r['rm_id']; ?>"><?php echo $_r['rm_name']; ?></option>
          <?php } ?>
        </select>
      </div>
    </div>
    <div class="form-group">
      <label class="col-md-4" for="radio">ช่วงเวลา</label>
      <div class="col-md-8">
        <div class="radio">
          <label for="radio">
            <input type="radio" name="time" value="8:30-12:00" checked="checked">ครึ่งวันเช้า 8:30-12:00
          </label>
        </div>
        <div class="radio">
          <label for="radio">
            <input type="radio" name="time" value="​13:00-16:00">ครึ่งวันบ่าย 13:00-16:00
          </label>
        </div>
        <div class="radio">
          <label for="radio">
            <input type="radio" name="time" value="8:30-16:00">เต็มวัน 8:30-16:00
          </label>
        </div>
      </div>
    </div>
    <div class="form-group">
      <label class="col-md-4" for="device">รายการเบิกอุปกรณ์</label>
      <?php foreach($device as $_d) { ?>
        <label class="col-md-4" for=""></label>
        <div class="col-sm-5">
          <div class="checkbox">
            <label for="device">
              <input type="checkbox" name="device[]" value="<?php echo $_d['dv_id']; ?>">
              <?php echo $_d['dv_name']; ?>
            </label>
          </div>
        </div>
        <div class="col-sm-3">
          <input type="number" class="form-control devicenum hidden" id="<?php echo $_d['dv_id']; ?>" placeholder="จำนวน" />
        </div>
      <?php } ?>
    </div>
    <div class="form-group">
      <label class="col-md-4" for="phone">เบอร์โทรศัพท์</label>
      <div class="col-md-8">
        <input name="phone" class="form-control" type="text" placeholder="เบอร์โทรศัพท์" />
      </div>
    </div>
    <div class="form-group">
      <label class="col-md-4" for="fullname">ชื่อผู้จอง</label>
      <div class="col-md-8">
        <select class="form-control" name="mb_id">
          <option></option>
          <?php foreach($member as $_m) { ?>
            <option value="<?php echo $_m['mb_id']; ?>"><?php echo $_m['mb_fullname']; ?></option>
          <?php } ?>
        </select>
      </div>
    </div>
    <div class="form-group">
      <label class="col-md-4"></label>
      <div class="col-md-8">
        <button type="submit" class="btn btn-success">เพิ่มข้อมูล</button>
        <button type="reset" class="btn btn-warning">ล้างรายการ</button>
      </div>
    </div>
  </form>
  <div class="alert-warning">
    <div id="ss" data-value="<?php echo ($this->session->flashdata('error') != '') ? $this->session->flashdata('error') : NULL; ?>"></div>
  </div>
  </div>
  <div class="col-md-12">
  <table class="table table-bordered table-hover">
    <thead>
      <tr>
        <th class="text-center" style="width:10%">ที่</th>
        <th class="text-center" style="width:35%">รายการขอใช้ห้องประชุม</th>
        <th class="text-center" style="width:15%">วันที่</th>
        <th class="text-center" style="width:15%">ช่วงเวลา</th>
        <th class="text-center" style="width:15%">ผู้ขอ</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($booking as $_b) { ?>
      <tr>
        <td class="text-center">RS-<?php echo $_b['rs_id']; ?></td>
        <td class="text-left"><?php echo $_b['rs_title']; ?></td>
        <td class="text-center"><?php echo $_b['rs_date']; ?></td>
        <td class="text-center"><?php echo $_b['rs_time']; ?></td>
        <td class="text-center"><?php echo $_b['mb_fullname']; ?></td>
        <td class="text-center">
          <a href="<?php echo site_url('booking/'.$_b['rs_id']); ?>">
          <i class="glyphicon glyphicon-eye-open"></i>
          </a>
        </td>
        <td class="text-center">
          <?php if($_b['rs_stat'] === '1') { ?>
            <i class="glyphicon glyphicon-ok"></i>
          <?php }else{ ?>
            <a href="#" data-toggle="modal" data-target="#confirm" data-body="<?php echo $_b['rs_date'].'&nbsp;'.$_b['rs_time']; ?>" data-href="<?php echo site_url('booking/del_booking/'.$_b['rs_id']); ?>">
            <i class="glyphicon glyphicon-trash"></i>
            </a>
          <?php } ?>
        </td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
  <p><span class="style1"><span class="style2">*หมายเหตุ</span> : เครื่องหมาย/ปุ่ม <img src="http://localhost/bookingroom/assets/img/ดาวน์โหลด.png" width="16" height="16" />ใช้สำหรับเปิดดูรายละเอียดการจองห้องประชุมพร้อมทั้งอนุมัติการจองห้องประชุม</span></p>
  <p>: เครื่องหมาย/ปุ่ม <img src="http://localhost/bookingroom/assets/img/trash.png" width="16" height="16" /> ใช้สำหรับลบรายการจองห้องประชุมที่ไม่ต้องการ </p>
  <p>: หากเป็นเครื่องหมาย/ปุ่ม <img src="http://localhost/bookingroom/assets/img/ดาวน์โหลด (1).png" width="16" height="16" /> แสดงว่าการของห้องประชุมวันนั้นห้องนั้นเวลานั้นได้ถูกการอนุมัติเรียบร้อยแล้ว</p>
  </div>
</div>

<script>
$(document).ready(function(){
  $(':checkbox').click(function(){
    chk = $(this);
    id = $(this).val();
    if($(this).is(':checked'))
    {
      $('.devicenum[id="'+id+'"]').removeClass('hidden').attr('name','devicenum[]').val('1');
    }
    else
    {
      $('.devicenum[id="'+id+'"]').addClass('hidden').removeAttr('name');
    }
  });
	$('form[role="booking"]').validate({
		debug:true,
    onkeyup:false,
		errorElement:'label',
		rules:{
			date: {
				required:true
			},
			title: {
				required:true
			},
			room: {
				required:true
			},
			time: {
				required:true
			},
			phone: {
				required:true,
        min:0
			}
		},
		messages:{
      date: {
        required:'กรุณาเลือกวันที่ !'
			},
			title: {
				required:'กรุณาระบุชื่อเรื่อง !'
			},
			room: {
				required:'กรุณาเลือกห้อง !'
			},
			phone: {
				required:'กรุณากรอกเบอร์โทรศัพท์ !',
				min:'ค่าตัวเลขต้องมากกว่า 0 !'
			}
		},
		submitHandler: function(form){
      form.submit();
		}
	});
});
</script>
