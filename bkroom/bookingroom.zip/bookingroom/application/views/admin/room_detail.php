<div class="row">
  <a href="#"
    class="btn btn-warning btn-block"
    data-body="<?php echo 'สถานที่ : '.$room->rm_name.'&nbsp;การใช้งาน'.$room->rm_used.'ครั้ง'; ?>"
    data-href="<?php echo site_url('room/del_room/'.$room->rm_id); ?>"
    data-toggle="modal" data-target="#confirm">
    <i class="glyphicon glyphicon-fire"></i>
  </a>
  <hr />
  <form class="form-horizontal" role="picture" enctype="multipart/form-data" method="post" action="<?php echo site_url('room/update_room_picture/'.$room->rm_id); ?>">
    <div class="form-group">
      <div class="col-lg-12 img-responsive">
        <?php foreach($picture as $_k => $_p) { ?>
        <div class="col-md-6">
          <img
            class="img-thumbnail"
            style="width:300px;height:300px;"
            src="<?php echo base_url('uploads/room/'.$_p['pt_thumb']); ?>" />
          <a href="#"
            data-toggle="modal"
            data-target="#confirm"
            data-body="ลบรูปภาพนี้"
            data-href="<?php echo site_url('room/del_picture/'.$_p['pt_thumb'].'/'.$_p['pt_id']); ?>">
            <i class="glyphicon glyphicon-remove"></i>
          </a>
        </div>
        <?php } ?>
      </div>
    </div>
    <div class="form-group">
      <div class="col-md-12 img-responsive" id="previewUpload"></div>
    </div>
    <div class="form-group">
      <label class="control-label col-md-2" for="picture">รูปภาพประกอบ</label>
      <div class="col-md-10">
        <input type="file" id="picture" class="form-control" name="picture[]" multiple />
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-md-2" for=""></label>
      <div class="col-md-10">
        <button class="btn btn-success" class="form-control">อัพเดทข้อมูล</button>
      </div>
    </div>
  </form>
  <hr />
  <form class="form-horizontal" role="room" enctype="multipart/form-data" method="post" action="<?php echo site_url('room/update_room/'.$room->rm_id); ?>">
    <div class="form-group">
      <label class="control-label col-md-2" for="picture">เลขกำกับข้อมูล</label>
      <div class="col-md-10">
        RM-<?php echo $room->rm_id; ?>
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-md-2" for="name">ชื่อห้องประชุม</label>
      <div class="col-md-10">
        <input type="text" class="form-control" name="name" value="<?php echo $room->rm_name; ?>" />
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-md-2" for="type">ประเภทห้องประชุม</label>
      <div class="col-md-10">
        <select name="type" class="form-control">
          <?php foreach($roomtype as $_rt) { ?>
            <option <?php if($room->rt_id === $_rt['rt_id']) { echo 'selected'; } ?> value="<?php echo $_rt['rt_id']; ?>"><?php echo $_rt['rt_name']; ?></option>
          <?php } ?>
        </select>
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-md-2" for="">อุปกรณ์ห้องประชุม</label>
      <div class="col-md-10">
        <input type="text" name="device" class="form-control" value="<?php echo $room->rm_device; ?>" />
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-md-2" for="">รายละเอียดห้องประชุม</label>
      <div class="col-md-10">
        <textarea name="detail" rows="3" class="form-control"><?php echo $room->rm_detail; ?></textarea>
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-md-2" for="number">จำนวนการรองรับ</label>
      <div class="col-md-10">
        <input type="number" name="fill" class="form-control" value="<?php echo $room->rm_fill; ?>" />
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-md-2" for="fill">สถิติการใช้งาน</label>
      <div class="col-md-10">
        <div class="input-group">
          <input type="number" name="fill" class="form-control" value="<?php echo $room->rm_used; ?>" disabled/>
          <div class="input-group-addon">/ครั้ง</div>
        </div>
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-md-2" for=""></label>
      <div class="col-md-10">
        <button class="btn btn-success" class="form-control">อัพเดทข้อมูล</button>
      </div>
    </div>
  </form>
  <div class="alert-warning">
    <?php echo ($this->session->flashdata('error') != '') ? $this->session->flashdata('error') : ''; ?>
  </div>
</div>

<script type="text/javascript">
$(function () {
    $("#picture").change(function () {
        if (typeof (FileReader) != "undefined") {
            var dvPreview = $("#previewUpload");
            dvPreview.html("");
            var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.png|.bmp)$/;
            $($(this)[0].files).each(function () {
                var file = $(this);
                if (regex.test(file[0].name.toLowerCase())) {
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        var img = $("<img class='img-thumbnail' />");
                        img.attr("style", "height:200px;width:200px");
                        img.attr("src", e.target.result);
                        dvPreview.append(img);
                    }
                    reader.readAsDataURL(file[0]);
                } else {
                    alert(file[0].name + " is not a valid image file.");
                    dvPreview.html("");
                    return false;
                }
            });
        } else {
            alert("This browser does not support HTML5 FileReader.");
        }
    });
});

$(document).ready(function(){

	$('form[role="room"]').validate({
		debug:true,
		errorElement:'label',
		rules:{
      picture: {
        extension:'jpg'
      },
			name: {
				required:true,
				rangelength:[1,100]
			},
			detail: {
				required:true
			},
			fill: {
				required:true,
        number:true,
        min:1,
				rangelength:[1,5]
			}
		},
		messages:{
      picture: {
        extension:'ใช้รูปภาพลักษณะ jpg !'
      },
			name: {
				required:'กรุณากรอกชื่อห้อง !',
				rangelength:'ชื่อห้องมีความยาวตั้งแต่ 1 ถึง 100 ตัวอักษร !'
			},
			detail: {
				required:'กรุณากรอกรายละเอียด !'
			},
			fill: {
				required:'ระบุปริมาณการรองรับ !',
        min:'ใช้ตัวเลขที่มีค่ามากกว่า 1 !',
        number:'ใช้ตัวเลขเท่านั้น !',
				rangelength:'ตัวเลขความจุไม่เกิน 4 หลัก !'
			}
		},
		submitHandler: function(form){
      form.submit();
		}
	});
});
</script>
