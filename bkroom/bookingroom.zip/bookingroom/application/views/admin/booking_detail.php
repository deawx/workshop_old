<style type="text/css">
<!--
.style1 {color: #000000
}
.style2 {color: #FF0000}
-->
</style>
<div class="row">

  <table class="table table-bordered">
    </thead>
      <tr>
        <td style="width:20%">&nbsp;</td>
        <th class="text-center">รายละเอียดการขอใช้ห้องประชุม</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td class="text-right">เลขกำกับรายการ</td>
        <td>RS-<?php echo $booking->rs_id; ?></td>
      </tr>
      <tr>
        <td class="text-right">หัวข้อเรื่อง</td>
        <td><?php echo $booking->rs_title; ?></td>
      </tr>
      <tr>
        <td class="text-right">ห้องที่ใช้</td>
        <td><?php echo $booking->rm_name; ?></td>
      </tr>
      <tr>
        <td class="text-right">วันที่</td>
        <td><?php echo $booking->rs_date; ?></td>
      </tr>
      <tr>
        <td class="text-right">ช่วงเวลา</td>
        <td><?php echo $booking->rs_time; ?></td>
      </tr>
      <tr>
        <td class="text-right">ผู้ขอใช้</td>
        <td><?php echo $booking->mb_fullname; ?></td>
      </tr>
      <tr>
        <td class="text-right">การยืมอุปกรณ์</td>
        <td>
          <table class="table" style="border:none;">
            <?php foreach($device as $_d) { ?>
            <tr class="well">
              <td>
                อุปกรณ์ : <?php echo $_d['dv_name']; ?>
              </td>
              <td class="text-center">
                จำนวน : <?php echo $_d['br_amount']; ?>
              </td>
            </tr>
            <?php } ?>
          </table>
        </td>
      </tr>
    </tbody>
    <tfoot>
      <tr>
        <td class="text-center">
          <?php if($booking->rs_stat === '1') { ?>
            <i class="glyphicon glyphicon-ok"></i>
          <?php }else{ ?>
            <?php
              switch ($booking->rs_time) {
                case '8:30-12:00':
                  $time = '1';
                  break;
                case '13:00-16:00':
                  $time = '2';
                  break;
                case '8:30-16:00':
                  $time = '3';
                  break;
              }
            ?>
            <a href="#" data-body="<?php echo $booking->rs_date.'&nbsp;'.$booking->rs_time; ?>" data-href="<?php echo site_url('booking/give_booking/'.$booking->rs_id.'/'.$booking->rm_id.'/'.$booking->rs_date.'/'.$time); ?>" data-toggle="modal" data-target="#confirm" >
            <i class="glyphicon glyphicon-plus"></i>
            </a>
          <?php } ?>
        </td>
      </tr>
      <tr>
        <td class="text-center">
          <a href="#" data-body="<?php echo $booking->rs_date.'&nbsp;'.$booking->rs_time; ?>" data-href="<?php echo site_url('booking/del_booking/'.$booking->rs_id); ?>"  data-toggle="modal" data-target="#confirm">
          <i class="glyphicon glyphicon-trash"></i>
          </a>
        </td>
      </tr>
    </tfoot>
  </table>
  <p><span class="style1"><span class="style2">*หมายเหตุ</span> : เครื่องหมาย/ปุ่ม <img src="http://localhost/bookingroom/assets/img/calendar.png" width="16" height="16" /> เป็นปุ่มสำหรับกดยันยันการอนุมัติคำขอการจองห้องประชุม</span></p>
  <p>: เครื่องหมาย/ปุ่ม <img src="http://localhost/bookingroom/assets/img/trash.png" width="16" height="16" /> ใช้สำหรับลบรายการจองห้องประชุมที่ไม่ต้องการ </p>
  <p>: หากเป็นเครื่องหมาย/ปุ่ม <img src="http://localhost/bookingroom/assets/img/ดาวน์โหลด (1).png" width="16" height="16" /> แสดงว่าการของห้องประชุมวันนั้นห้องนั้นเวลานั้นได้ถูกการอนุมัติเรียบร้อยแล้ว</p>
  <div class="alert-warning">
    <?php echo ($this->session->flashdata('error') != '') ? $this->session->flashdata('error') : ''; ?>
  </div>
</div>
