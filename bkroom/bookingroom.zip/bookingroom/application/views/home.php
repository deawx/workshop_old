<style type="text/css">
<!--
body {
	background-image: url();
}
.style1 {	font-family: AngsanaUPC;
	font-size: 24px;
}
.style2 {	font-family: AngsanaUPC;
	font-size: 36px;
}
-->
</style>
<p>
  <div class="row">
</p>
<div style="width:1100px; float:center; padding:5px;">

    <marquee scrollamount="2" scrolldelay="50" truespeed="truespeed">
      <span class="style1">สามารถสมัครสมาชิกได้แล้วตั้งแต่บัดนี้เป็นต้นไป</span>
    </marquee>
  </h3>
  <p>&nbsp;</p>
</div>
<p>&nbsp; </p>
<div class="row">
  <div class="col-lg-12">
    <h3>รายละเอียดและข้อมูลทั่วไป</h3>
  </div>
</div>
<div class="row text-center">
  <div role="tabpanel">
    <ul class="nav nav-tabs" role="tablist">
      <li role="presentation" class="active"><a href="#room" aria-controls="room" role="tab" data-toggle="tab">รายละเอียดห้องประชุม</a></li>
      <li role="presentation"><a href="#device" aria-controls="device" role="tab" data-toggle="tab">รายละเอียดอุปกรณ์</a></li>
      <li role="presentation"><a href="#rule" aria-controls="rule" role="tab" data-toggle="tab">กฎระเบียบการจองห้องประชุม</a></li>
      <li role="presentation"><a href="#contact" aria-controls="form" role="tab" data-toggle="tab">ติดต่อผู้ดูแลระบบ</a></li>
    </ul>
    <div class="tab-content">
      <div role="tabpanel" class="tab-pane active" id="room">
        <br />
        <?php foreach($room as $_r) { ?>
        <div class="col-md-3 col-sm-6 hero-feature">
          <div class="thumbnail">
            <?php
              foreach($picture as $_p) {
                if($_r['rm_id'] === $_p['rm_id']) {
            ?>
            <img
              class="img-thumbnail"
              src="<?php echo base_url('uploads/room/'.$_p['pt_thumb']); ?>"
              style="width:300px;height:300px"
              alt="" />
            <?php } } ?>
            <div class="caption">
              <table class="table">
                <tr>
                  <td>ชื่อห้อง : <?php echo $_r['rm_name']; ?></td>
                </tr>
                <tr>
                  <td>อุปกรณ์ : <?php echo $_r['rm_device']; ?></td>
                </tr>
                <tr>
                  <td>ความจุ : <?php echo $_r['rm_fill']; ?></td>
                </tr>
                <tr>
                  <td><a class="btn btn-info" href="<?php echo site_url('home/'.$_r['rm_id']); ?>">รายละเอียด</a></td>
                </tr>
              </table>
            </div>
          </div>
        </div>
        <?php } ?>
      </div>
      <div role="tabpanel" class="tab-pane" id="device">
      <br />
        <table bgcolor="#FF0033" class="table table-bordered table-hover">
          <thead>
            <tr>
              <th class="text-center" style="width:5%;">ที่</th>
              <th class="text-center">รูปภาพ</th>
              <th class="text-center">ชื่ออุปกรณ์</th>
              <th class="text-center">ประเภท</th>
              <th class="text-center" style="width:35%;">รายละเอียด</th>
              <th class="text-center" style="width:10%;">การใช้งาน</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($device as $_k => $_d) { ?>
            <tr>
              <td class="text-center"><?php echo $_k+1; ?></td>
              <td><img class="img-thumbnail" src="<?php echo base_url('uploads/device/'.$_d['dv_picture']); ?>" style="width:100px;height:100px;" /></td>
              <td class="text-left"><?php echo $_d['dv_name']; ?></td>
              <td class="text-left"><?php echo $_d['dt_name']; ?></td>
              <td class="text-left"><?php echo $_d['dv_detail']; ?></td>
              <td class="text-center"><?php echo $_d['dv_used']; ?></td>
            </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
      <div role="tabpanel" class="tab-pane" id="rule">
        <div class="text-left">
          <?php if($rule != '') {
            echo '<br />';
            echo $rule->rl_detail;
            }
          ?></div>
      </div>
      <div role="tabpanel" class="tab-pane" id="contact">
        <div class="text-left">
          <p>
            <?php if($contact != '') {
            echo '<br />';
            echo $contact->ct_detail;
            }
          ?>
          </p>
        </div>
      </div>
    </div>
  </div>
</div>
