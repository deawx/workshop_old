<div class="row">
  <br />
  <br />
  <div class="">
      
    <form class="form-horizontal well" role="login" method="post" action="<?php echo site_url('login/do_login'); ?>">
       <div class="form-group text-center"><div class="col-md-6 col-md-push-3 col-md-pull-3">
          <h4>::เข้าสู่ระบบ::</h4>
      </div>
       </div>
      <div class="clearfix"></div>
        <div class="form-group">
        <div class="input-group col-md-6 col-md-push-3 col-md-pull-3">
          <span class="input-group-addon">
            <span class="glyphicon glyphicon-user"></span>
          </span>
          <input class="form-control" type="text" name="username" placeholder="ชื่อผู้ใช้" />
        </div>
      </div>
      <div class="form-group">
        <div class="input-group col-md-6 col-md-push-3 col-md-pull-3">
          <span class="input-group-addon">
            <span class="glyphicon glyphicon-eye-close"></span>
          </span>
          <input class="form-control" type="password" name="password" id="password" placeholder="รหัสผ่าน" />
        </div>
      </div>
      <hr />
      <div class="form-group " >
        <div class="col-md-12 col-md-6 col-md-push-3 col-md-pull-3">
          <button class="btn btn-primary" type="submit">ล็อกอิน</button>
          <span class="pull-right">
            <a class="btn btn-info" href="<?php echo site_url('register'); ?>">ลงทะเบียน</a>
          </span>
        </div>
      </div>
    </form>

  </div>
</div>

<script>
$(document).ready(function(){
	$('form[role="login"]').validate({
		debug:true,
		errorElement:'label',
		rules:{
			username: {
				required:true,
				rangelength:[5,10]
			},
			password: {
				required:true,
				rangelength:[5,10]
			}
		},
		messages:{
			username: {
				required:'กรุณากรอกชื่อผู้ใช้ด้วยครับ !',
				rangelength:'กรุณากรอกข้อมูล  ถึง 10 ตัวอักษร !'
			},
			password: {
				required:'กรุณากรอกรหัสผ่านด้วยครับ !',
        rangelength:'กรุณากรอกข้อมูล 5 ถึง 10 ตัวอักษร !'
			}
		},
		submitHandler: function(form){
      form.submit();
		}
	});
});
</script>
