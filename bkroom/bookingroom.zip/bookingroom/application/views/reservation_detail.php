<style>
body {
  margin: 0;
  padding: 0;
  background-color: #FAFAFA;
}
* {
  box-sizing: border-box;
  -moz-box-sizing: border-box;
}
.page {
  width: 21cm;
  min-height: 29.7cm;
  padding: 2cm;
  margin: 1cm auto;
  border: 1px #D3D3D3 solid;
  border-radius: 5px;
  background: white;
  box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
}
@page {
  size: A4;
  margin: 0;
}
@media print {
  .page {
    margin: 0;
    border: initial;
    border-radius: initial;
    width: initial;
    min-height: initial;
    box-shadow: initial;
    background: initial;
    page-break-after: always;
  }
}
table {
  width:100%;
}
.table, .table tr {
  line-height: 1.5em;
}
.table th {
  text-align: center;
}
.table, .table td {
  border:1px solid black;
}
</style>

<?php
$month = array(
  "มกราคม","กุมภาพันธ์","มีนาคม",
  "เมษายน","พฤษภาคม","มิถุนายน",
  "กรกฏาคม","สิงหาคม","กันยายน",
  "ตุลาคม","พฤศจิกายน","ธันวาคม"
);
$nmonth = date("m")-1;
$d = explode('-',$reservation['rs_date'])[2];
$m = explode('-',$reservation['rs_date'])[1]-1;
$y = explode('-',$reservation['rs_date'])[0]+543;
$n = str_pad($reservation['rs_id'],5,'0', STR_PAD_LEFT);
?>
<div class="book">
  <div class="page">
      <h4 style="text-align:center;">หลักฐานการใช้บริการห้องประชุม
        <small><button onclick="javascript:window.print();">สั่งพิมพ์หน้านี้</button></small>
      </h4>
      <br />
      <table height="179">
        <tr>
          <td style="width:60%">
            <img src="<?php echo base_url('assets/img/rmutr.jpg'); ?>" width="100" height="300" style="width:100px;height:100px;" />          </td>
          <td style="width:40%">
            <p style="text-align:left;"> เลขที่ใบจองห้องประชุม <?php echo $n.'/'.$y; ?> </p>
            <p style="text-align:left;">
              วันที่ <?php echo date('d').'&nbsp'; echo $month[$nmonth].'&nbsp'; echo date('Y')+543; ?>
            </p>
          </td>
        </tr>
      </table>
<br />
      <br />
      <p style="text-indent:5em;word-spacing:1em;">
        ข้าพเจ้า <u>&nbsp;<?php echo $reservation['mb_fullname']; ?>&nbsp;</u>
        ตำแหน่ง <u>&nbsp;<?php echo $reservation['mb_position']; ?>&nbsp;</u>
        สังกัดหน่วยงาน <u>&nbsp;<?php echo $reservation['ag_name']; ?>&nbsp;</u>
        ฝ่าย/แผนก <u>&nbsp;<?php echo $reservation['mb_group']; ?>&nbsp;</u>
        เบอร์โทรศัพท์ <u>&nbsp;<?php echo $reservation['mb_phone']; ?>&nbsp;</u>
      </p>
      <p style="text-indent:5em;line-height:2em;word-spacing:1em;">
        มีความประสงค์ขอใช้บริการห้องประชุม <u>&nbsp;<?php echo $reservation['rm_name']; ?>&nbsp;</u>
        สำหรับหัวข้อการประชุมเรื่อง <u>&nbsp;<?php echo $reservation['rs_title']; ?>&nbsp;</u>
        ภายในวันที่ <u>&nbsp;<?php echo $d.'&nbsp;'; echo $month[$m].'&nbsp;'; echo $y; ?>&nbsp;</u>
        ภายในช่วงเวลา <u>&nbsp;<?php echo $reservation['rs_time']; ?>&nbsp;</u>
      </p>
      <?php if($device != '') { ?>
      <p>
        และในการขอใช้ห้องประชุมครั้งนี้ ข้าพเจ้าจึงขอใช้อุปกรณ์เพิ่มเติมต่างๆ มีรายการดังต่อไปนี้
      </p>
      <table class="table">
        <tr>
          <th>ที่</th>
          <th>ชื่ออุปกรณ์</th>
          <th>ประเภทอุปกรณ์</th>
          <th>จำนวน</th>
        </tr>
        <?php foreach($device as $_k => $_d) { ?>
        <tr>
          <td style="text-align:center;">
            <?php echo $_k+1; ?>
          </td>
          <td style="padding-left:1em;">
            <?php echo $_d['dv_name']; ?>
          </td>
          <td style="padding-left:1em;">
            <?php echo $_d['dt_name']; ?>
          </td>
          <td style="text-align:center;">
            <?php echo $_d['br_amount']; ?>
          </td>
        </tr>
        <?php } ?>
      </table>
      <?php }else{ ?>
        <p>โดยไม่มีรายการเบิกอุปกรณ์ใดๆ</p>
      <?php } ?>
      <p>
        *เพิ่มเติม<br />
        ..........................................................................................................................
        ..........................................................................................................................
      </p>
      <!-- <table style="text-align:center;">
        <tr>
          <td style="width:50%;">
            <p>ลงชื่อ..............ผู้จอง</p>
            <p>(....................)</p>
            <p>วันที่...................</p>
          </td>
          <td style="width:50%;">
            <p>ลงชื่อ..............ผู้อนุมัติ</p>
            <p>(....................)</p>
            <p>วันที่...................</p>
          </td>
        </tr>
      </table> -->
      <p>
        **<u>หมายเหตุ</u>กรุณายื่นเอกสารฉบับนี้พร้อมแสดงบัตรยืนยันตัวตนในการติดต่อ เอกสารจะใช้ได้เมื่อเจ้าหน้าที่อนุมัติคำร้องเรียบร้อยแล้ว
      </p>
  </div>
</div>
