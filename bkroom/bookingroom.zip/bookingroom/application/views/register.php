<div class="row">
  <br />
  <br />
  <!--<div class="col-md-6 col-md-push-3 col-md-pull-3">-->
  <div>
    <form class="form-horizontal well" role="register" method="post" action="<?php echo site_url('register/do_register'); ?>">
      <div class="form-group text-center"><div class="col-md-6 col-md-push-3 col-md-pull-3">
          <h4>::สมัครสมาชิก::</h4>
      </div>
       </div>
      <div class="clearfix"></div>
        <div class="form-group">
        <div class="input-group col-md-6 col-md-push-3 col-md-pull-3">
          <span class="input-group-addon">
            <span class="glyphicon glyphicon-user"></span>
          </span>
          <input class="form-control" type="text" name="username" id="username" placeholder="ชื่อผู้ใช้" />
        </div>
      </div>
      <div class="form-group">
        <div class="input-group col-md-6 col-md-push-3 col-md-pull-3">
          <span class="input-group-addon">
            <span class="glyphicon glyphicon-eye-close"></span>
          </span>
          <input class="form-control" type="password" name="password" id="password" placeholder="รหัสผ่าน" />
        </div>
      </div>
      <div class="form-group">
        <div class="input-group col-md-6 col-md-push-3 col-md-pull-3">
          <span class="input-group-addon">
            <span class="glyphicon glyphicon-eye-close"></span>
          </span>
          <input class="form-control" type="password" name="confirmPassword" placeholder="ยืนยันรหัสผ่าน" />
        </div>
      </div>
      <div class="form-group">
        <div class="input-group col-md-6 col-md-push-3 col-md-pull-3">
          <span class="input-group-addon">
            <span class="glyphicon glyphicon-info-sign"></span>
          </span>
          <input class="form-control" type="text" name="name" placeholder="ชื่อ" />
        </div>
      </div>
      <div class="form-group">
        <div class="input-group col-md-6 col-md-push-3 col-md-pull-3">
          <span class="input-group-addon">
            <span class="glyphicon glyphicon-info-sign"></span>
          </span>
          <input class="form-control" type="text" name="lastname" placeholder="นามสกุล" />
        </div>
      </div>
      <div class="form-group">
        <div class="input-group col-md-6 col-md-push-3 col-md-pull-3">
          <span class="input-group-addon">
            <span class="glyphicon glyphicon-info-sign"></span>
          </span>
          <input class="form-control" type="text" name="position" placeholder="ตำแหน่ง" />
        </div>
      </div>
      <div class="form-group">
        <div class="input-group col-md-6 col-md-push-3 col-md-pull-3">
          <span class="input-group-addon">
            <span class="glyphicon glyphicon-info-sign"></span>
          </span>
          <input class="form-control" type="text" name="group" placeholder="ฝ่าย/แผนก" />
        </div>
      </div>
      <div class="form-group">
        <div class="input-group col-md-6 col-md-push-3 col-md-pull-3">
          <span class="input-group-addon">
            <span class="glyphicon glyphicon-info-sign"></span>
          </span>
          <select class="form-control" name="agent">
            <option value="">----เลือกคณะ----</option>
            <?php foreach($agent as $_a) { ?>
            <option value="<?php echo $_a['ag_id']; ?>"><?php echo $_a['ag_name']; ?></option>
            <?php } ?>
          </select>
        </div>
      </div>
      <div class="form-group">
        <div class="input-group col-md-6 col-md-push-3 col-md-pull-3">
          <span class="input-group-addon">
            <span class="glyphicon glyphicon-phone-alt"></span>
          </span>
          <input class="form-control" type="phone" name="phone" placeholder="เบอร์โทรศัพท์" />
        </div>
      </div>
      <hr />
      <div class="form-group">
        <div class="col-md-12 col-md-6 col-md-push-3 col-md-pull-3">
          <button class="btn btn-primary" type="submit">ลงทะเบียน</button>
          <span class="pull-right">
            <a class="btn btn-info" href="<?php echo site_url('login'); ?>">เข้าสู่ระบบ</a>
          </span>
        </div>
      </div>
      <?php if($this->session->flashdata('error')) { ?>
        <span class="text-warning h4"><?php echo $this->session->flashdata('error'); ?></span>
      <?php } ?>
    </form>

</div>
</div>

<script>
$(document).ready(function(){

	$('form[role="register"]').validate({
		debug:true,
    onkeyup:false,
		errorElement:'label',
		rules:{
			username: {
				required:true,
				rangelength:[5,20],
        remote: {
          type: 'POST',
          url : '<?php echo site_url("register/check_name"); ?>',
          data : {
            username : function(){
              return $('#username').val();
            }
          }
        }
			},
			password: {
				required:true,
				rangelength:[8,10]
			},
			confirmPassword: {
				required:true,
				equalTo: '#password'
			},
			name: {
				required:true,
				rangelength:[2,30]
			},
			lastname: {
				required:true,
				rangelength:[3,30]
			},
			phone: {
				required:true,
        number:true
			},
			position: {
				required:true,
        rangelength:[1,30]
			},
			group: {
				required:true,
        rangelength:[1,30]
			},
			agent: {
				required:true
			}
		},
		messages:{
			username: {
				required:'กรุณากรอกชื่อผู้ใช้ด้วยครับ !',
        rangelength:'กรุณากรอกข้อมูล 5 ถึง 20 ตัวอักษร !',
        remote : 'มีชื่อผู้ใช้อยู่แล้วในระบบ ไม่สามารถใช้ชื่อนี้ได้'
			},
			password: {
				required:'กรุณากรอกรหัสผ่านด้วยครับ !',
        rangelength:'กรุณากรอกข้อมูล 8 ถึง 10 ตัวอักษร !'
			},
			confirmPassword: {
				required:'กรุณากรอกรหัสผ่านให้ตรงกันด้วยครับ !',
				matched:'กรุณากรอกรหัสผ่านให้ตรงกันด้วยครับ !'
			},
			name: {
				required:'กรุณากรอกชื่อด้วยครับ !',
        rangelength:'ไม่เกิน 30 ตัวอักษร !'
			},
			lastname: {
				required:'กรุณากรอกนามสกุลด้วยครับ !',
        rangelength:'ไม่เกิน 30 ตัวอักษร !'
			},
      phone: {
				required:'กรุณากรอกเบอร์โทร !',
				number:'กรุณกรอกข้อมูลตัวเลขด้วยครับ !'
			},
      position: {
				required:'กรอกข้อมูลตำแหน่งงาน !',
        rangelength:'ไม่เกิน 30 ตัวอักษร !'
			},
      group: {
				required:'กรอกข้อมูลตำแหน่งงาน !',
        rangelength:'ไม่เกิน 30 ตัวอักษร !'
			},
      agent: {
				required:'เลือกหน่วยงาน !'
			}
		},
		submitHandler: function(form){
      form.submit();
		}
	});
});
</script>
