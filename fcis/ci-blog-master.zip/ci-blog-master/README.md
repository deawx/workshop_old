# ci-blog
Basic CMS based on CodeIgniter 3.x
# Installation

Copy 'ci-blog' directory to your 'www' or 'htdocs' directory

Create database 'project_ciblogdb' or another name you want

Import the .sql file from /sql/1_ciblogdb_structure_and_sample_data.sql to your database

Rename file application/config/config.php.example to config.php

Rename file application/config/database.php.example to database.php

Configure the database.php (host,user,password, db) based on your database server configuration

Open your browser and type => http://localhost/ci-blog

Done.

Sampel Accounts:

admin => username : admin@admin.com password:password

members => username : members@website.com password:12345678


