<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Name:  CI - Blog
*
* Version: 0.1
*
* Author: Sugiarto
*		  sugiarto@gie-art.com
*         @gieart_dotcom
*
*/

$config['ciblog_theme'] = 'default';

