<footer class="footer-wrap" id="footer">
        <div class="container">
          <div class="row">
            <div class="col-sm-12">
              <div class="clearfix footer-inner">
                <ul class="social-icons">
                  <li><a data-tooltip="Facebook" data-delay="50"  data-toggle="tooltip" data-position="top" class="tooltips tooltipped facebook" href="#"><i class="fa fa-facebook"></i></a>
                  </li>
                  <li><a data-tooltip="Linkdin" data-delay="50" data-toggle="tooltip"  data-position="top" class="tooltips tooltipped linkedin" href="#"><i class="fa fa-linkedin"></i></a>
                  </li>
                  <li><a data-tooltip="Twitter" data-delay="50" data-toggle="tooltip"  data-position="top" class="tooltips tooltipped twitter" href="#"><i class="fa fa-twitter"></i></a>
                  </li>
                  <li><a data-tooltip="Google Plus" data-delay="50" data-toggle="tooltip" data-position="top" class="tooltips tooltipped google-plus" href="#"><i class="fa fa-google-plus"></i></a>
                  </li>
                </ul>
                <div class="copyright">
                  <span>CI Blog &copy; All Rights Reserved | Theme by <a href="http://wowbootstrap.com">Wowbootstrap.com</a></span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>